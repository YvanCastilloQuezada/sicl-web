import {
  TRPCClientError,
  TRPCUntypedClient,
  clientCallTypeToProcedureType,
  createFlatProxy,
  createRecursiveProxy,
  createTRPCClient,
  createTRPCClientProxy,
  createTRPCUntypedClient,
  createWSClient,
  experimental_localLink,
  getFetch,
  getUntypedClient,
  httpBatchLink,
  httpBatchStreamLink,
  httpLink,
  httpSubscriptionLink,
  isAsyncIterable,
  isFormData,
  isNonJsonSerializable,
  isObject,
  isOctetType,
  isTRPCClientError,
  loggerLink,
  retryLink,
  splitLink,
  unstable_httpBatchStreamLink,
  unstable_httpSubscriptionLink,
  unstable_localLink,
  wsLink
} from "./chunk-GIAR3RVC.js";
import {
  hashKey,
  infiniteQueryOptions,
  queryOptions,
  skipToken,
  useInfiniteQuery,
  useMutation,
  usePrefetchInfiniteQuery,
  usePrefetchQuery,
  useQueries,
  useQuery,
  useSuspenseInfiniteQuery,
  useSuspenseQueries,
  useSuspenseQuery
} from "./chunk-NCYC6RU2.js";
import {
  require_jsx_runtime
} from "./chunk-KIYS72I5.js";
import {
  require_react
} from "./chunk-MO2SMAW5.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/.pnpm/@trpc+react-query@11.6.0_@tanstack+react-query@5.90.2_react@19.2.1__@trpc+client@11.6.0_b3a4fc388d38e7312f2de6608955b66b/node_modules/@trpc/react-query/dist/getQueryKey-BY58RNzP.mjs
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
    key = keys[i];
    if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
      get: ((k) => from[k]).bind(null, key),
      enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
    });
  }
  return to;
};
var __toESM2 = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
  value: mod,
  enumerable: true
}) : target, mod));
var require_objectWithoutPropertiesLoose = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/objectWithoutPropertiesLoose.js"(exports, module) {
  function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
      if (e.includes(n)) continue;
      t[n] = r[n];
    }
    return t;
  }
  module.exports = _objectWithoutPropertiesLoose, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var require_objectWithoutProperties = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/objectWithoutProperties.js"(exports, module) {
  var objectWithoutPropertiesLoose = require_objectWithoutPropertiesLoose();
  function _objectWithoutProperties$1(e, t) {
    if (null == e) return {};
    var o, r, i = objectWithoutPropertiesLoose(e, t);
    if (Object.getOwnPropertySymbols) {
      var s = Object.getOwnPropertySymbols(e);
      for (r = 0; r < s.length; r++) o = s[r], t.includes(o) || {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
    }
    return i;
  }
  module.exports = _objectWithoutProperties$1, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var require_typeof = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/typeof.js"(exports, module) {
  function _typeof$2(o) {
    "@babel/helpers - typeof";
    return module.exports = _typeof$2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o$1) {
      return typeof o$1;
    } : function(o$1) {
      return o$1 && "function" == typeof Symbol && o$1.constructor === Symbol && o$1 !== Symbol.prototype ? "symbol" : typeof o$1;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof$2(o);
  }
  module.exports = _typeof$2, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var require_toPrimitive = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/toPrimitive.js"(exports, module) {
  var _typeof$1 = require_typeof()["default"];
  function toPrimitive$1(t, r) {
    if ("object" != _typeof$1(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof$1(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  module.exports = toPrimitive$1, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var require_toPropertyKey = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/toPropertyKey.js"(exports, module) {
  var _typeof = require_typeof()["default"];
  var toPrimitive = require_toPrimitive();
  function toPropertyKey$1(t) {
    var i = toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
  }
  module.exports = toPropertyKey$1, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var require_defineProperty = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/defineProperty.js"(exports, module) {
  var toPropertyKey = require_toPropertyKey();
  function _defineProperty(e, r, t) {
    return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: true,
      configurable: true,
      writable: true
    }) : e[r] = t, e;
  }
  module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var require_objectSpread2 = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/objectSpread2.js"(exports, module) {
  var defineProperty = require_defineProperty();
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function(r$1) {
        return Object.getOwnPropertyDescriptor(e, r$1).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), true).forEach(function(r$1) {
        defineProperty(e, r$1, t[r$1]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r$1) {
        Object.defineProperty(e, r$1, Object.getOwnPropertyDescriptor(t, r$1));
      });
    }
    return e;
  }
  module.exports = _objectSpread2, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var import_objectWithoutProperties = __toESM2(require_objectWithoutProperties(), 1);
var import_objectSpread2 = __toESM2(require_objectSpread2(), 1);
var _excluded = ["cursor", "direction"];
function getQueryKeyInternal(path, input, type) {
  const splitPath = path.flatMap((part) => part.split("."));
  if (!input && (!type || type === "any")) return splitPath.length ? [splitPath] : [];
  if (type === "infinite" && isObject(input) && ("direction" in input || "cursor" in input)) {
    const { cursor: _, direction: __ } = input, inputWithoutCursorAndDirection = (0, import_objectWithoutProperties.default)(input, _excluded);
    return [splitPath, {
      input: inputWithoutCursorAndDirection,
      type: "infinite"
    }];
  }
  return [splitPath, (0, import_objectSpread2.default)((0, import_objectSpread2.default)({}, typeof input !== "undefined" && input !== skipToken && { input }), type && type !== "any" && { type })];
}
function getMutationKeyInternal(path) {
  return getQueryKeyInternal(path, void 0, "any");
}
function getQueryKey(procedureOrRouter, ..._params) {
  const [input, type] = _params;
  const path = procedureOrRouter._def().path;
  const queryKey = getQueryKeyInternal(path, input, type !== null && type !== void 0 ? type : "any");
  return queryKey;
}
function getMutationKey(procedure) {
  const path = procedure._def().path;
  return getMutationKeyInternal(path);
}

// node_modules/.pnpm/@trpc+react-query@11.6.0_@tanstack+react-query@5.90.2_react@19.2.1__@trpc+client@11.6.0_b3a4fc388d38e7312f2de6608955b66b/node_modules/@trpc/react-query/dist/shared-JtnEvJvB.mjs
var React$2 = __toESM(require_react(), 1);
var React$1 = __toESM(require_react(), 1);
var React = __toESM(require_react(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
function createReactDecoration(hooks) {
  return createRecursiveProxy(({ path, args }) => {
    var _rest$;
    const pathCopy = [...path];
    const lastArg = pathCopy.pop();
    if (lastArg === "useMutation") return hooks[lastArg](pathCopy, ...args);
    if (lastArg === "_def") return { path: pathCopy };
    const [input, ...rest] = args;
    const opts = (_rest$ = rest[0]) !== null && _rest$ !== void 0 ? _rest$ : {};
    return hooks[lastArg](pathCopy, input, opts);
  });
}
var _React$createContext;
var contextProps = [
  "client",
  "ssrContext",
  "ssrState",
  "abortOnUnmount"
];
var TRPCContext = (_React$createContext = React$2.createContext) === null || _React$createContext === void 0 ? void 0 : _React$createContext.call(React$2, null);
var getQueryType = (utilName) => {
  switch (utilName) {
    case "queryOptions":
    case "fetch":
    case "ensureData":
    case "prefetch":
    case "getData":
    case "setData":
    case "setQueriesData":
      return "query";
    case "infiniteQueryOptions":
    case "fetchInfinite":
    case "prefetchInfinite":
    case "getInfiniteData":
    case "setInfiniteData":
      return "infinite";
    case "setMutationDefaults":
    case "getMutationDefaults":
    case "isMutating":
    case "cancel":
    case "invalidate":
    case "refetch":
    case "reset":
      return "any";
  }
};
function createRecursiveUtilsProxy(context) {
  return createRecursiveProxy((opts) => {
    const path = [...opts.path];
    const utilName = path.pop();
    const args = [...opts.args];
    const input = args.shift();
    const queryType = getQueryType(utilName);
    const queryKey = getQueryKeyInternal(path, input, queryType);
    const contextMap = {
      infiniteQueryOptions: () => context.infiniteQueryOptions(path, queryKey, args[0]),
      queryOptions: () => context.queryOptions(path, queryKey, ...args),
      fetch: () => context.fetchQuery(queryKey, ...args),
      fetchInfinite: () => context.fetchInfiniteQuery(queryKey, args[0]),
      prefetch: () => context.prefetchQuery(queryKey, ...args),
      prefetchInfinite: () => context.prefetchInfiniteQuery(queryKey, args[0]),
      ensureData: () => context.ensureQueryData(queryKey, ...args),
      invalidate: () => context.invalidateQueries(queryKey, ...args),
      reset: () => context.resetQueries(queryKey, ...args),
      refetch: () => context.refetchQueries(queryKey, ...args),
      cancel: () => context.cancelQuery(queryKey, ...args),
      setData: () => {
        context.setQueryData(queryKey, args[0], args[1]);
      },
      setQueriesData: () => context.setQueriesData(queryKey, args[0], args[1], args[2]),
      setInfiniteData: () => {
        context.setInfiniteQueryData(queryKey, args[0], args[1]);
      },
      getData: () => context.getQueryData(queryKey),
      getInfiniteData: () => context.getInfiniteQueryData(queryKey),
      setMutationDefaults: () => context.setMutationDefaults(getMutationKeyInternal(path), input),
      getMutationDefaults: () => context.getMutationDefaults(getMutationKeyInternal(path)),
      isMutating: () => context.isMutating({ mutationKey: getMutationKeyInternal(path) })
    };
    return contextMap[utilName]();
  });
}
function createReactQueryUtils(context) {
  const clientProxy = createTRPCClientProxy(context.client);
  const proxy = createRecursiveUtilsProxy(context);
  return createFlatProxy((key) => {
    const contextName = key;
    if (contextName === "client") return clientProxy;
    if (contextProps.includes(contextName)) return context[contextName];
    return proxy[key];
  });
}
function createQueryUtilsProxy(context) {
  return createRecursiveUtilsProxy(context);
}
var import_objectSpread2$3 = __toESM2(require_objectSpread2(), 1);
function createUseQueries(client) {
  const untypedClient = client instanceof TRPCUntypedClient ? client : getUntypedClient(client);
  return createRecursiveProxy((opts) => {
    const arrayPath = opts.path;
    const dotPath = arrayPath.join(".");
    const [input, _opts] = opts.args;
    const options = (0, import_objectSpread2$3.default)({
      queryKey: getQueryKeyInternal(arrayPath, input, "query"),
      queryFn: () => {
        return untypedClient.query(dotPath, input, _opts === null || _opts === void 0 ? void 0 : _opts.trpc);
      }
    }, _opts);
    return options;
  });
}
var import_objectSpread2$2 = __toESM2(require_objectSpread2(), 1);
function getClientArgs(queryKey, opts, infiniteParams) {
  var _queryKey$;
  const path = queryKey[0];
  let input = (_queryKey$ = queryKey[1]) === null || _queryKey$ === void 0 ? void 0 : _queryKey$.input;
  if (infiniteParams) {
    var _input;
    input = (0, import_objectSpread2$2.default)((0, import_objectSpread2$2.default)((0, import_objectSpread2$2.default)({}, (_input = input) !== null && _input !== void 0 ? _input : {}), infiniteParams.pageParam ? { cursor: infiniteParams.pageParam } : {}), {}, { direction: infiniteParams.direction });
  }
  return [
    path.join("."),
    input,
    opts === null || opts === void 0 ? void 0 : opts.trpc
  ];
}
var require_asyncIterator = __commonJS({ "../../node_modules/.pnpm/@oxc-project+runtime@0.72.2/node_modules/@oxc-project/runtime/src/helpers/asyncIterator.js"(exports, module) {
  function _asyncIterator$1(r) {
    var n, t, o, e = 2;
    for ("undefined" != typeof Symbol && (t = Symbol.asyncIterator, o = Symbol.iterator); e--; ) {
      if (t && null != (n = r[t])) return n.call(r);
      if (o && null != (n = r[o])) return new AsyncFromSyncIterator(n.call(r));
      t = "@@asyncIterator", o = "@@iterator";
    }
    throw new TypeError("Object is not async iterable");
  }
  function AsyncFromSyncIterator(r) {
    function AsyncFromSyncIteratorContinuation(r$1) {
      if (Object(r$1) !== r$1) return Promise.reject(new TypeError(r$1 + " is not an object."));
      var n = r$1.done;
      return Promise.resolve(r$1.value).then(function(r$2) {
        return {
          value: r$2,
          done: n
        };
      });
    }
    return AsyncFromSyncIterator = function AsyncFromSyncIterator$1(r$1) {
      this.s = r$1, this.n = r$1.next;
    }, AsyncFromSyncIterator.prototype = {
      s: null,
      n: null,
      next: function next() {
        return AsyncFromSyncIteratorContinuation(this.n.apply(this.s, arguments));
      },
      "return": function _return(r$1) {
        var n = this.s["return"];
        return void 0 === n ? Promise.resolve({
          value: r$1,
          done: true
        }) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
      },
      "throw": function _throw(r$1) {
        var n = this.s["return"];
        return void 0 === n ? Promise.reject(r$1) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
      }
    }, new AsyncFromSyncIterator(r);
  }
  module.exports = _asyncIterator$1, module.exports.__esModule = true, module.exports["default"] = module.exports;
} });
var import_asyncIterator = __toESM2(require_asyncIterator(), 1);
function createTRPCOptionsResult(value) {
  const path = value.path.join(".");
  return { path };
}
function useHookResult(value) {
  const result = createTRPCOptionsResult(value);
  return React$1.useMemo(() => result, [result]);
}
async function buildQueryFromAsyncIterable(asyncIterable, queryClient, queryKey) {
  const queryCache = queryClient.getQueryCache();
  const query = queryCache.build(queryClient, { queryKey });
  query.setState({
    data: [],
    status: "success"
  });
  const aggregate = [];
  var _iteratorAbruptCompletion = false;
  var _didIteratorError = false;
  var _iteratorError;
  try {
    for (var _iterator = (0, import_asyncIterator.default)(asyncIterable), _step; _iteratorAbruptCompletion = !(_step = await _iterator.next()).done; _iteratorAbruptCompletion = false) {
      const value = _step.value;
      {
        aggregate.push(value);
        query.setState({ data: [...aggregate] });
      }
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (_iteratorAbruptCompletion && _iterator.return != null) await _iterator.return();
    } finally {
      if (_didIteratorError) throw _iteratorError;
    }
  }
  return aggregate;
}
var import_objectSpread2$1 = __toESM2(require_objectSpread2(), 1);
function createUtilityFunctions(opts) {
  const { client, queryClient } = opts;
  const untypedClient = client instanceof TRPCUntypedClient ? client : getUntypedClient(client);
  return {
    infiniteQueryOptions: (path, queryKey, opts$1) => {
      var _queryKey$, _ref;
      const inputIsSkipToken = ((_queryKey$ = queryKey[1]) === null || _queryKey$ === void 0 ? void 0 : _queryKey$.input) === skipToken;
      const queryFn = async (queryFnContext) => {
        var _opts$trpc;
        const actualOpts = (0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, { trpc: (0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.trpc), (opts$1 === null || opts$1 === void 0 || (_opts$trpc = opts$1.trpc) === null || _opts$trpc === void 0 ? void 0 : _opts$trpc.abortOnUnmount) ? { signal: queryFnContext.signal } : { signal: null }) });
        const result = await untypedClient.query(...getClientArgs(queryKey, actualOpts, {
          direction: queryFnContext.direction,
          pageParam: queryFnContext.pageParam
        }));
        return result;
      };
      return Object.assign(infiniteQueryOptions((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        initialData: opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.initialData,
        queryKey,
        queryFn: inputIsSkipToken ? skipToken : queryFn,
        initialPageParam: (_ref = opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.initialCursor) !== null && _ref !== void 0 ? _ref : null
      })), { trpc: createTRPCOptionsResult({ path }) });
    },
    queryOptions: (path, queryKey, opts$1) => {
      var _queryKey$2;
      const inputIsSkipToken = ((_queryKey$2 = queryKey[1]) === null || _queryKey$2 === void 0 ? void 0 : _queryKey$2.input) === skipToken;
      const queryFn = async (queryFnContext) => {
        var _opts$trpc2;
        const actualOpts = (0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, { trpc: (0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.trpc), (opts$1 === null || opts$1 === void 0 || (_opts$trpc2 = opts$1.trpc) === null || _opts$trpc2 === void 0 ? void 0 : _opts$trpc2.abortOnUnmount) ? { signal: queryFnContext.signal } : { signal: null }) });
        const result = await untypedClient.query(...getClientArgs(queryKey, actualOpts));
        if (isAsyncIterable(result)) return buildQueryFromAsyncIterable(result, queryClient, queryKey);
        return result;
      };
      return Object.assign(queryOptions((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        initialData: opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.initialData,
        queryKey,
        queryFn: inputIsSkipToken ? skipToken : queryFn
      })), { trpc: createTRPCOptionsResult({ path }) });
    },
    fetchQuery: (queryKey, opts$1) => {
      return queryClient.fetchQuery((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        queryKey,
        queryFn: () => untypedClient.query(...getClientArgs(queryKey, opts$1))
      }));
    },
    fetchInfiniteQuery: (queryKey, opts$1) => {
      var _opts$initialCursor;
      return queryClient.fetchInfiniteQuery((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        queryKey,
        queryFn: ({ pageParam, direction }) => {
          return untypedClient.query(...getClientArgs(queryKey, opts$1, {
            pageParam,
            direction
          }));
        },
        initialPageParam: (_opts$initialCursor = opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.initialCursor) !== null && _opts$initialCursor !== void 0 ? _opts$initialCursor : null
      }));
    },
    prefetchQuery: (queryKey, opts$1) => {
      return queryClient.prefetchQuery((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        queryKey,
        queryFn: () => untypedClient.query(...getClientArgs(queryKey, opts$1))
      }));
    },
    prefetchInfiniteQuery: (queryKey, opts$1) => {
      var _opts$initialCursor2;
      return queryClient.prefetchInfiniteQuery((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        queryKey,
        queryFn: ({ pageParam, direction }) => {
          return untypedClient.query(...getClientArgs(queryKey, opts$1, {
            pageParam,
            direction
          }));
        },
        initialPageParam: (_opts$initialCursor2 = opts$1 === null || opts$1 === void 0 ? void 0 : opts$1.initialCursor) !== null && _opts$initialCursor2 !== void 0 ? _opts$initialCursor2 : null
      }));
    },
    ensureQueryData: (queryKey, opts$1) => {
      return queryClient.ensureQueryData((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, opts$1), {}, {
        queryKey,
        queryFn: () => untypedClient.query(...getClientArgs(queryKey, opts$1))
      }));
    },
    invalidateQueries: (queryKey, filters, options) => {
      return queryClient.invalidateQueries((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, filters), {}, { queryKey }), options);
    },
    resetQueries: (queryKey, filters, options) => {
      return queryClient.resetQueries((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, filters), {}, { queryKey }), options);
    },
    refetchQueries: (queryKey, filters, options) => {
      return queryClient.refetchQueries((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, filters), {}, { queryKey }), options);
    },
    cancelQuery: (queryKey, options) => {
      return queryClient.cancelQueries({ queryKey }, options);
    },
    setQueryData: (queryKey, updater, options) => {
      return queryClient.setQueryData(queryKey, updater, options);
    },
    setQueriesData: (queryKey, filters, updater, options) => {
      return queryClient.setQueriesData((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, filters), {}, { queryKey }), updater, options);
    },
    getQueryData: (queryKey) => {
      return queryClient.getQueryData(queryKey);
    },
    setInfiniteQueryData: (queryKey, updater, options) => {
      return queryClient.setQueryData(queryKey, updater, options);
    },
    getInfiniteQueryData: (queryKey) => {
      return queryClient.getQueryData(queryKey);
    },
    setMutationDefaults: (mutationKey, options) => {
      const path = mutationKey[0];
      const canonicalMutationFn = (input) => {
        return untypedClient.mutation(...getClientArgs([path, { input }], opts));
      };
      return queryClient.setMutationDefaults(mutationKey, typeof options === "function" ? options({ canonicalMutationFn }) : options);
    },
    getMutationDefaults: (mutationKey) => {
      return queryClient.getMutationDefaults(mutationKey);
    },
    isMutating: (filters) => {
      return queryClient.isMutating((0, import_objectSpread2$1.default)((0, import_objectSpread2$1.default)({}, filters), {}, { exact: true }));
    }
  };
}
var import_objectSpread22 = __toESM2(require_objectSpread2());
var trackResult = (result, onTrackResult) => {
  const trackedResult = new Proxy(result, { get(target, prop) {
    onTrackResult(prop);
    return target[prop];
  } });
  return trackedResult;
};
function createRootHooks(config) {
  var _config$overrides$use, _config$overrides, _config$context;
  const mutationSuccessOverride = (_config$overrides$use = config === null || config === void 0 || (_config$overrides = config.overrides) === null || _config$overrides === void 0 || (_config$overrides = _config$overrides.useMutation) === null || _config$overrides === void 0 ? void 0 : _config$overrides.onSuccess) !== null && _config$overrides$use !== void 0 ? _config$overrides$use : (options) => options.originalFn();
  const Context = (_config$context = config === null || config === void 0 ? void 0 : config.context) !== null && _config$context !== void 0 ? _config$context : TRPCContext;
  const createClient = createTRPCClient;
  const TRPCProvider = (props) => {
    var _props$ssrState;
    const { abortOnUnmount = false, queryClient, ssrContext } = props;
    const [ssrState, setSSRState] = React.useState((_props$ssrState = props.ssrState) !== null && _props$ssrState !== void 0 ? _props$ssrState : false);
    const client = props.client instanceof TRPCUntypedClient ? props.client : getUntypedClient(props.client);
    const fns = React.useMemo(() => createUtilityFunctions({
      client,
      queryClient
    }), [client, queryClient]);
    const contextValue = React.useMemo(() => (0, import_objectSpread22.default)({
      abortOnUnmount,
      queryClient,
      client,
      ssrContext: ssrContext !== null && ssrContext !== void 0 ? ssrContext : null,
      ssrState
    }, fns), [
      abortOnUnmount,
      client,
      fns,
      queryClient,
      ssrContext,
      ssrState
    ]);
    React.useEffect(() => {
      setSSRState((state) => state ? "mounted" : false);
    }, []);
    return (0, import_jsx_runtime.jsx)(Context.Provider, {
      value: contextValue,
      children: props.children
    });
  };
  function useContext2() {
    const context = React.useContext(Context);
    if (!context) throw new Error("Unable to find tRPC Context. Did you forget to wrap your App inside `withTRPC` HoC?");
    return context;
  }
  function useSSRQueryOptionsIfNeeded(queryKey, opts) {
    var _queryClient$getQuery;
    const { queryClient, ssrState } = useContext2();
    return ssrState && ssrState !== "mounted" && ((_queryClient$getQuery = queryClient.getQueryCache().find({ queryKey })) === null || _queryClient$getQuery === void 0 ? void 0 : _queryClient$getQuery.state.status) === "error" ? (0, import_objectSpread22.default)({ retryOnMount: false }, opts) : opts;
  }
  function useQuery$1(path, input, opts) {
    var _opts$trpc, _opts$enabled, _ref, _opts$trpc$abortOnUnm, _opts$trpc2;
    const context = useContext2();
    const { abortOnUnmount, client, ssrState, queryClient, prefetchQuery } = context;
    const queryKey = getQueryKeyInternal(path, input, "query");
    const defaultOpts = queryClient.getQueryDefaults(queryKey);
    const isInputSkipToken = input === skipToken;
    if (typeof window === "undefined" && ssrState === "prepass" && (opts === null || opts === void 0 || (_opts$trpc = opts.trpc) === null || _opts$trpc === void 0 ? void 0 : _opts$trpc.ssr) !== false && ((_opts$enabled = opts === null || opts === void 0 ? void 0 : opts.enabled) !== null && _opts$enabled !== void 0 ? _opts$enabled : defaultOpts === null || defaultOpts === void 0 ? void 0 : defaultOpts.enabled) !== false && !isInputSkipToken && !queryClient.getQueryCache().find({ queryKey })) prefetchQuery(queryKey, opts);
    const ssrOpts = useSSRQueryOptionsIfNeeded(queryKey, (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, defaultOpts), opts));
    const shouldAbortOnUnmount = (_ref = (_opts$trpc$abortOnUnm = opts === null || opts === void 0 || (_opts$trpc2 = opts.trpc) === null || _opts$trpc2 === void 0 ? void 0 : _opts$trpc2.abortOnUnmount) !== null && _opts$trpc$abortOnUnm !== void 0 ? _opts$trpc$abortOnUnm : config === null || config === void 0 ? void 0 : config.abortOnUnmount) !== null && _ref !== void 0 ? _ref : abortOnUnmount;
    const hook = useQuery((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts), {}, {
      queryKey,
      queryFn: isInputSkipToken ? input : async (queryFunctionContext) => {
        const actualOpts = (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts), {}, { trpc: (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts === null || ssrOpts === void 0 ? void 0 : ssrOpts.trpc), shouldAbortOnUnmount ? { signal: queryFunctionContext.signal } : { signal: null }) });
        const result = await client.query(...getClientArgs(queryKey, actualOpts));
        if (isAsyncIterable(result)) return buildQueryFromAsyncIterable(result, queryClient, queryKey);
        return result;
      }
    }), queryClient);
    hook.trpc = useHookResult({ path });
    return hook;
  }
  function usePrefetchQuery$1(path, input, opts) {
    var _ref2, _opts$trpc$abortOnUnm2, _opts$trpc3;
    const context = useContext2();
    const queryKey = getQueryKeyInternal(path, input, "query");
    const isInputSkipToken = input === skipToken;
    const shouldAbortOnUnmount = (_ref2 = (_opts$trpc$abortOnUnm2 = opts === null || opts === void 0 || (_opts$trpc3 = opts.trpc) === null || _opts$trpc3 === void 0 ? void 0 : _opts$trpc3.abortOnUnmount) !== null && _opts$trpc$abortOnUnm2 !== void 0 ? _opts$trpc$abortOnUnm2 : config === null || config === void 0 ? void 0 : config.abortOnUnmount) !== null && _ref2 !== void 0 ? _ref2 : context.abortOnUnmount;
    usePrefetchQuery((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts), {}, {
      queryKey,
      queryFn: isInputSkipToken ? input : (queryFunctionContext) => {
        const actualOpts = { trpc: (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts === null || opts === void 0 ? void 0 : opts.trpc), shouldAbortOnUnmount ? { signal: queryFunctionContext.signal } : {}) };
        return context.client.query(...getClientArgs(queryKey, actualOpts));
      }
    }));
  }
  function useSuspenseQuery$1(path, input, opts) {
    var _ref3, _opts$trpc$abortOnUnm3, _opts$trpc4;
    const context = useContext2();
    const queryKey = getQueryKeyInternal(path, input, "query");
    const shouldAbortOnUnmount = (_ref3 = (_opts$trpc$abortOnUnm3 = opts === null || opts === void 0 || (_opts$trpc4 = opts.trpc) === null || _opts$trpc4 === void 0 ? void 0 : _opts$trpc4.abortOnUnmount) !== null && _opts$trpc$abortOnUnm3 !== void 0 ? _opts$trpc$abortOnUnm3 : config === null || config === void 0 ? void 0 : config.abortOnUnmount) !== null && _ref3 !== void 0 ? _ref3 : context.abortOnUnmount;
    const hook = useSuspenseQuery((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts), {}, {
      queryKey,
      queryFn: (queryFunctionContext) => {
        const actualOpts = (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts), {}, { trpc: (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts === null || opts === void 0 ? void 0 : opts.trpc), shouldAbortOnUnmount ? { signal: queryFunctionContext.signal } : { signal: null }) });
        return context.client.query(...getClientArgs(queryKey, actualOpts));
      }
    }), context.queryClient);
    hook.trpc = useHookResult({ path });
    return [hook.data, hook];
  }
  function useMutation$1(path, opts) {
    const { client, queryClient } = useContext2();
    const mutationKey = getMutationKeyInternal(path);
    const defaultOpts = queryClient.defaultMutationOptions(queryClient.getMutationDefaults(mutationKey));
    const hook = useMutation((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts), {}, {
      mutationKey,
      mutationFn: (input) => {
        return client.mutation(...getClientArgs([path, { input }], opts));
      },
      onSuccess(...args) {
        var _ref4, _opts$meta;
        const originalFn = () => {
          var _opts$onSuccess, _opts$onSuccess2, _defaultOpts$onSucces;
          return (_opts$onSuccess = opts === null || opts === void 0 || (_opts$onSuccess2 = opts.onSuccess) === null || _opts$onSuccess2 === void 0 ? void 0 : _opts$onSuccess2.call(opts, ...args)) !== null && _opts$onSuccess !== void 0 ? _opts$onSuccess : defaultOpts === null || defaultOpts === void 0 || (_defaultOpts$onSucces = defaultOpts.onSuccess) === null || _defaultOpts$onSucces === void 0 ? void 0 : _defaultOpts$onSucces.call(defaultOpts, ...args);
        };
        return mutationSuccessOverride({
          originalFn,
          queryClient,
          meta: (_ref4 = (_opts$meta = opts === null || opts === void 0 ? void 0 : opts.meta) !== null && _opts$meta !== void 0 ? _opts$meta : defaultOpts === null || defaultOpts === void 0 ? void 0 : defaultOpts.meta) !== null && _ref4 !== void 0 ? _ref4 : {}
        });
      }
    }), queryClient);
    hook.trpc = useHookResult({ path });
    return hook;
  }
  const initialStateIdle = {
    data: void 0,
    error: null,
    status: "idle"
  };
  const initialStateConnecting = {
    data: void 0,
    error: null,
    status: "connecting"
  };
  function useSubscription(path, input, opts) {
    var _opts$enabled2;
    const enabled = (_opts$enabled2 = opts === null || opts === void 0 ? void 0 : opts.enabled) !== null && _opts$enabled2 !== void 0 ? _opts$enabled2 : input !== skipToken;
    const queryKey = hashKey(getQueryKeyInternal(path, input, "any"));
    const { client } = useContext2();
    const optsRef = React.useRef(opts);
    React.useEffect(() => {
      optsRef.current = opts;
    });
    const [trackedProps] = React.useState(/* @__PURE__ */ new Set([]));
    const addTrackedProp = React.useCallback((key) => {
      trackedProps.add(key);
    }, [trackedProps]);
    const currentSubscriptionRef = React.useRef(null);
    const updateState = React.useCallback((callback) => {
      const prev = resultRef.current;
      const next = resultRef.current = callback(prev);
      let shouldUpdate = false;
      for (const key of trackedProps) if (prev[key] !== next[key]) {
        shouldUpdate = true;
        break;
      }
      if (shouldUpdate) setState(trackResult(next, addTrackedProp));
    }, [addTrackedProp, trackedProps]);
    const reset = React.useCallback(() => {
      var _currentSubscriptionR;
      (_currentSubscriptionR = currentSubscriptionRef.current) === null || _currentSubscriptionR === void 0 || _currentSubscriptionR.unsubscribe();
      if (!enabled) {
        updateState(() => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, initialStateIdle), {}, { reset }));
        return;
      }
      updateState(() => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, initialStateConnecting), {}, { reset }));
      const subscription = client.subscription(path.join("."), input !== null && input !== void 0 ? input : void 0, {
        onStarted: () => {
          var _optsRef$current$onSt, _optsRef$current;
          (_optsRef$current$onSt = (_optsRef$current = optsRef.current).onStarted) === null || _optsRef$current$onSt === void 0 || _optsRef$current$onSt.call(_optsRef$current);
          updateState((prev) => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, prev), {}, {
            status: "pending",
            error: null
          }));
        },
        onData: (data) => {
          var _optsRef$current$onDa, _optsRef$current2;
          (_optsRef$current$onDa = (_optsRef$current2 = optsRef.current).onData) === null || _optsRef$current$onDa === void 0 || _optsRef$current$onDa.call(_optsRef$current2, data);
          updateState((prev) => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, prev), {}, {
            status: "pending",
            data,
            error: null
          }));
        },
        onError: (error) => {
          var _optsRef$current$onEr, _optsRef$current3;
          (_optsRef$current$onEr = (_optsRef$current3 = optsRef.current).onError) === null || _optsRef$current$onEr === void 0 || _optsRef$current$onEr.call(_optsRef$current3, error);
          updateState((prev) => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, prev), {}, {
            status: "error",
            error
          }));
        },
        onConnectionStateChange: (result) => {
          updateState((prev) => {
            switch (result.state) {
              case "idle":
                return (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, prev), {}, {
                  status: result.state,
                  error: null,
                  data: void 0
                });
              case "connecting":
                return (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, prev), {}, {
                  error: result.error,
                  status: result.state
                });
              case "pending":
                return prev;
            }
          });
        },
        onComplete: () => {
          var _optsRef$current$onCo, _optsRef$current4;
          (_optsRef$current$onCo = (_optsRef$current4 = optsRef.current).onComplete) === null || _optsRef$current$onCo === void 0 || _optsRef$current$onCo.call(_optsRef$current4);
          updateState((prev) => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, prev), {}, {
            status: "idle",
            error: null,
            data: void 0
          }));
        }
      });
      currentSubscriptionRef.current = subscription;
    }, [
      client,
      queryKey,
      enabled,
      updateState
    ]);
    React.useEffect(() => {
      reset();
      return () => {
        var _currentSubscriptionR2;
        (_currentSubscriptionR2 = currentSubscriptionRef.current) === null || _currentSubscriptionR2 === void 0 || _currentSubscriptionR2.unsubscribe();
      };
    }, [reset]);
    const resultRef = React.useRef(enabled ? (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, initialStateConnecting), {}, { reset }) : (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, initialStateIdle), {}, { reset }));
    const [state, setState] = React.useState(trackResult(resultRef.current, addTrackedProp));
    return state;
  }
  function useInfiniteQuery$1(path, input, opts) {
    var _opts$trpc5, _opts$enabled3, _opts$trpc$abortOnUnm4, _opts$trpc6, _opts$initialCursor;
    const { client, ssrState, prefetchInfiniteQuery, queryClient, abortOnUnmount } = useContext2();
    const queryKey = getQueryKeyInternal(path, input, "infinite");
    const defaultOpts = queryClient.getQueryDefaults(queryKey);
    const isInputSkipToken = input === skipToken;
    if (typeof window === "undefined" && ssrState === "prepass" && (opts === null || opts === void 0 || (_opts$trpc5 = opts.trpc) === null || _opts$trpc5 === void 0 ? void 0 : _opts$trpc5.ssr) !== false && ((_opts$enabled3 = opts === null || opts === void 0 ? void 0 : opts.enabled) !== null && _opts$enabled3 !== void 0 ? _opts$enabled3 : defaultOpts === null || defaultOpts === void 0 ? void 0 : defaultOpts.enabled) !== false && !isInputSkipToken && !queryClient.getQueryCache().find({ queryKey })) prefetchInfiniteQuery(queryKey, (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, defaultOpts), opts));
    const ssrOpts = useSSRQueryOptionsIfNeeded(queryKey, (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, defaultOpts), opts));
    const shouldAbortOnUnmount = (_opts$trpc$abortOnUnm4 = opts === null || opts === void 0 || (_opts$trpc6 = opts.trpc) === null || _opts$trpc6 === void 0 ? void 0 : _opts$trpc6.abortOnUnmount) !== null && _opts$trpc$abortOnUnm4 !== void 0 ? _opts$trpc$abortOnUnm4 : abortOnUnmount;
    const hook = useInfiniteQuery((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts), {}, {
      initialPageParam: (_opts$initialCursor = opts.initialCursor) !== null && _opts$initialCursor !== void 0 ? _opts$initialCursor : null,
      persister: opts.persister,
      queryKey,
      queryFn: isInputSkipToken ? input : (queryFunctionContext) => {
        var _queryFunctionContext;
        const actualOpts = (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts), {}, { trpc: (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts === null || ssrOpts === void 0 ? void 0 : ssrOpts.trpc), shouldAbortOnUnmount ? { signal: queryFunctionContext.signal } : { signal: null }) });
        return client.query(...getClientArgs(queryKey, actualOpts, {
          pageParam: (_queryFunctionContext = queryFunctionContext.pageParam) !== null && _queryFunctionContext !== void 0 ? _queryFunctionContext : opts.initialCursor,
          direction: queryFunctionContext.direction
        }));
      }
    }), queryClient);
    hook.trpc = useHookResult({ path });
    return hook;
  }
  function usePrefetchInfiniteQuery$1(path, input, opts) {
    var _opts$trpc$abortOnUnm5, _opts$trpc7, _opts$initialCursor2;
    const context = useContext2();
    const queryKey = getQueryKeyInternal(path, input, "infinite");
    const defaultOpts = context.queryClient.getQueryDefaults(queryKey);
    const isInputSkipToken = input === skipToken;
    const ssrOpts = useSSRQueryOptionsIfNeeded(queryKey, (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, defaultOpts), opts));
    const shouldAbortOnUnmount = (_opts$trpc$abortOnUnm5 = opts === null || opts === void 0 || (_opts$trpc7 = opts.trpc) === null || _opts$trpc7 === void 0 ? void 0 : _opts$trpc7.abortOnUnmount) !== null && _opts$trpc$abortOnUnm5 !== void 0 ? _opts$trpc$abortOnUnm5 : context.abortOnUnmount;
    usePrefetchInfiniteQuery((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts), {}, {
      initialPageParam: (_opts$initialCursor2 = opts.initialCursor) !== null && _opts$initialCursor2 !== void 0 ? _opts$initialCursor2 : null,
      queryKey,
      queryFn: isInputSkipToken ? input : (queryFunctionContext) => {
        var _queryFunctionContext2;
        const actualOpts = (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts), {}, { trpc: (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts === null || ssrOpts === void 0 ? void 0 : ssrOpts.trpc), shouldAbortOnUnmount ? { signal: queryFunctionContext.signal } : {}) });
        return context.client.query(...getClientArgs(queryKey, actualOpts, {
          pageParam: (_queryFunctionContext2 = queryFunctionContext.pageParam) !== null && _queryFunctionContext2 !== void 0 ? _queryFunctionContext2 : opts.initialCursor,
          direction: queryFunctionContext.direction
        }));
      }
    }));
  }
  function useSuspenseInfiniteQuery$1(path, input, opts) {
    var _opts$trpc$abortOnUnm6, _opts$trpc8, _opts$initialCursor3;
    const context = useContext2();
    const queryKey = getQueryKeyInternal(path, input, "infinite");
    const defaultOpts = context.queryClient.getQueryDefaults(queryKey);
    const ssrOpts = useSSRQueryOptionsIfNeeded(queryKey, (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, defaultOpts), opts));
    const shouldAbortOnUnmount = (_opts$trpc$abortOnUnm6 = opts === null || opts === void 0 || (_opts$trpc8 = opts.trpc) === null || _opts$trpc8 === void 0 ? void 0 : _opts$trpc8.abortOnUnmount) !== null && _opts$trpc$abortOnUnm6 !== void 0 ? _opts$trpc$abortOnUnm6 : context.abortOnUnmount;
    const hook = useSuspenseInfiniteQuery((0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, opts), {}, {
      initialPageParam: (_opts$initialCursor3 = opts.initialCursor) !== null && _opts$initialCursor3 !== void 0 ? _opts$initialCursor3 : null,
      queryKey,
      queryFn: (queryFunctionContext) => {
        var _queryFunctionContext3;
        const actualOpts = (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts), {}, { trpc: (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, ssrOpts === null || ssrOpts === void 0 ? void 0 : ssrOpts.trpc), shouldAbortOnUnmount ? { signal: queryFunctionContext.signal } : {}) });
        return context.client.query(...getClientArgs(queryKey, actualOpts, {
          pageParam: (_queryFunctionContext3 = queryFunctionContext.pageParam) !== null && _queryFunctionContext3 !== void 0 ? _queryFunctionContext3 : opts.initialCursor,
          direction: queryFunctionContext.direction
        }));
      }
    }), context.queryClient);
    hook.trpc = useHookResult({ path });
    return [hook.data, hook];
  }
  const useQueries$1 = (queriesCallback, options) => {
    const { ssrState, queryClient, prefetchQuery, client } = useContext2();
    const proxy = createUseQueries(client);
    const queries = queriesCallback(proxy);
    if (typeof window === "undefined" && ssrState === "prepass") for (const query of queries) {
      var _queryOption$trpc;
      const queryOption = query;
      if (((_queryOption$trpc = queryOption.trpc) === null || _queryOption$trpc === void 0 ? void 0 : _queryOption$trpc.ssr) !== false && !queryClient.getQueryCache().find({ queryKey: queryOption.queryKey })) prefetchQuery(queryOption.queryKey, queryOption);
    }
    return useQueries({
      queries: queries.map((query) => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, query), {}, { queryKey: query.queryKey })),
      combine: options === null || options === void 0 ? void 0 : options.combine
    }, queryClient);
  };
  const useSuspenseQueries$1 = (queriesCallback) => {
    const { queryClient, client } = useContext2();
    const proxy = createUseQueries(client);
    const queries = queriesCallback(proxy);
    const hook = useSuspenseQueries({ queries: queries.map((query) => (0, import_objectSpread22.default)((0, import_objectSpread22.default)({}, query), {}, {
      queryFn: query.queryFn,
      queryKey: query.queryKey
    })) }, queryClient);
    return [hook.map((h) => h.data), hook];
  };
  return {
    Provider: TRPCProvider,
    createClient,
    useContext: useContext2,
    useUtils: useContext2,
    useQuery: useQuery$1,
    usePrefetchQuery: usePrefetchQuery$1,
    useSuspenseQuery: useSuspenseQuery$1,
    useQueries: useQueries$1,
    useSuspenseQueries: useSuspenseQueries$1,
    useMutation: useMutation$1,
    useSubscription,
    useInfiniteQuery: useInfiniteQuery$1,
    usePrefetchInfiniteQuery: usePrefetchInfiniteQuery$1,
    useSuspenseInfiniteQuery: useSuspenseInfiniteQuery$1
  };
}

// node_modules/.pnpm/@trpc+react-query@11.6.0_@tanstack+react-query@5.90.2_react@19.2.1__@trpc+client@11.6.0_b3a4fc388d38e7312f2de6608955b66b/node_modules/@trpc/react-query/dist/index.mjs
var React2 = __toESM(require_react(), 1);
function createHooksInternal(trpc) {
  const proxy = createReactDecoration(trpc);
  return createFlatProxy((key) => {
    if (key === "useContext" || key === "useUtils") return () => {
      const context = trpc.useUtils();
      return React2.useMemo(() => {
        return createReactQueryUtils(context);
      }, [context]);
    };
    if (trpc.hasOwnProperty(key)) return trpc[key];
    return proxy[key];
  });
}
function createTRPCReact(opts) {
  const hooks = createRootHooks(opts);
  const proxy = createHooksInternal(hooks);
  return proxy;
}
function createTRPCQueryUtils(opts) {
  const utils = createUtilityFunctions(opts);
  return createQueryUtilsProxy(utils);
}
export {
  TRPCClientError,
  TRPCUntypedClient,
  clientCallTypeToProcedureType,
  createTRPCClient,
  createTRPCClientProxy,
  createTRPCClient as createTRPCProxyClient,
  createTRPCQueryUtils,
  createTRPCReact,
  createTRPCUntypedClient,
  createWSClient,
  experimental_localLink,
  getFetch,
  getMutationKey,
  getQueryKey,
  getUntypedClient,
  httpBatchLink,
  httpBatchStreamLink,
  httpLink,
  httpSubscriptionLink,
  isFormData,
  isNonJsonSerializable,
  isOctetType,
  isTRPCClientError,
  loggerLink,
  retryLink,
  splitLink,
  unstable_httpBatchStreamLink,
  unstable_httpSubscriptionLink,
  unstable_localLink,
  wsLink
};
/*! Bundled license information:

@trpc/react-query/dist/shared-JtnEvJvB.mjs:
  (* istanbul ignore next -- @preserve *)
*/
//# sourceMappingURL=@trpc_react-query.js.map
