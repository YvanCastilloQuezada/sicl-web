from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter

OUTPUT_DIR = Path('/home/ubuntu/financial_deliverables')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_FILE = OUTPUT_DIR / 'modelo_tentativo_multi_juegos_peru.xlsx'

DARK_GREEN = '135B44'
LIGHT_GREEN = 'CFE9E0'
LIGHT_GRAY = 'E7E5E4'
BLUE = '0000FF'
BLACK = '000000'
GREEN = '008000'
WHITE = 'FFFFFF'
THIN = Side(style='thin', color='B7B7B7')
DOUBLE = Side(style='double', color='000000')
currency_fmt = '#,##0;(#,##0);-'
percent_fmt = '0.0%'

wb = Workbook()
ws = wb.active
ws.title = 'Supuestos'

def setup_sheet(sheet, title, subtitle, unit='(S/ salvo indicación contraria)'):
    sheet.sheet_view.showGridLines = False
    sheet.column_dimensions['A'].width = 20
    sheet.column_dimensions['B'].width = 20
    sheet.merge_cells('C3:G3')
    title_cell = sheet['C3']
    title_cell.value = title
    title_cell.fill = PatternFill('solid', fgColor=DARK_GREEN)
    title_cell.font = Font(color=WHITE, bold=True, size=16)
    title_cell.alignment = Alignment(horizontal='left')
    sheet['C5'] = subtitle
    sheet['C5'].font = Font(bold=True, size=11)
    sheet['C6'] = unit
    sheet['C6'].font = Font(italic=True, color='666666')
    sheet.page_setup.orientation = 'landscape'
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.print_area = 'B2:K60'
    sheet.oddFooter.center.text = f'{sheet.title} | Página &P'

def section(sheet, row, label, end_col='G'):
    sheet.merge_cells(start_row=row, start_column=3, end_row=row, end_column=ord(end_col)-64)
    cell = sheet.cell(row=row, column=3)
    cell.value = label
    cell.fill = PatternFill('solid', fgColor=LIGHT_GREEN)
    cell.font = Font(bold=True, color=BLACK)

def hardcoded(cell, value, comment_text, fmt=None):
    cell.value = value
    cell.font = Font(color=BLUE)
    cell.comment = Comment(comment_text, 'Manus AI')
    if fmt:
        cell.number_format = fmt

def formula(cell, value, fmt=None, linked=False):
    cell.value = value
    cell.font = Font(color=GREEN if linked else BLACK)
    if fmt:
        cell.number_format = fmt

def finalize(sheet):
    for col in range(3, sheet.max_column + 1):
        width = 12
        for row in range(1, sheet.max_row + 1):
            value = sheet.cell(row=row, column=col).value
            if value is not None:
                width = max(width, min(48, len(str(value)) + 2))
        sheet.column_dimensions[get_column_letter(col)].width = width

setup_sheet(ws, 'Modelo tentativo — Multi Juegos Perú', 'Inputs editables para una futura operación regulada; no representa el piloto gratuito.')
section(ws, 8, 'Escenarios de ingreso y gasto fijo', 'F')
headers = ['Concepto', 'Conservador', 'Base', 'Escala']
for idx, value in enumerate(headers, 3):
    cell = ws.cell(9, idx, value)
    cell.font = Font(bold=True)
    cell.fill = PatternFill('solid', fgColor=LIGHT_GRAY)

scenario_inputs = [
    ('Ingreso Neto de Juego mensual (IN)', 180000, 350000, 700000, 'Supuesto de planeamiento, no ingreso histórico.'),
    ('Gasto fijo mensual', 200000, 225000, 260000, 'Supuesto de planeamiento basado en el presupuesto por área.'),
]
for r, (label, low, base, scale, note) in enumerate(scenario_inputs, 10):
    ws.cell(r, 3, label)
    for c, value in enumerate([low, base, scale], 4):
        hardcoded(ws.cell(r, c), value, note, currency_fmt)

section(ws, 14, 'Tasas y parámetros editables', 'F')
parameter_rows = [
    ('Impuesto específico de juegos efectivo', 0.1176, 'Derivado: 12% sobre base luego de gasto de mantenimiento de 2% del IN. Fuente: SUNAT, consulta 24-08-2026.'),
    ('Procesamiento de pagos / IN', 0.025, 'Supuesto de planeamiento. Sustituir por cotizaciones de adquirentes y billeteras.'),
    ('Plataforma y soporte variable / IN', 0.030, 'Supuesto de planeamiento. Incluye elasticidad de nube, atención y verificación.'),
    ('Impuesto a la renta — Régimen General', 0.295, 'Fuente: SUNAT, tasa de Régimen General; consulta 24-08-2026.'),
    ('Aporte institucional de impacto / utilidad neta', 0.010, 'Política propuesta; no es obligación legal ni debe cargarse al jugador.'),
    ('Mínimo anual para destino distrital', 15000, 'Política propuesta para evitar fragmentación y asegurar trazabilidad.'),
]
for r, (label, value, note) in enumerate(parameter_rows, 15):
    ws.cell(r, 3, label)
    fmt = currency_fmt if r == 20 else percent_fmt
    hardcoded(ws.cell(r, 4), value, note, fmt)

ws['C23'] = 'Notas de modelo'
ws['C23'].font = Font(bold=True)
ws['C24'] = 'Los supuestos en azul son editables. Las fórmulas negras se calculan dentro de cada hoja; los vínculos verdes apuntan a Supuestos.'
ws.merge_cells('C24:F24')
ws['C25'] = 'El aporte social se calcula solo si la utilidad neta es positiva y no se descuenta de premios, depósitos ni billeteras de jugadores.'
ws.merge_cells('C25:F25')

budget = wb.create_sheet('Presupuesto Base')
setup_sheet(budget, 'Presupuesto mensual base', 'Envolvente de gasto fijo mensual; sustituir por nómina, contratos y cotizaciones.')
section(budget, 8, 'Gastos operativos repetitivos', 'F')
budget['C9'], budget['D9'], budget['E9'] = 'Partida', 'S/ mensuales', 'Propósito'
for cell in budget[9][2:5]:
    cell.font = Font(bold=True)
    cell.fill = PatternFill('solid', fgColor=LIGHT_GRAY)
operational = [
    ('Operación de juegos, juego responsable y prevención', 30000, 'Supervisión operativa, límites, revisiones y alertas.'),
    ('Atención al jugador y soporte extendido', 22000, 'Atención multicanal, reclamos e incidentes.'),
    ('Riesgo de pagos, fraude y contracargos', 12000, 'KYC, alertas, conciliación y prevención de abuso.'),
    ('Nube, DevSecOps y ciberseguridad', 18000, 'Infraestructura, respaldos, WAF y respuesta a incidentes.'),
    ('IA, datos y analítica operativa', 14000, 'Fraude, soporte, pronóstico de capacidad y borradores supervisados.'),
    ('Licencias de sistemas y observabilidad', 9000, 'CRM, ticketing, logs, identidad y monitoreo.'),
    ('Contenido, comunidad y educación responsable', 10000, 'Reglas, comunicación no compulsiva y contenidos.'),
    ('Marketing y adquisición responsable', 30000, 'Campañas y medición, sin incentivos por pérdidas.'),
]
for r, (label, amount, purpose) in enumerate(operational, 10):
    budget.cell(r, 3, label)
    hardcoded(budget.cell(r, 4), amount, 'Supuesto de presupuesto mensual; reemplazar por cotización o nómina.', currency_fmt)
    budget.cell(r, 5, purpose)
subtotal_op_row = 18
budget.cell(subtotal_op_row, 3, 'Subtotal operacional')
formula(budget.cell(subtotal_op_row, 4), '=SUM(D10:D17)', currency_fmt)
budget.cell(subtotal_op_row, 3).font = Font(bold=True)
budget.cell(subtotal_op_row, 4).font = Font(bold=True)

section(budget, 20, 'Gastos generales de administración y finanzas', 'F')
budget['C21'], budget['D21'], budget['E21'] = 'Partida', 'S/ mensuales', 'Propósito'
for cell in budget[21][2:5]:
    cell.font = Font(bold=True)
    cell.fill = PatternFill('solid', fgColor=LIGHT_GRAY)
admin = [
    ('Dirección, producto y recursos humanos', 25000, 'Gestión, producto, coordinación y administración de personal.'),
    ('Administración, contabilidad y finanzas', 12000, 'Contabilidad, tesorería, conciliación y presupuesto.'),
    ('Asesoría legal, regulatoria y cumplimiento', 16000, 'Privacidad, contratos, licencias, juego responsable y cumplimiento.'),
    ('Reserva de auditoría, certificación y pruebas', 18000, 'Pruebas técnicas y auditorías independientes.'),
    ('Oficina, seguros y administración corporativa', 9000, 'Pólizas, herramientas y gastos corporativos.'),
]
for r, (label, amount, purpose) in enumerate(admin, 22):
    budget.cell(r, 3, label)
    hardcoded(budget.cell(r, 4), amount, 'Supuesto de presupuesto mensual; reemplazar por contrato, póliza o nómina.', currency_fmt)
    budget.cell(r, 5, purpose)
subtotal_admin_row = 27
budget.cell(subtotal_admin_row, 3, 'Subtotal administración y finanzas')
formula(budget.cell(subtotal_admin_row, 4), '=SUM(D22:D26)', currency_fmt)
budget.cell(subtotal_admin_row, 3).font = Font(bold=True)
budget.cell(subtotal_admin_row, 4).font = Font(bold=True)
budget.cell(29, 3, 'Total fijo mensual base')
formula(budget.cell(29, 4), '=D18+D27', currency_fmt)
for cell in [budget.cell(29, 3), budget.cell(29, 4)]:
    cell.font = Font(bold=True)
    cell.border = Border(top=THIN, bottom=DOUBLE)
budget['C31'] = 'Control'
budget['D31'] = 'El total debe coincidir con el supuesto Base de la hoja Supuestos.'
budget['C32'] = 'Diferencia'
formula(budget['D32'], "=D29-Supuestos!E11", currency_fmt, linked=True)

scenario = wb.create_sheet('Escenarios')
setup_sheet(scenario, 'Escenarios de utilidad neta', 'Fórmulas mensuales; Conservador, Base y Escala.')
for c, label in enumerate(['Concepto', 'Conservador', 'Base', 'Escala'], 3):
    scenario.cell(8, c, label)
    scenario.cell(8, c).font = Font(bold=True)
    scenario.cell(8, c).fill = PatternFill('solid', fgColor=LIGHT_GRAY)
lines = [
    ('Ingreso Neto de Juego (IN)', ['=Supuestos!D10', '=Supuestos!E10', '=Supuestos!F10'], currency_fmt, True),
    ('Impuesto específico de juegos', ['=-D9*Supuestos!$D$15', '=-E9*Supuestos!$D$15', '=-F9*Supuestos!$D$15'], currency_fmt, False),
    ('Procesamiento de pagos', ['=-D9*Supuestos!$D$16', '=-E9*Supuestos!$D$16', '=-F9*Supuestos!$D$16'], currency_fmt, False),
    ('Plataforma y soporte variable', ['=-D9*Supuestos!$D$17', '=-E9*Supuestos!$D$17', '=-F9*Supuestos!$D$17'], currency_fmt, False),
    ('Gastos fijos', ['=-Supuestos!D11', '=-Supuestos!E11', '=-Supuestos!F11'], currency_fmt, True),
    ('Utilidad antes de renta', ['=SUM(D9:D13)', '=SUM(E9:E13)', '=SUM(F9:F13)'], currency_fmt, False),
    ('Impuesto a la renta', ['=-MAX(0,D14*Supuestos!$D$18)', '=-MAX(0,E14*Supuestos!$D$18)', '=-MAX(0,F14*Supuestos!$D$18)'], currency_fmt, False),
    ('Utilidad neta', ['=D14+D15', '=E14+E15', '=F14+F15'], currency_fmt, False),
    ('Aporte institucional social (1%)', ['=-MAX(0,D16*Supuestos!$D$19)', '=-MAX(0,E16*Supuestos!$D$19)', '=-MAX(0,F16*Supuestos!$D$19)'], currency_fmt, False),
    ('Utilidad retenida luego del aporte', ['=D16+D17', '=E16+E17', '=F16+F17'], currency_fmt, False),
]
for r, (label, forms, fmt, linked) in enumerate(lines, 9):
    scenario.cell(r, 3, label)
    for c, expression in enumerate(forms, 4):
        formula(scenario.cell(r, c), expression, fmt, linked=linked and r in [9, 13])
    if r in [14, 16, 18]:
        for c in range(3, 7):
            scenario.cell(r, c).font = Font(bold=True, color=GREEN if c > 3 and linked else BLACK)
            scenario.cell(r, c).border = Border(top=THIN)

section(scenario, 21, 'Punto de equilibrio del caso base', 'F')
scenario['C22'] = 'Margen de contribución después de cargos variables'
formula(scenario['D22'], '=1-Supuestos!$D$15-Supuestos!$D$16-Supuestos!$D$17', percent_fmt)
scenario['C23'] = 'Ingreso Neto de Juego de equilibrio'
formula(scenario['D23'], '=Supuestos!E11/D22', currency_fmt)
scenario['C24'] = 'Lectura'
scenario['D24'] = 'El aporte social es cero si la utilidad neta no es positiva.'

impact = wb.create_sheet('Impacto Territorial')
setup_sheet(impact, 'Aporte social territorial', 'Propuesta de política; no corresponde al piloto gratuito.')
section(impact, 8, 'Regla de activación y cálculo', 'F')
impact['C9'], impact['D9'], impact['E9'], impact['F9'] = 'Concepto', 'Conservador', 'Base', 'Escala'
for cell in impact[9][2:6]:
    cell.font = Font(bold=True)
    cell.fill = PatternFill('solid', fgColor=LIGHT_GRAY)
impact['C10'] = 'Aporte mensual de impacto'
for c, ref in enumerate(['=ABS(Escenarios!D17)', '=ABS(Escenarios!E17)', '=ABS(Escenarios!F17)'], 4):
    formula(impact.cell(10, c), ref, currency_fmt, linked=True)
impact['C11'] = 'Aporte anual de impacto'
for c in range(4, 7):
    formula(impact.cell(11, c), f'={get_column_letter(c)}10*12', currency_fmt)
impact['C12'] = '¿Alcanza mínimo para distrito?'
for c in range(4, 7):
    formula(impact.cell(12, c), f'=IF({get_column_letter(c)}11>=Supuestos!$D$20,"Sí","No; acumular a fondo regional")')
impact['C14'] = 'Política de fondos'
impact['D14'] = 'Hasta 1% de utilidad neta después de renta; 100% del aporte comprometido se destina al receptor. Auditoría y administración salen de gasto corporativo.'
impact.merge_cells('D14:F14')

section(impact, 17, 'Gobernanza territorial recomendada', 'F')
policy_rows = [
    ('Entidad inicial', 'Usar receptor existente calificado; evaluar asociación independiente solo cuando el fondo sea material y recurrente.'),
    ('Municipalidades', 'Usarlas solo en proyectos de escala, con expediente, aceptación y documentación correspondiente.'),
    ('Criterio de destino', 'Domicilio verificado voluntariamente del jugador adulto, nunca monto apostado, perdido o ganado.'),
    ('Rendición', 'Publicar cada trimestre: utilidad neta elegible, aporte aprobado, receptor, comprobante, avance y resultado.'),
    ('Premios', 'No se deduce ningún importe de premios, depósitos ni billeteras. Toda donación del ganador es opt-in separado.'),
]
for r, (label, detail) in enumerate(policy_rows, 18):
    impact.cell(r, 3, label)
    impact.cell(r, 3).font = Font(bold=True)
    impact.cell(r, 4, detail)
    impact.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)

sources = wb.create_sheet('Fuentes y límites')
setup_sheet(sources, 'Fuentes y límites', 'Fuentes regulatorias consultadas y advertencias de uso.')
section(sources, 8, 'Fuentes', 'F')
source_rows = [
    ('Impuesto específico', 'SUNAT — Impuesto a los Juegos a Distancia y Apuestas Deportivas', 'https://orientacion.sunat.gob.pe/impuesto-a-los-juegos'),
    ('Impuesto a la renta', 'SUNAT — Tasa del Impuesto', 'https://orientacion.sunat.gob.pe/03-tasa-del-impuesto'),
    ('Autorización y certificación', 'Ley N.º 31557 — El Peruano', 'https://busquedas.elperuano.pe/dispositivo/NL/2095517-1'),
    ('Receptores de donación', 'SUNAT — Calificación como entidad perceptora', 'https://www.gob.pe/30791-solicitar-la-calificacion-como-entidad-perceptora-de-donaciones-en-la-sunat'),
    ('Municipalidades', 'gob.pe — Cómo aprobar donaciones en municipalidades', 'https://www.gob.pe/12286-como-aprobar-donaciones-en-las-municipalidades'),
]
for r, (subject, source, url) in enumerate(source_rows, 9):
    sources.cell(r, 3, subject)
    sources.cell(r, 4, source)
    sources.cell(r, 5, url)
    sources.cell(r, 5).hyperlink = url
    sources.cell(r, 5).style = 'Hyperlink'
section(sources, 16, 'Límites de interpretación', 'F')
limitations = [
    'El modelo es una hipótesis de planeamiento en PEN, sin ingresos históricos ni cotizaciones vinculantes.',
    'No incluye IGV, ISC, retenciones, deuda, capital de trabajo, depreciación ni tratamiento fiscal específico de aportes sociales.',
    'No presupone que Multi Juegos Perú tenga autorización, entidad legal constituida o permiso para aceptar dinero real.',
    'El uso de IA debe ser supervisado por personas y no puede decidir resultados de juego ni publicar mercados sensibles automáticamente.',
]
for r, text in enumerate(limitations, 17):
    sources.cell(r, 3, f'{r-16}.')
    sources.cell(r, 4, text)
    sources.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)

for sheet in wb.worksheets:
    finalize(sheet)
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical='top', wrap_text=True)

wb.calculation.fullCalcOnLoad = True
wb.calculation.forceFullCalc = True
wb.save(OUTPUT_FILE)
print(OUTPUT_FILE)
