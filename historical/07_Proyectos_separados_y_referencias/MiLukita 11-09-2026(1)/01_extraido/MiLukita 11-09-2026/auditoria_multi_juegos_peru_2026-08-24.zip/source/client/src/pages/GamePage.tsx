import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import PilotLayout from "@/components/PilotLayout";
import { games, getGame, volumeBenefits } from "@/data/games";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Check, CircleHelp, Clock3, Crown, LockKeyhole, Minus, Plus, Sparkles, TicketCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { toast } from "sonner";

const cardRanks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

export default function GamePage() {
  const [, params] = useRoute("/juegos/:game");
  const game = getGame(params?.game);
  const { isAuthenticated } = useAuth();
  const roundsQuery = trpc.games.rounds.useQuery();
  const liveRound = roundsQuery.data?.find((round) => round.gameType === game.key && round.state === "open");
  const latestSettledRound = roundsQuery.data?.find((round) => round.gameType === game.key && round.state === "settled");
  const [selected, setSelected] = useState<number[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [spinning, setSpinning] = useState(false);
  const [ticketReceipt, setTicketReceipt] = useState<{ publicId: string; ticketHash: string; virtualCost: number } | null>(null);

  const tier = useMemo(() => [...volumeBenefits].reverse().find((benefit) => quantity >= benefit.minimum) ?? volumeBenefits[0], [quantity]);
  const subtotal = game.price * quantity;
  const total = Math.round(subtotal * (1 - tier.discount / 100));
  const reserveTicket = trpc.games.reserveTicket.useMutation({
    onSuccess: (ticket) => {
      setSubmitted(true);
      setTicketReceipt(ticket);
      toast.success("Boleto ficticio confirmado", { description: `${ticket.publicId} · saldo virtual: ${ticket.balanceAfter} créditos.` });
      roundsQuery.refetch();
    },
    onError: (error) => toast.error("No se pudo reservar el boleto", { description: error.message }),
  });

  const choose = (number: number) => {
    if (game.key === "bingo") {
      setSelected([number]);
      return;
    }
    setSelected((current) => {
      if (current.includes(number)) return current.filter((value) => value !== number);
      if (current.length >= game.pickLimit) return current;
      return [...current, number].sort((a, b) => a - b);
    });
  };

  const quickPick = () => {
    const pool = Array.from({ length: game.numberRange }, (_, index) => game.key === "ruleta" ? index : index + 1);
    const picks: number[] = [];
    while (picks.length < game.pickLimit) {
      const next = pool[Math.floor(Math.random() * pool.length)];
      if (!picks.includes(next)) picks.push(next);
    }
    setSelected(picks.sort((a, b) => a - b));
  };

  const submitTicket = () => {
    if (selected.length !== game.pickLimit) {
      toast.error(`Completa tu selección: ${game.pickLimit === 1 ? "elige una opción" : `elige ${game.pickLimit} números`}.`);
      return;
    }
    if (!isAuthenticated) {
      toast.message("Inicia sesión para reservar", { description: "La autenticación protege tu billetera virtual, historial y boleto ficticio." });
      return;
    }
    if (!liveRound) {
      toast.message("La ronda conectada aún no está abierta", { description: "Un operador debe crear y publicar la ronda desde el panel de operación." });
      return;
    }
    reserveTicket.mutate({
      roundPublicId: liveRound.publicId,
      picks: selected,
      quantity,
      idempotencyKey: `ticket-${liveRound.publicId}-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    });
  };

  const previewSpin = () => {
    setSpinning(true);
    window.setTimeout(() => setSpinning(false), 1050);
  };

  return (
    <PilotLayout>
      <main className="container py-8 sm:py-12">
        <div className="mb-8 flex flex-wrap items-center gap-2">
          {games.map((item) => (
            <Link key={item.key} href={`/juegos/${item.key}`} className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${item.key === game.key ? "border-emerald-300/50 bg-emerald-300/15 text-emerald-100" : "border-white/10 bg-white/4 text-slate-300 hover:bg-white/8"}`}>
              {item.name}
            </Link>
          ))}
        </div>

        <section className="grid gap-7 lg:grid-cols-[1.4fr_0.8fr]">
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#0c2118] p-5 shadow-2xl shadow-black/30 sm:p-8">
            <div className="absolute -right-16 -top-12 h-52 w-52 rounded-full bg-emerald-400/10 blur-3xl" />
            <div className="relative flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="eyebrow">{game.eyebrow}</p>
                <h1 className="font-display mt-2 text-4xl text-white sm:text-5xl">{game.name}</h1>
                <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300 sm:text-base">{game.description}</p>
              </div>
              <Badge className="border border-cyan-200/20 bg-cyan-300/10 px-3 py-1.5 text-cyan-100 hover:bg-cyan-300/10"><Clock3 className="mr-1.5 h-3.5 w-3.5" /> Cierra en {game.closesIn}</Badge>
            </div>

            <div className="relative mt-8 rounded-2xl border border-white/10 bg-black/20 p-5 sm:p-6">
              <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-bold text-white">1. Arma tu participación</p>
                  <p className="mt-1 text-xs text-slate-400">{game.key === "bingo" ? "Selecciona una cartilla virtual." : game.key === "cartas" ? "Elige tres rangos de carta diferentes." : `Elige ${game.pickLimit === 1 ? "una opción" : `${game.pickLimit} números`}.`}</p>
                </div>
                <Button variant="outline" onClick={quickPick} className="border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"><Sparkles className="mr-2 h-4 w-4 text-amber-200" />Selección rápida</Button>
              </div>

              <div className={`grid gap-2 ${game.key === "bingo" ? "grid-cols-1 sm:grid-cols-3" : game.key === "cartas" ? "grid-cols-4 sm:grid-cols-7" : "grid-cols-6 sm:grid-cols-7"}`}>
                {Array.from({ length: game.numberRange }, (_, index) => game.key === "ruleta" ? index : index + 1).map((number) => {
                  const active = selected.includes(number);
                  return (
                    <button
                      key={number}
                      type="button"
                      onClick={() => choose(number)}
                      className={`${game.key === "bingo" ? "h-20 rounded-xl px-4 text-left" : game.key === "cartas" ? "aspect-[3/4] rounded-xl" : "aspect-square rounded-xl"} grid place-items-center border text-sm font-black transition ${active ? "border-amber-200 bg-amber-200 text-[#152415] shadow-lg shadow-amber-200/10" : game.key === "cartas" ? "border-rose-200/25 bg-gradient-to-br from-rose-300/15 to-amber-200/10 text-rose-100 hover:border-amber-200/60" : "border-white/10 bg-white/5 text-slate-200 hover:border-emerald-300/50 hover:bg-emerald-300/10"}`}
                    >
                      {game.key === "bingo" ? <span>Cartilla {String(number).padStart(2, "0")}</span> : game.key === "cartas" ? <span className="font-display text-2xl">{cardRanks[number - 1]}</span> : number}
                    </button>
                  );
                })}
              </div>
              <div className="mt-5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                <CircleHelp className="h-4 w-4 text-emerald-300" />
                Selección: <span className="font-bold text-white">{selected.length ? selected.map((value) => game.key === "cartas" ? cardRanks[value - 1] : value).join(" · ") : "pendiente"}</span>
                <span className="text-slate-500">· La animación solo mostrará el resultado cerrado por servidor.</span>
              </div>
            </div>
            <div className="relative mt-5 grid gap-3 sm:grid-cols-3">
              {game.key === "ruleta" ? <div className="rounded-2xl border border-amber-200/15 bg-amber-200/5 p-4 sm:col-span-3"><p className="text-xs font-bold uppercase tracking-[0.12em] text-amber-200">Animación desacoplada</p><div className="mt-3 flex items-center gap-4"><button type="button" onClick={previewSpin} className={`grid h-16 w-16 place-items-center rounded-full border-4 border-amber-200/70 bg-[conic-gradient(#e8bd5b_0_9%,#132c20_9%_18%,#c74343_18%_27%,#132c20_27%_36%,#e8bd5b_36%_45%,#132c20_45%_54%,#c74343_54%_63%,#132c20_63%_72%,#e8bd5b_72%_81%,#132c20_81%)] shadow-lg shadow-amber-200/15 ${spinning ? "animate-[spin_1s_cubic-bezier(0.23,1,0.32,1)]" : ""}`} aria-label="Reproducir animación de ruleta"><span className="rounded-full bg-[#0a1812] px-2 py-1 text-xs font-black text-white">{latestSettledRound?.resultJson ? JSON.parse(latestSettledRound.resultJson).number : "?"}</span></button><p className="text-sm leading-6 text-slate-300">Pulsa la rueda para reproducir la animación. El giro visual no decide nada: al cerrarse una ronda, reproduce únicamente el resultado del servidor.</p></div></div> : null}
              {game.key === "jackpot" ? <div className="rounded-2xl border border-amber-200/15 bg-amber-200/5 p-4 sm:col-span-3"><p className="text-xs font-bold uppercase tracking-[0.12em] text-amber-200">Pozo virtual progresivo</p><p className="font-display mt-1 text-4xl text-white">{(liveRound?.jackpotPoolCredits ?? 18400).toLocaleString("es-PE")} cr.</p><p className="mt-2 text-xs leading-5 text-slate-400">El 35% del costo virtual de cada boleto confirmado incrementa el pozo de esta ronda. No tiene valor monetario.</p></div> : null}
              {game.key === "bingo" ? <div className="rounded-2xl border border-cyan-200/15 bg-cyan-200/5 p-4 sm:col-span-3"><p className="text-xs font-bold uppercase tracking-[0.12em] text-cyan-200">Cartilla y llamados verificables</p>{latestSettledRound?.resultJson ? <div className="mt-3"><p className="text-sm text-white">Cartilla ganadora: <strong>{JSON.parse(latestSettledRound.resultJson).winningCartilla}</strong></p><div className="mt-3 flex flex-wrap gap-2">{JSON.parse(latestSettledRound.resultJson).calls.map((call: number) => <span key={call} className="grid h-8 w-8 place-items-center rounded-full border border-cyan-200/25 bg-cyan-200/10 text-xs font-bold text-cyan-50">{call}</span>)}</div><p className="mt-3 text-xs leading-5 text-cyan-100/75">La condición de victoria se cumple cuando la cartilla seleccionada coincide con la cartilla ganadora publicada por el servidor.</p></div> : <p className="mt-2 text-sm leading-6 text-slate-300">La cartilla ganadora y los 15 llamados se publican tras el cierre. Línea y cartón se liquidan como premio virtual de la cartilla ganadora.</p>}</div> : null}
              {game.key === "loteria" && ticketReceipt ? <div className="rounded-2xl border border-emerald-300/25 bg-emerald-300/10 p-4 sm:col-span-3"><p className="text-xs font-bold uppercase tracking-[0.12em] text-emerald-200">Comprobante virtual</p><p className="mt-1 font-mono text-sm text-white">{ticketReceipt.publicId}</p><p className="mt-2 break-all text-[11px] text-emerald-100/75">Hash: {ticketReceipt.ticketHash}</p></div> : null}
              {game.key === "cartas" ? <div className="rounded-2xl border border-rose-200/20 bg-rose-300/5 p-4 sm:col-span-3"><p className="text-xs font-bold uppercase tracking-[0.12em] text-rose-100">Tabla Trío 13 · RTP virtual 86.89%</p><div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs"><div className="rounded-xl bg-black/20 p-3"><strong className="block text-lg text-white">3</strong><span className="text-slate-400">coincidencias · 700 cr.</span></div><div className="rounded-xl bg-black/20 p-3"><strong className="block text-lg text-white">2</strong><span className="text-slate-400">coincidencias · 37 cr.</span></div><div className="rounded-xl bg-black/20 p-3"><strong className="block text-lg text-white">1</strong><span className="text-slate-400">coincidencia · 5 cr.</span></div></div><p className="mt-3 text-xs leading-5 text-rose-100/75">La baraja se genera desde la semilla comprometida; la animación solo representa el resultado ya cerrado por el servidor.</p></div> : null}
            </div>
          </div>

          <aside className="space-y-5">
            <div className="rounded-[2rem] border border-amber-200/15 bg-gradient-to-b from-[#262010] to-[#111b14] p-6 shadow-xl shadow-black/20">
              <div className="flex items-center justify-between"><p className="text-sm font-bold text-white">2. Ajusta tus boletos</p><Crown className="h-5 w-5 text-amber-200" /></div>
              <div className="mt-6 flex items-center justify-between rounded-2xl border border-white/10 bg-black/20 p-2">
                <Button size="icon" variant="ghost" onClick={() => setQuantity((value) => Math.max(1, value - 1))} className="text-white hover:bg-white/10 hover:text-white"><Minus className="h-4 w-4" /></Button>
                <div className="text-center"><p className="text-2xl font-black text-white">{quantity}</p><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">boletos ficticios</p></div>
                <Button size="icon" variant="ghost" onClick={() => setQuantity((value) => Math.min(10, value + 1))} className="text-white hover:bg-white/10 hover:text-white"><Plus className="h-4 w-4" /></Button>
              </div>

              <div className="mt-5 space-y-3">
                {volumeBenefits.map((benefit) => (
                  <div key={benefit.minimum} className={`flex items-center justify-between rounded-xl border px-3 py-2.5 text-xs ${tier.minimum === benefit.minimum ? "border-emerald-300/40 bg-emerald-300/10 text-emerald-50" : "border-white/8 bg-white/3 text-slate-400"}`}>
                    <span className="font-semibold">{benefit.label} <span className="font-normal">· {benefit.note}</span></span>
                    <span className="font-black">{benefit.discount ? `−${benefit.discount}%` : "sin descuento"} · {benefit.multiplier}</span>
                  </div>
                ))}
              </div>

              <div className="mt-6 space-y-2 border-t border-white/10 pt-5 text-sm">
                <div className="flex justify-between text-slate-300"><span>Precio virtual</span><span>{subtotal} cr.</span></div>
                <div className="flex justify-between text-emerald-200"><span>Beneficio piloto</span><span>−{tier.discount}%</span></div>
                <div className="flex justify-between pt-2 text-base font-black text-white"><span>Total</span><span>{total} créditos</span></div>
              </div>
              <Button disabled={reserveTicket.isPending} onClick={submitTicket} className="gold-button mt-6 w-full"><TicketCheck className="mr-2 h-4 w-4" />{reserveTicket.isPending ? "Reservando…" : "Reservar boleto ficticio"}</Button>
              <p className="mt-3 flex gap-2 text-[11px] leading-5 text-slate-400"><LockKeyhole className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-300" />No se cobra dinero, no se procesa Yape y no existen retiros en este piloto.</p>
            </div>

            {submitted ? <div className="rounded-2xl border border-emerald-300/30 bg-emerald-300/10 p-5 text-sm text-emerald-50"><div className="flex items-center gap-2 font-bold"><Check className="h-4 w-4" />Participación de prueba preparada</div><p className="mt-2 leading-6 text-emerald-100/80">Al cerrar la ronda, el expediente público mostrará hash, semilla, reglas y resultado reproducible.</p></div> : null}
          </aside>
        </section>
      </main>
    </PilotLayout>
  );
}
