import PilotLayout from "@/components/PilotLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { CircleUserRound, Clock3, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function Profile() {
  const { user, isAuthenticated } = useAuth();
  const summaryQuery = trpc.wallet.summary.useQuery(undefined, { enabled: isAuthenticated });
  const roleLabel = user?.role === "admin" ? "Operador" : "Jugador";

  return (
    <PilotLayout>
      <main className="container py-9 sm:py-14">
        <section className="overflow-hidden rounded-[2rem] border border-emerald-300/15 bg-[radial-gradient(circle_at_80%_10%,rgba(242,194,96,0.18),transparent_30%),#0a1e16] p-6 sm:p-10">
          <Badge className="border border-emerald-300/25 bg-emerald-300/10 text-emerald-100 hover:bg-emerald-300/10"><CircleUserRound className="mr-1.5 h-3.5 w-3.5" /> Perfil del piloto</Badge>
          <div className="mt-6 grid gap-7 lg:grid-cols-[1fr_auto] lg:items-end"><div><h1 className="font-display text-4xl text-white sm:text-6xl">{isAuthenticated ? `Hola, ${user?.name ?? "jugador"}.` : "Tu perfil, a tu ritmo."}</h1><p className="mt-4 max-w-2xl text-sm leading-7 text-slate-300">El perfil conserva tu historial de créditos virtuales, tus límites de uso y tu región del piloto. Nada de este espacio procesa dinero real ni permite retiros.</p></div>{isAuthenticated ? <div className="rounded-2xl border border-amber-200/20 bg-amber-200/8 p-5"><p className="text-xs font-bold uppercase tracking-[0.12em] text-amber-100">Rol activo</p><p className="font-display mt-1 text-3xl text-white">{roleLabel}</p></div> : <Button onClick={() => startLogin()} className="gold-button">Ingresar al piloto</Button>}</div>
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-3"><div className="rounded-[2rem] border border-white/10 bg-[#0a1b14] p-6"><ShieldCheck className="h-5 w-5 text-emerald-300" /><h2 className="font-display mt-5 text-3xl text-white">Cuenta protegida</h2><p className="mt-3 text-sm leading-6 text-slate-300">Autenticación y rol diferenciado para jugar u operar. Los movimientos del piloto quedan registrados en el historial.</p></div><div className="rounded-[2rem] border border-cyan-200/15 bg-[#0b2025] p-6"><Clock3 className="h-5 w-5 text-cyan-200" /><h2 className="font-display mt-5 text-3xl text-white">Uso responsable</h2><p className="mt-3 text-sm leading-6 text-slate-300">Límite actual: <span className="font-bold text-cyan-100">{summaryQuery.data?.settings.sessionLimitMinutes ?? 60} minutos</span>. Las pausas voluntarias se configuran desde tu billetera.</p><Link href="/billetera" className="mt-5 inline-flex text-sm font-bold text-cyan-100 hover:text-white">Configurar límites →</Link></div><div className="rounded-[2rem] border border-amber-200/15 bg-[#211c10] p-6"><Sparkles className="h-5 w-5 text-amber-200" /><h2 className="font-display mt-5 text-3xl text-white">Región piloto</h2><p className="mt-3 text-sm leading-6 text-slate-300">Configuración inicial: <span className="font-bold text-amber-100">{summaryQuery.data?.settings.countryCode ?? "PE"}</span>. La expansión a Sudamérica se habilitará por país y política.</p></div></section>

        <section className="mt-8 rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 sm:p-8"><p className="eyebrow">Acceso directo a modalidades</p><div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[{ label: "Ruleta", href: "/juegos/ruleta" }, { label: "Jackpot", href: "/juegos/jackpot" }, { label: "Bingo", href: "/juegos/bingo" }, { label: "Lotería", href: "/juegos/loteria" }].map((game) => <Link key={game.href} href={game.href} className="rounded-2xl border border-white/10 bg-black/15 px-5 py-4 text-sm font-bold text-white transition hover:border-emerald-300/35 hover:bg-emerald-300/10">{game.label} <span className="float-right text-emerald-300">→</span></Link>)}</div></section>
      </main>
    </PilotLayout>
  );
}
