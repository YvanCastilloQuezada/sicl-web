export type GameKey = "ruleta" | "jackpot" | "bingo" | "loteria" | "cartas";

export type GameDefinition = {
  key: GameKey;
  name: string;
  eyebrow: string;
  description: string;
  price: number;
  pickLimit: number;
  numberRange: number;
  prize: string;
  color: string;
  roundId: string;
  closesIn: string;
};

export const games: GameDefinition[] = [
  {
    key: "ruleta",
    name: "Ruleta",
    eyebrow: "Giro de precisión",
    description: "Elige una casilla y acompaña un giro de servidor con evidencia pública.",
    price: 20,
    pickLimit: 1,
    numberRange: 37,
    prize: "Hasta 360 créditos virtuales",
    color: "from-cyan-300 via-emerald-300 to-yellow-200",
    roundId: "RP-R-0142",
    closesIn: "04:12",
  },
  {
    key: "jackpot",
    name: "Jackpot",
    eyebrow: "Bóveda de la semana",
    description: "Construye una combinación de cinco posiciones para competir por el pozo virtual.",
    price: 45,
    pickLimit: 5,
    numberRange: 20,
    prize: "Pozo virtual: 18 400 créditos",
    color: "from-yellow-200 via-amber-400 to-orange-300",
    roundId: "RP-J-0048",
    closesIn: "12:35",
  },
  {
    key: "bingo",
    name: "Bingo",
    eyebrow: "Cartilla en vivo",
    description: "Selecciona una cartilla virtual y sigue los llamados de una ronda transparente.",
    price: 35,
    pickLimit: 1,
    numberRange: 3,
    prize: "Línea y cartón virtual",
    color: "from-fuchsia-200 via-pink-300 to-violet-300",
    roundId: "RP-B-0086",
    closesIn: "18:09",
  },
  {
    key: "loteria",
    name: "Lotería",
    eyebrow: "Seis números, una ronda",
    description: "Escoge seis números y compara tu boleto con el resultado verificable de la ronda.",
    price: 25,
    pickLimit: 6,
    numberRange: 49,
    prize: "Hasta 9 000 créditos virtuales",
    color: "from-blue-200 via-sky-300 to-cyan-200",
    roundId: "RP-L-0311",
    closesIn: "09:46",
  },
  {
    key: "cartas",
    name: "Trío 13",
    eyebrow: "Cartas de precisión",
    description: "Elige tres rangos entre trece; el servidor revela tres cartas sin reemplazo y publica la evidencia verificable.",
    price: 10,
    pickLimit: 3,
    numberRange: 13,
    prize: "Hasta 700 créditos virtuales",
    color: "from-rose-200 via-amber-300 to-emerald-200",
    roundId: "RP-C-0001",
    closesIn: "07:20",
  },
];

export const volumeBenefits = [
  { minimum: 1, label: "Explora", discount: 0, multiplier: "x1.00", note: "1–2 participaciones" },
  { minimum: 3, label: "Constancia", discount: 6, multiplier: "x1.10", note: "3–5 participaciones" },
  { minimum: 6, label: "Impulso", discount: 12, multiplier: "x1.25", note: "6 o más participaciones" },
];

export const pilotProof = {
  roundId: "RP-R-0141",
  game: "Ruleta",
  ruleset: "ruleta-v1.0.0",
  serverSeedHash: "a64c2ed1c6d6e0e696e5a89ea8d7930a3f4790ae1b30d032dc8bc8f60f5d08e4",
  revealedSeed: "rp-pilot-0141-emerald-orbit",
  publicSeed: "PILOTO-2026-ROUND-0141",
  ticketSetHash: "3520609a154a13bfcb83666df361d78b77b1ffd805a0c03852f0b6f5422367f4",
  result: "17 negro",
  algorithm: "HMAC-SHA-256 + rechazo uniforme v1",
};

export function getGame(key: string | undefined) {
  return games.find((game) => game.key === key) ?? games[0];
}
