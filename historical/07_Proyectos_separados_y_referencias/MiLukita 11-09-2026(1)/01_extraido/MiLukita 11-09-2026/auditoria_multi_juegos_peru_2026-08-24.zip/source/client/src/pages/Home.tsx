import PilotLayout from "@/components/PilotLayout";
import { Button } from "@/components/ui/button";
import { games, volumeBenefits } from "@/data/games";
import { ArrowRight, BadgeCheck, CircleDollarSign, Crown, Gamepad2, Gift, ShieldCheck, Sparkles, Trophy } from "lucide-react";
import { Link } from "wouter";

/**
 * All content in this page are only for example, replace with your own feature implementation
 * When building pages, remember your instructions in Frontend Workflow, Frontend Best Practices, Design Guide and Common Pitfalls
 */
export default function Home() {
  return (
    <PilotLayout>
      <main>
        <section className="hero-shell relative isolate overflow-hidden">
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(4,13,10,0.98)_0%,rgba(4,13,10,0.90)_35%,rgba(4,13,10,0.20)_72%,rgba(4,13,10,0.65)_100%)]" />
          <div className="container relative grid min-h-[620px] items-center py-14 sm:py-20 lg:min-h-[680px]">
            <div className="max-w-2xl">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-200/20 bg-emerald-300/10 px-4 py-2 text-xs font-bold text-emerald-100"><Sparkles className="h-3.5 w-3.5 text-amber-200" /> EXPERIENCIA PILOTO · PERÚ Y SUDAMÉRICA</div>
              <h1 className="font-display text-5xl leading-[0.95] tracking-tight text-white sm:text-7xl lg:text-8xl">Juega con estilo.<br /><span className="text-gradient-gold">Verifica con confianza.</span></h1>
              <p className="mt-7 max-w-xl text-base leading-7 text-slate-200 sm:text-lg">Cuatro experiencias de juego en un solo portal: Ruleta, Jackpot, Bingo y Lotería. Todo funciona con créditos virtuales, reglas visibles y sorteos diseñados para comprobarse.</p>
              <div className="mt-8 flex flex-wrap gap-3"><Link href="/juegos/ruleta"><Button size="lg" className="gold-button px-6">Explorar juegos <ArrowRight className="ml-2 h-4 w-4" /></Button></Link><Link href="/verificar"><Button size="lg" variant="outline" className="border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"><ShieldCheck className="mr-2 h-4 w-4 text-emerald-300" />Verificar un sorteo</Button></Link></div>
              <div className="mt-10 grid max-w-xl grid-cols-3 gap-3 border-t border-white/10 pt-6"><div><p className="font-display text-3xl text-white">04</p><p className="mt-1 text-xs text-slate-400">modalidades</p></div><div><p className="font-display text-3xl text-white">100%</p><p className="mt-1 text-xs text-slate-400">virtual</p></div><div><p className="font-display text-3xl text-white">0</p><p className="mt-1 text-xs text-slate-400">retiros</p></div></div>
            </div>
          </div>
        </section>

        <section className="container py-16 sm:py-24">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="eyebrow">Elige tu momento</p><h2 className="font-display mt-2 text-4xl text-white sm:text-5xl">Un paquete, cuatro formas de jugar.</h2></div><p className="max-w-sm text-sm leading-6 text-slate-400">Cada modalidad conserva reglas transparentes, selección guiada y un enlace directo a su verificación.</p></div>
          <div className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-4">{games.map((game, index) => <Link key={game.key} href={`/juegos/${game.key}`} className="game-card group"><div className={`mb-8 h-1 w-16 rounded-full bg-gradient-to-r ${game.color}`} /><p className="text-xs font-bold uppercase tracking-[0.14em] text-emerald-200/70">0{index + 1} · {game.eyebrow}</p><h3 className="font-display mt-3 text-3xl text-white">{game.name}</h3><p className="mt-3 min-h-16 text-sm leading-6 text-slate-300">{game.description}</p><div className="mt-7 border-t border-white/10 pt-4"><p className="text-xs text-slate-500">Ronda {game.roundId} · cierre {game.closesIn}</p><div className="mt-3 flex items-center justify-between text-sm font-bold text-white"><span>{game.price} cr. virtuales</span><ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></div></div></Link>)}</div>
        </section>

        <section className="border-y border-white/8 bg-[#0a1c15] py-16 sm:py-24"><div className="container grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-center"><div><p className="eyebrow">Beneficios transparentes</p><h2 className="font-display mt-2 text-4xl leading-tight text-white sm:text-5xl">Más participación. <span className="text-emerald-300">Mejores condiciones.</span></h2><p className="mt-5 text-sm leading-7 text-slate-300">Durante el piloto, los beneficios se expresan únicamente en créditos virtuales. Las condiciones están visibles antes de reservar un boleto ficticio.</p><Link href="/billetera"><Button variant="outline" className="mt-7 border-emerald-300/20 bg-emerald-300/5 text-emerald-50 hover:bg-emerald-300/10 hover:text-emerald-50">Ir a mi billetera virtual <ArrowRight className="ml-2 h-4 w-4" /></Button></Link></div><div className="grid gap-3">{volumeBenefits.map((benefit, index) => <div key={benefit.label} className="flex flex-wrap items-center gap-4 rounded-2xl border border-white/10 bg-white/4 p-5"><div className="grid h-10 w-10 place-items-center rounded-xl bg-amber-200/10 text-sm font-black text-amber-200">0{index + 1}</div><div className="min-w-40 flex-1"><p className="font-bold text-white">{benefit.label}</p><p className="mt-1 text-xs text-slate-400">{benefit.note}</p></div><div className="text-right"><p className="text-xl font-black text-emerald-200">{benefit.discount ? `−${benefit.discount}%` : "Base"}</p><p className="text-xs text-slate-400">multiplicador {benefit.multiplier}</p></div></div>)}</div></div></section>

        <section className="container py-16 sm:py-24"><div className="grid gap-5 md:grid-cols-3">{[{ icon: ShieldCheck, title: "Justicia visible", text: "Hash previo, reglas versionadas y verificador público para cada ronda." }, { icon: Gift, title: "Progreso amable", text: "Bonificación de bienvenida, misiones no monetarias y recompensas diarias." }, { icon: CircleDollarSign, title: "Cero dinero real", text: "Sin pagos, retiros o valor monetario durante todo el piloto." }].map((item) => <div key={item.title} className="rounded-[1.75rem] border border-white/10 bg-white/4 p-7"><item.icon className="h-6 w-6 text-amber-200" /><h3 className="font-display mt-6 text-3xl text-white">{item.title}</h3><p className="mt-3 text-sm leading-6 text-slate-300">{item.text}</p></div>)}</div>
          <div className="mt-8 grid gap-6 overflow-hidden rounded-[2rem] border border-emerald-300/15 bg-[linear-gradient(110deg,#123c2c,#0b1d16_48%,#1d1a0d)] p-7 sm:p-10 lg:grid-cols-[1fr_auto] lg:items-center"><div><p className="eyebrow">Construido para un piloto responsable</p><h2 className="font-display mt-2 text-4xl text-white sm:text-5xl">La animación entretiene. El servidor decide.</h2><p className="mt-4 max-w-2xl text-sm leading-7 text-slate-300">La experiencia visual está desacoplada del resultado. El sistema futuro bloqueará participaciones, cerrará la ronda y emitirá una evidencia que podrás revisar.</p></div><Link href="/verificar"><Button className="gold-button whitespace-nowrap">Abrir verificador <BadgeCheck className="ml-2 h-4 w-4" /></Button></Link></div>
        </section>
      </main>
    </PilotLayout>
  );
}
