import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import GamePage from "@/pages/GamePage";
import ImpactoPage from "@/pages/ImpactoPage";
import MultiMarketPage from "@/pages/MultiMarketPage";
import TransparenciaPage from "@/pages/TransparenciaPage";
import Operations from "@/pages/Operations";
import Profile from "@/pages/Profile";
import Verify from "@/pages/Verify";
import Wallet from "@/pages/Wallet";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/juegos/:game"} component={GamePage} />
      <Route path={"/multimarket"} component={MultiMarketPage} />
      <Route path={"/impacto"} component={ImpactoPage} />
      <Route path={"/transparencia"} component={TransparenciaPage} />
      <Route path={"/billetera"} component={Wallet} />
      <Route path={"/verificar"} component={Verify} />
      <Route path={"/operacion"} component={Operations} />
      <Route path={"/perfil"} component={Profile} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
