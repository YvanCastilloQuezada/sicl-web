import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Menu, ShieldCheck, Sparkles, X } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

const navigation = [
  { label: "Ruleta", href: "/juegos/ruleta" },
  { label: "Jackpot", href: "/juegos/jackpot" },
  { label: "Bingo", href: "/juegos/bingo" },
  { label: "Lotería", href: "/juegos/loteria" },
  { label: "Trío 13", href: "/juegos/cartas" },
  { label: "MultiMarket", href: "/multimarket" },
  { label: "Impacto", href: "/impacto" },
  { label: "Tablas", href: "/transparencia" },
  { label: "Billetera", href: "/billetera" },
  { label: "Verificar", href: "/verificar" },
  { label: "Perfil", href: "/perfil" },
  { label: "Operación", href: "/operacion" },
];

export default function PilotLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, logout } = useAuth();
  const walletQuery = trpc.wallet.summary.useQuery(undefined, { enabled: isAuthenticated });
  const walletBalance = walletQuery.data?.wallet.balance ?? 2650;
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#071310] text-[#f3efe6]">
      <div className="pilot-ribbon">
        <div className="container flex items-center justify-center gap-2 text-center text-[11px] font-semibold tracking-[0.16em] text-emerald-50 sm:text-xs">
          <ShieldCheck className="h-3.5 w-3.5" />
          PILOTO GRATUITO · CRÉDITOS VIRTUALES · SIN DINERO REAL · SIN RETIROS
        </div>
      </div>

      <header className="sticky top-0 z-40 border-b border-white/8 bg-[#071310]/85 backdrop-blur-xl">
        <div className="container flex h-20 items-center justify-between gap-4">
          <Link href="/" className="group flex items-center gap-3" aria-label="Ir al inicio">
            <div className="brand-mark grid h-10 w-10 place-items-center rounded-xl text-sm font-black text-[#05251a]">RP</div>
            <div>
              <p className="font-display text-lg leading-none tracking-tight text-white">Multi Juegos Perú</p>
              <p className="mt-1 text-[9px] font-bold uppercase tracking-[0.21em] text-emerald-300">Transparencia y propósito</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-3 xl:flex" aria-label="Navegación principal">
            {navigation.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`nav-link text-xs ${location === item.href ? "text-emerald-200" : ""}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden items-center gap-3 sm:flex">
            <Badge className="border border-emerald-300/20 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-100 hover:bg-emerald-400/10">
              <Sparkles className="mr-1.5 h-3.5 w-3.5" /> {walletBalance.toLocaleString("es-PE")} créditos
            </Badge>
            {isAuthenticated ? (
              <Button onClick={logout} variant="outline" className="border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white">
                Salir
              </Button>
            ) : (
              <Button onClick={() => startLogin()} className="gold-button">Ingresar</Button>
            )}
          </div>

          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => setOpen((value) => !value)}
            className="border border-white/10 text-white hover:bg-white/10 hover:text-white lg:hidden"
            aria-label="Abrir menú"
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>

        {open ? (
          <div className="border-t border-white/10 bg-[#081913] px-4 py-4 lg:hidden">
            <nav className="container grid gap-2" aria-label="Navegación móvil">
              {navigation.map((item) => (
                <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 text-sm font-semibold text-white hover:bg-white/8">
                  {item.label}
                </Link>
              ))}
              {!isAuthenticated ? <Button onClick={() => startLogin()} className="gold-button mt-2">Ingresar al piloto</Button> : <p className="px-4 py-2 text-sm text-emerald-200">Hola, {user?.name ?? "jugador"}</p>}
            </nav>
          </div>
        ) : null}
      </header>

      {children}

      <footer className="border-t border-white/10 bg-[#050d0a] py-10">
        <div className="container grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <div className="mb-4 flex items-center gap-2 text-sm font-bold text-white"><ShieldCheck className="h-4 w-4 text-emerald-300" /> Piloto responsable y verificable</div>
            <p className="max-w-2xl text-sm leading-6 text-slate-300">Multi Juegos Perú es una demostración gratuita. No procesa pagos, no admite retiros y no asigna valor monetario a créditos, premios, contratos o beneficios.</p>
          </div>
          <div className="text-left text-xs text-slate-400 md:text-right">Perú y Sudamérica · Yape preparado, desactivado · v0.1 piloto</div>
        </div>
      </footer>
    </div>
  );
}
