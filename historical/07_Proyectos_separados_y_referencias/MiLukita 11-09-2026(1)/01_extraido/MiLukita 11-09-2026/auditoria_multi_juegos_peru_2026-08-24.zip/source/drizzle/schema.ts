import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const gameRulesets = mysqlTable("game_rulesets", {
  id: int("id").autoincrement().primaryKey(),
  gameType: mysqlEnum("gameType", ["ruleta", "jackpot", "bingo", "loteria", "cartas"]).notNull(),
  version: varchar("version", { length: 32 }).notNull(),
  title: varchar("title", { length: 128 }).notNull(),
  rulesJson: text("rulesJson").notNull(),
  prizePolicyJson: text("prizePolicyJson").notNull(),
  isPublished: boolean("isPublished").default(false).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [uniqueIndex("ruleset_game_version_unique").on(table.gameType, table.version)]);

export const gameRounds = mysqlTable("game_rounds", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  gameType: mysqlEnum("gameType", ["ruleta", "jackpot", "bingo", "loteria", "cartas"]).notNull(),
  rulesetId: int("rulesetId").notNull().references(() => gameRulesets.id),
  state: mysqlEnum("state", ["draft", "open", "locked", "drawn", "settled", "archived"]).default("draft").notNull(),
  opensAt: timestamp("opensAt").notNull(),
  closesAt: timestamp("closesAt").notNull(),
  serverSeedHash: varchar("serverSeedHash", { length: 128 }).notNull(),
  serverSeedSecret: text("serverSeedSecret").notNull(),
  revealedServerSeed: text("revealedServerSeed"),
  publicSeed: text("publicSeed"),
  ticketSetHash: varchar("ticketSetHash", { length: 128 }),
  resultJson: text("resultJson"),
  jackpotPoolCredits: int("jackpotPoolCredits").default(0).notNull(),
  algorithmVersion: varchar("algorithmVersion", { length: 64 }).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lockedAt: timestamp("lockedAt"),
  drawnAt: timestamp("drawnAt"),
  settledAt: timestamp("settledAt"),
}, (table) => [
  uniqueIndex("game_round_public_id_unique").on(table.publicId),
  index("game_round_type_state_index").on(table.gameType, table.state),
]);

export const virtualWallets = mysqlTable("virtual_wallets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  balance: int("balance").default(0).notNull(),
  welcomeBonusClaimed: boolean("welcomeBonusClaimed").default(false).notNull(),
  lastDailyRewardAt: timestamp("lastDailyRewardAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("wallet_user_unique").on(table.userId)]);

export const playerSettings = mysqlTable("player_settings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  countryCode: varchar("countryCode", { length: 2 }).default("PE").notNull(),
  sessionLimitMinutes: int("sessionLimitMinutes").default(60).notNull(),
  voluntaryPauseUntil: timestamp("voluntaryPauseUntil"),
  marketingEnabled: boolean("marketingEnabled").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("player_settings_user_unique").on(table.userId)]);

export const walletTransactions = mysqlTable("wallet_transactions", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  userId: int("userId").notNull().references(() => users.id),
  type: mysqlEnum("type", ["welcome_bonus", "daily_reward", "mission_reward", "ticket_debit", "virtual_prize", "promotion_bonus", "market_debit", "market_payout", "market_refund", "manual_adjustment"]).notNull(),
  amount: int("amount").notNull(),
  balanceAfter: int("balanceAfter").notNull(),
  idempotencyKey: varchar("idempotencyKey", { length: 96 }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  metadataJson: text("metadataJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("wallet_transaction_public_unique").on(table.publicId),
  uniqueIndex("wallet_transaction_idempotency_unique").on(table.idempotencyKey),
  index("wallet_transaction_user_index").on(table.userId, table.createdAt),
]);

export const pilotTickets = mysqlTable("pilot_tickets", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  userId: int("userId").notNull().references(() => users.id),
  roundId: int("roundId").notNull().references(() => gameRounds.id),
  gameType: mysqlEnum("gameType", ["ruleta", "jackpot", "bingo", "loteria", "cartas"]).notNull(),
  picksJson: text("picksJson").notNull(),
  quantity: int("quantity").default(1).notNull(),
  virtualCost: int("virtualCost").notNull(),
  virtualPrizeAmount: int("virtualPrizeAmount").default(0).notNull(),
  benefitTier: varchar("benefitTier", { length: 32 }).notNull(),
  status: mysqlEnum("status", ["reserved", "confirmed", "settled", "cancelled"]).default("reserved").notNull(),
  resultJson: text("resultJson"),
  ticketHash: varchar("ticketHash", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("pilot_ticket_public_unique").on(table.publicId),
  index("pilot_ticket_round_index").on(table.roundId, table.createdAt),
  index("pilot_ticket_user_index").on(table.userId, table.createdAt),
]);

export const auditEvents = mysqlTable("audit_events", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  actorUserId: int("actorUserId").references(() => users.id),
  eventType: varchar("eventType", { length: 64 }).notNull(),
  entityType: varchar("entityType", { length: 64 }).notNull(),
  entityPublicId: varchar("entityPublicId", { length: 64 }).notNull(),
  payloadJson: text("payloadJson").notNull(),
  previousHash: varchar("previousHash", { length: 128 }),
  eventHash: varchar("eventHash", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("audit_event_public_unique").on(table.publicId),
  index("audit_event_entity_index").on(table.entityType, table.entityPublicId, table.createdAt),
]);

export const paymentReferences = mysqlTable("payment_references", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  userId: int("userId").notNull().references(() => users.id),
  provider: mysqlEnum("provider", ["yape"]).default("yape").notNull(),
  status: mysqlEnum("status", ["disabled", "pending", "confirmed", "rejected", "expired"]).default("disabled").notNull(),
  countryCode: varchar("countryCode", { length: 2 }).default("PE").notNull(),
  virtualAmount: int("virtualAmount").notNull(),
  idempotencyKey: varchar("idempotencyKey", { length: 96 }).notNull(),
  providerReference: varchar("providerReference", { length: 128 }),
  metadataJson: text("metadataJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  uniqueIndex("payment_reference_public_unique").on(table.publicId),
  uniqueIndex("payment_reference_idempotency_unique").on(table.idempotencyKey),
]);

export const missions = mysqlTable("missions", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull(),
  title: varchar("title", { length: 128 }).notNull(),
  badgeLabel: varchar("badgeLabel", { length: 96 }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  targetCount: int("targetCount").notNull(),
  rewardCredits: int("rewardCredits").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [uniqueIndex("mission_code_unique").on(table.code)]);

export const playerMissionProgress = mysqlTable("player_mission_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  missionId: int("missionId").notNull().references(() => missions.id),
  progressCount: int("progressCount").default(0).notNull(),
  completedAt: timestamp("completedAt"),
  claimedAt: timestamp("claimedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("player_mission_unique").on(table.userId, table.missionId)]);

export const promotionRules = mysqlTable("promotion_rules", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull(),
  label: varchar("label", { length: 128 }).notNull(),
  kind: mysqlEnum("kind", ["volume_discount", "streak_bonus", "multiplier"]).notNull(),
  conditionsJson: text("conditionsJson").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("promotion_code_unique").on(table.code)]);

export const marketEvents = mysqlTable("market_events", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  title: varchar("title", { length: 220 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 48 }).notNull(),
  sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
  sourceUrl: varchar("sourceUrl", { length: 512 }).notNull(),
  resolutionRule: text("resolutionRule").notNull(),
  state: mysqlEnum("state", ["draft", "open", "closed", "settled", "voided"]).default("draft").notNull(),
  yesPriceCredits: int("yesPriceCredits").default(50).notNull(),
  noPriceCredits: int("noPriceCredits").default(50).notNull(),
  payoutCredits: int("payoutCredits").default(100).notNull(),
  closesAt: timestamp("closesAt").notNull(),
  resolvesAt: timestamp("resolvesAt"),
  outcome: mysqlEnum("outcome", ["yes", "no"]),
  resolutionUrl: varchar("resolutionUrl", { length: 512 }),
  pilotOnly: boolean("pilotOnly").default(true).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  uniqueIndex("market_event_public_unique").on(table.publicId),
  index("market_event_state_close_index").on(table.state, table.closesAt),
]);

export const marketPositions = mysqlTable("market_positions", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  userId: int("userId").notNull().references(() => users.id),
  marketId: int("marketId").notNull().references(() => marketEvents.id),
  side: mysqlEnum("side", ["yes", "no"]).notNull(),
  contracts: int("contracts").notNull(),
  unitCostCredits: int("unitCostCredits").notNull(),
  virtualCost: int("virtualCost").notNull(),
  virtualPayout: int("virtualPayout").default(0).notNull(),
  status: mysqlEnum("status", ["active", "settled", "refunded"]).default("active").notNull(),
  idempotencyKey: varchar("idempotencyKey", { length: 96 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  settledAt: timestamp("settledAt"),
}, (table) => [
  uniqueIndex("market_position_public_unique").on(table.publicId),
  uniqueIndex("market_position_idempotency_unique").on(table.idempotencyKey),
  index("market_position_market_index").on(table.marketId, table.createdAt),
  index("market_position_user_index").on(table.userId, table.createdAt),
]);

export const socialImpactCycles = mysqlTable("social_impact_cycles", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 40 }).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  periodLabel: varchar("periodLabel", { length: 96 }).notNull(),
  institutionalRateBps: int("institutionalRateBps").default(100).notNull(),
  status: mysqlEnum("status", ["pilot_disclosure", "planned", "paid", "cancelled"]).default("pilot_disclosure").notNull(),
  beneficiaryName: varchar("beneficiaryName", { length: 160 }),
  policyText: text("policyText").notNull(),
  approvedAmount: int("approvedAmount").default(0).notNull(),
  paidAmount: int("paidAmount").default(0).notNull(),
  reportUrl: varchar("reportUrl", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("social_impact_cycle_public_unique").on(table.publicId)]);

export type GameRuleset = typeof gameRulesets.$inferSelect;
export type GameRound = typeof gameRounds.$inferSelect;
export type VirtualWallet = typeof virtualWallets.$inferSelect;
export type PilotTicket = typeof pilotTickets.$inferSelect;
