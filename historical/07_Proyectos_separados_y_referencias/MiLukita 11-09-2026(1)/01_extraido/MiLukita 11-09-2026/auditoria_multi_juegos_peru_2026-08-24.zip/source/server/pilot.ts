import { and, desc, eq, inArray } from "drizzle-orm";
import { createHash, createHmac, randomBytes } from "node:crypto";
import { nanoid } from "nanoid";
import {
  auditEvents,
  gameRounds,
  gameRulesets,
  marketEvents,
  marketPositions,
  missions,
  paymentReferences,
  playerSettings,
  playerMissionProgress,
  pilotTickets,
  promotionRules,
  socialImpactCycles,
  virtualWallets,
  walletTransactions,
} from "../drizzle/schema";
import { getDb } from "./db";

export const GAME_TYPES = ["ruleta", "jackpot", "bingo", "loteria", "cartas"] as const;
export type GameType = (typeof GAME_TYPES)[number];
export const MARKET_CATEGORIES = ["cultura", "entretenimiento", "tecnologia", "educacion"] as const;
export type MarketCategory = (typeof MARKET_CATEGORIES)[number];
export const isAllowedMarketCategory = (category: string): category is MarketCategory => MARKET_CATEGORIES.includes(category as MarketCategory);

const GAME_CONFIG: Record<GameType, { title: string; price: number; pickLimit: number; range: number; rules: string; prizes: string }> = {
  ruleta: { title: "Ruleta piloto", price: 20, pickLimit: 1, range: 37, rules: "Selecciona una de 37 casillas, de 0 a 36. La ronda se decide tras el cierre.", prizes: "Premio virtual por coincidencia exacta." },
  jackpot: { title: "Jackpot piloto", price: 45, pickLimit: 5, range: 20, rules: "Selecciona cinco posiciones distintas entre 1 y 20.", prizes: "Pozo virtual y categorías de coincidencia." },
  bingo: { title: "Bingo piloto", price: 35, pickLimit: 1, range: 3, rules: "Selecciona una cartilla virtual. La secuencia se obtiene con sorteos verificables.", prizes: "Premios virtuales de línea y cartón." },
  loteria: { title: "Lotería piloto", price: 25, pickLimit: 6, range: 49, rules: "Selecciona seis números distintos entre 1 y 49.", prizes: "Premios virtuales definidos por coincidencias." },
  cartas: { title: "Trío 13", price: 10, pickLimit: 3, range: 13, rules: "Elige tres cartas distintas entre los trece rangos. El servidor revela tres cartas tras el cierre.", prizes: "Premios virtuales por una, dos o tres coincidencias." },
};

const ALGORITHM_VERSION = "hmac-sha256-rejection-v1";
const WELCOME_BONUS = 2000;
const DAILY_REWARD = 180;

const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");
const makePublicId = (prefix: string) => `${prefix}-${nanoid(12).toUpperCase()}`;
function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function getBenefit(quantity: number) {
  if (quantity >= 6) return { tier: "impulso", discount: 12, multiplier: 1.25 };
  if (quantity >= 3) return { tier: "constancia", discount: 6, multiplier: 1.1 };
  return { tier: "explora", discount: 0, multiplier: 1 };
}

async function resolveBenefit(quantity: number) {
  const db = await requireDatabase();
  const promotions = await db.select().from(promotionRules).where(and(eq(promotionRules.kind, "volume_discount"), eq(promotionRules.isActive, true)));
  const candidates = promotions.map((promotion) => ({ promotion, conditions: JSON.parse(promotion.conditionsJson) as { minimum?: number; discount?: number; multiplier?: number } })).filter(({ conditions }) => quantity >= (conditions.minimum ?? 1));
  const selected = candidates.sort((left, right) => (right.conditions.minimum ?? 0) - (left.conditions.minimum ?? 0))[0];
  if (!selected) return getBenefit(quantity);
  return { tier: selected.promotion.code, discount: selected.conditions.discount ?? 0, multiplier: selected.conditions.multiplier ?? 1 };
}

function deterministicIndex(seed: string, context: string, size: number, counterStart = 0) {
  const max = 0x100000000;
  const limit = Math.floor(max / size) * size;
  let counter = counterStart;
  while (true) {
    const digest = createHmac("sha256", seed).update(`${context}:${counter}`).digest();
    const candidate = digest.readUInt32BE(0);
    if (candidate < limit) return { value: candidate % size, counter: counter + 1 };
    counter += 1;
  }
}

function sampleUnique(seed: string, context: string, range: number, count: number, startAt = 1) {
  const pool = Array.from({ length: range }, (_, index) => index + startAt);
  const values: number[] = [];
  let counter = 0;
  while (values.length < count) {
    const pick = deterministicIndex(seed, context, pool.length, counter);
    counter = pick.counter;
    values.push(pool.splice(pick.value, 1)[0]);
  }
  return values.sort((left, right) => left - right);
}

export function drawTrio13(seed: string, publicSeed: string, publicId: string) {
  return sampleUnique(seed, `${publicId}:${publicSeed}:${ALGORITHM_VERSION}`, 13, 3);
}

function calculateResult(gameType: GameType, seed: string, publicSeed: string, publicId: string) {
  const context = `${publicId}:${publicSeed}:${ALGORITHM_VERSION}`;
  if (gameType === "ruleta") {
    const number = deterministicIndex(seed, context, 37).value;
    const color = number === 0 ? "verde" : [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(number) ? "rojo" : "negro";
    return { number, color };
  }
  if (gameType === "jackpot") return { positions: sampleUnique(seed, context, 20, 5) };
  if (gameType === "bingo") return { calls: sampleUnique(seed, context, 75, 15), winningCartilla: deterministicIndex(seed, `${context}:cartilla`, 3).value + 1 };
  if (gameType === "cartas") return { cards: drawTrio13(seed, publicSeed, publicId) };
  return { numbers: sampleUnique(seed, context, 49, 6) };
}

async function requireDatabase() {
  const db = await getDb();
  if (!db) throw new Error("La base de datos no está disponible.");
  return db;
}

async function appendAuditEvent(input: { actorUserId?: number; eventType: string; entityType: string; entityPublicId: string; payload: unknown }) {
  const db = await requireDatabase();
  const last = await db.select({ eventHash: auditEvents.eventHash }).from(auditEvents).orderBy(desc(auditEvents.id)).limit(1);
  const previousHash = last[0]?.eventHash ?? null;
  const payloadJson = canonicalJson(input.payload);
  const eventHash = sha256(`${previousHash ?? "genesis"}|${input.eventType}|${input.entityType}|${input.entityPublicId}|${payloadJson}`);
  await db.insert(auditEvents).values({
    publicId: makePublicId("AUD"),
    actorUserId: input.actorUserId,
    eventType: input.eventType,
    entityType: input.entityType,
    entityPublicId: input.entityPublicId,
    payloadJson,
    previousHash,
    eventHash,
  });
  return eventHash;
}

export async function bootstrapPilotRules(actorUserId: number) {
  const db = await requireDatabase();
  const now = new Date();
  const created: string[] = [];

  for (const gameType of GAME_TYPES) {
    const config = GAME_CONFIG[gameType];
    const existing = await db.select().from(gameRulesets).where(and(eq(gameRulesets.gameType, gameType), eq(gameRulesets.version, "v1.0.0"))).limit(1);
    let ruleset = existing[0];
    if (!ruleset) {
      await db.insert(gameRulesets).values({
        gameType,
        version: "v1.0.0",
        title: config.title,
        rulesJson: JSON.stringify({ gameType, pickLimit: config.pickLimit, numberRange: config.range, text: config.rules, pilotOnly: true }),
        prizePolicyJson: JSON.stringify({ text: config.prizes, virtualOnly: true, withdrawals: false }),
        isPublished: true,
        createdByUserId: actorUserId,
      });
      const rows = await db.select().from(gameRulesets).where(and(eq(gameRulesets.gameType, gameType), eq(gameRulesets.version, "v1.0.0"))).limit(1);
      ruleset = rows[0];
    }
    const openRound = await db.select().from(gameRounds).where(and(eq(gameRounds.gameType, gameType), inArray(gameRounds.state, ["draft", "open"]))).limit(1);
    if (!openRound[0] && ruleset) {
      const secret = randomBytes(32).toString("hex");
      const publicId = `RP-${gameType.slice(0, 1).toUpperCase()}-${nanoid(8).toUpperCase()}`;
      await db.insert(gameRounds).values({
        publicId,
        gameType,
        rulesetId: ruleset.id,
        state: "open",
        opensAt: now,
        closesAt: new Date(now.getTime() + 20 * 60 * 1000),
        serverSeedHash: sha256(secret),
        serverSeedSecret: secret,
        jackpotPoolCredits: gameType === "jackpot" ? 18400 : 0,
        algorithmVersion: ALGORITHM_VERSION,
        createdByUserId: actorUserId,
      });
      await appendAuditEvent({ actorUserId, eventType: "round.opened", entityType: "round", entityPublicId: publicId, payload: { gameType, ruleset: ruleset.version, serverSeedHash: sha256(secret) } });
      created.push(publicId);
    }
  }
  const defaultMissions = [
    { code: "FIRST_TICKET", title: "Primer boleto", badgeLabel: "Inicio verificado", description: "Confirma una participación virtual.", targetCount: 1, rewardCredits: 80 },
    { code: "TWO_GAMES", title: "Explora dos modalidades", badgeLabel: "Explorador de mesa", description: "Participa en dos tipos de juego distintos.", targetCount: 2, rewardCredits: 120 },
    { code: "VERIFY_DRAW", title: "Consulta un sorteo", badgeLabel: "Verificador público", description: "Abre y confirma un expediente verificable.", targetCount: 1, rewardCredits: 60 },
  ];
  for (const mission of defaultMissions) {
    const existingMission = await db.select().from(missions).where(eq(missions.code, mission.code)).limit(1);
    if (!existingMission[0]) await db.insert(missions).values(mission);
  }
  const defaultPromotions = [
    { code: "explora", label: "Explora", conditions: { minimum: 1, discount: 0, multiplier: 1 } },
    { code: "constancia", label: "Constancia", conditions: { minimum: 3, discount: 6, multiplier: 1.1 } },
    { code: "impulso", label: "Impulso", conditions: { minimum: 6, discount: 12, multiplier: 1.25 } },
    { code: "racha_3", label: "Racha de tres", conditions: { every: 3, rewardCredits: 70 } },
  ];
  for (const promotion of defaultPromotions) {
    const existingPromotion = await db.select().from(promotionRules).where(eq(promotionRules.code, promotion.code)).limit(1);
    if (!existingPromotion[0]) await db.insert(promotionRules).values({ code: promotion.code, label: promotion.label, kind: promotion.code === "racha_3" ? "streak_bonus" : "volume_discount", conditionsJson: JSON.stringify(promotion.conditions), createdByUserId: actorUserId });
  }
  const socialCycle = await db.select().from(socialImpactCycles).where(eq(socialImpactCycles.periodLabel, "Piloto gratuito")).limit(1);
  if (!socialCycle[0]) {
    await db.insert(socialImpactCycles).values({
      publicId: makePublicId("SOC"),
      title: "Compromiso social del piloto",
      periodLabel: "Piloto gratuito",
      institutionalRateBps: 100,
      status: "pilot_disclosure",
      policyText: "Durante el piloto no hay dinero real ni utilidades. Si se habilita una versión regulada, se propondrá un aporte institucional de hasta 1 % de utilidades netas, divulgado por periodo y respaldado con un reporte. Las donaciones de ganadores serán siempre voluntarias, explícitas y no reducirán premios sin consentimiento.",
    });
  }
  return { created };
}

export async function getPublicRounds() {
  const db = await requireDatabase();
  const rows = await db.select().from(gameRounds).where(inArray(gameRounds.state, ["open", "locked", "drawn", "settled"])).orderBy(desc(gameRounds.createdAt));
  return rows.map(({ serverSeedSecret: _secret, ...round }) => round);
}

export async function getRoundProof(publicId: string) {
  const db = await requireDatabase();
  const rows = await db.select().from(gameRounds).where(eq(gameRounds.publicId, publicId)).limit(1);
  const round = rows[0];
  if (!round) return null;
  const rulesetRows = await db.select().from(gameRulesets).where(eq(gameRulesets.id, round.rulesetId)).limit(1);
  const ruleset = rulesetRows[0];
  return {
    publicId: round.publicId,
    gameType: round.gameType,
    state: round.state,
    ruleset: ruleset ? { version: ruleset.version, rules: JSON.parse(ruleset.rulesJson), prizes: JSON.parse(ruleset.prizePolicyJson) } : null,
    serverSeedHash: round.serverSeedHash,
    revealedServerSeed: round.revealedServerSeed,
    publicSeed: round.publicSeed,
    ticketSetHash: round.ticketSetHash,
    result: round.resultJson ? JSON.parse(round.resultJson) : null,
    algorithmVersion: round.algorithmVersion,
    closesAt: round.closesAt,
    drawnAt: round.drawnAt,
  };
}

async function getOrCreateWallet(userId: number) {
  const db = await requireDatabase();
  const current = await db.select().from(virtualWallets).where(eq(virtualWallets.userId, userId)).limit(1);
  if (current[0]) return current[0];
  await db.insert(virtualWallets).values({ userId, balance: WELCOME_BONUS, welcomeBonusClaimed: true });
  const wallet = (await db.select().from(virtualWallets).where(eq(virtualWallets.userId, userId)).limit(1))[0];
  await db.insert(walletTransactions).values({
    publicId: makePublicId("WAL"),
    userId,
    type: "welcome_bonus",
    amount: WELCOME_BONUS,
    balanceAfter: WELCOME_BONUS,
    idempotencyKey: `welcome:${userId}`,
    description: "Bonificación de bienvenida del piloto",
    metadataJson: JSON.stringify({ pilotOnly: true }),
  });
  await appendAuditEvent({ actorUserId: userId, eventType: "wallet.welcome_bonus", entityType: "wallet", entityPublicId: String(userId), payload: { amount: WELCOME_BONUS } });
  return wallet;
}

async function getOrCreatePlayerSettings(userId: number) {
  const db = await requireDatabase();
  const current = await db.select().from(playerSettings).where(eq(playerSettings.userId, userId)).limit(1);
  if (current[0]) return current[0];
  await db.insert(playerSettings).values({ userId, countryCode: "PE", sessionLimitMinutes: 60, marketingEnabled: false });
  return (await db.select().from(playerSettings).where(eq(playerSettings.userId, userId)).limit(1))[0];
}

async function setMissionProgress(userId: number, code: string, progressCount: number) {
  const db = await requireDatabase();
  const mission = (await db.select().from(missions).where(eq(missions.code, code)).limit(1))[0];
  if (!mission) return;
  const existing = await db.select().from(playerMissionProgress).where(and(eq(playerMissionProgress.userId, userId), eq(playerMissionProgress.missionId, mission.id))).limit(1);
  const completedAt = progressCount >= mission.targetCount ? new Date() : null;
  if (existing[0]) {
    const nextProgress = Math.max(existing[0].progressCount, progressCount);
    await db.update(playerMissionProgress).set({ progressCount: nextProgress, completedAt: existing[0].completedAt ?? completedAt }).where(eq(playerMissionProgress.id, existing[0].id));
    return;
  }
  await db.insert(playerMissionProgress).values({ userId, missionId: mission.id, progressCount, completedAt });
}

async function updateTicketMissions(userId: number) {
  const db = await requireDatabase();
  const tickets = await db.select({ gameType: pilotTickets.gameType }).from(pilotTickets).where(and(eq(pilotTickets.userId, userId), eq(pilotTickets.status, "confirmed")));
  await setMissionProgress(userId, "FIRST_TICKET", tickets.length ? 1 : 0);
  await setMissionProgress(userId, "TWO_GAMES", Array.from(new Set(tickets.map((ticket) => ticket.gameType))).length);
}

async function awardStreakBonus(userId: number, ticketPublicId: string) {
  const db = await requireDatabase();
  const streakRule = (await db.select().from(promotionRules).where(and(eq(promotionRules.code, "racha_3"), eq(promotionRules.isActive, true))).limit(1))[0];
  if (!streakRule) return 0;
  const conditions = JSON.parse(streakRule.conditionsJson) as { every?: number; rewardCredits?: number };
  const every = conditions.every ?? 3;
  const tickets = await db.select({ id: pilotTickets.id }).from(pilotTickets).where(eq(pilotTickets.userId, userId));
  if (!tickets.length || tickets.length % every !== 0) return 0;
  const reward = conditions.rewardCredits ?? 70;
  const wallet = await getOrCreateWallet(userId);
  const nextBalance = wallet.balance + reward;
  await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
  await db.insert(walletTransactions).values({ publicId: makePublicId("WAL"), userId, type: "promotion_bonus", amount: reward, balanceAfter: nextBalance, idempotencyKey: `streak:${ticketPublicId}`, description: `Bono virtual ${streakRule.label}`, metadataJson: JSON.stringify({ ticketPublicId, promotionCode: streakRule.code, pilotOnly: true }) });
  await appendAuditEvent({ actorUserId: userId, eventType: "promotion.streak_awarded", entityType: "ticket", entityPublicId: ticketPublicId, payload: { reward, promotionCode: streakRule.code } });
  return reward;
}

export async function getMissionSummary(userId: number) {
  const db = await requireDatabase();
  const active = await db.select().from(missions).where(eq(missions.isActive, true));
  for (const mission of active) {
    const progress = await db.select().from(playerMissionProgress).where(and(eq(playerMissionProgress.userId, userId), eq(playerMissionProgress.missionId, mission.id))).limit(1);
    if (!progress[0]) await db.insert(playerMissionProgress).values({ userId, missionId: mission.id });
  }
  const progressRows = await db.select().from(playerMissionProgress).where(eq(playerMissionProgress.userId, userId));
  return active.map((mission) => ({ ...mission, progress: progressRows.find((progress) => progress.missionId === mission.id) }));
}

export async function claimMissionReward(userId: number, code: string) {
  const db = await requireDatabase();
  const mission = (await db.select().from(missions).where(eq(missions.code, code)).limit(1))[0];
  if (!mission) throw new Error("No se encontró la misión.");
  const progress = (await db.select().from(playerMissionProgress).where(and(eq(playerMissionProgress.userId, userId), eq(playerMissionProgress.missionId, mission.id))).limit(1))[0];
  if (!progress || !progress.completedAt) throw new Error("La misión todavía no está completa.");
  if (progress.claimedAt) throw new Error("Esta recompensa ya fue reclamada.");
  const wallet = await getOrCreateWallet(userId);
  const nextBalance = wallet.balance + mission.rewardCredits;
  await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
  await db.update(playerMissionProgress).set({ claimedAt: new Date() }).where(eq(playerMissionProgress.id, progress.id));
  await db.insert(walletTransactions).values({ publicId: makePublicId("WAL"), userId, type: "mission_reward", amount: mission.rewardCredits, balanceAfter: nextBalance, idempotencyKey: `mission:${userId}:${code}`, description: `Misión completada: ${mission.title}`, metadataJson: JSON.stringify({ missionCode: code, pilotOnly: true }) });
  await appendAuditEvent({ actorUserId: userId, eventType: "mission.claimed", entityType: "mission", entityPublicId: code, payload: { rewardCredits: mission.rewardCredits } });
  return { balance: nextBalance, reward: mission.rewardCredits, code };
}

export async function registerVerificationMission(userId: number) {
  await setMissionProgress(userId, "VERIFY_DRAW", 1);
  return getMissionSummary(userId);
}

export async function getWalletSummary(userId: number) {
  const db = await requireDatabase();
  const wallet = await getOrCreateWallet(userId);
  const settings = await getOrCreatePlayerSettings(userId);
  const transactions = await db.select().from(walletTransactions).where(eq(walletTransactions.userId, userId)).orderBy(desc(walletTransactions.createdAt)).limit(20);
  const missionSummary = await getMissionSummary(userId);
  return { wallet, transactions, settings, missionSummary, pilotOnly: true, withdrawalsEnabled: false };
}

export async function getPublicMarkets() {
  const db = await requireDatabase();
  return db.select().from(marketEvents).where(inArray(marketEvents.state, ["open", "closed", "settled", "voided"])).orderBy(desc(marketEvents.createdAt));
}

export async function getMarketSummary(userId: number) {
  const db = await requireDatabase();
  const [markets, positions] = await Promise.all([
    getPublicMarkets(),
    db.select().from(marketPositions).where(eq(marketPositions.userId, userId)).orderBy(desc(marketPositions.createdAt)),
  ]);
  return { markets, positions, pilotOnly: true, withdrawalsEnabled: false };
}

export function calculateMarketPayout(side: "yes" | "no", outcome: "yes" | "no", contracts: number, payoutCredits: number) {
  return side === outcome ? contracts * payoutCredits : 0;
}

export async function reserveMarketPosition(input: { userId: number; marketPublicId: string; side: "yes" | "no"; contracts: number; idempotencyKey: string }) {
  const db = await requireDatabase();
  if (!Number.isInteger(input.contracts) || input.contracts < 1 || input.contracts > 10) throw new Error("La cantidad de contratos virtuales debe estar entre 1 y 10.");
  const market = (await db.select().from(marketEvents).where(eq(marketEvents.publicId, input.marketPublicId)).limit(1))[0];
  if (!market || market.state !== "open" || new Date(market.closesAt).getTime() <= Date.now()) throw new Error("Este mercado virtual no está abierto.");
  const settings = await getOrCreatePlayerSettings(input.userId);
  if (settings.voluntaryPauseUntil && settings.voluntaryPauseUntil.getTime() > Date.now()) throw new Error("Tu pausa voluntaria está activa.");
  const existing = (await db.select().from(marketPositions).where(eq(marketPositions.idempotencyKey, input.idempotencyKey)).limit(1))[0];
  if (existing) return { publicId: existing.publicId, virtualCost: existing.virtualCost, side: existing.side, contracts: existing.contracts, recovered: true };
  const unitCostCredits = input.side === "yes" ? market.yesPriceCredits : market.noPriceCredits;
  const virtualCost = unitCostCredits * input.contracts;
  const wallet = await getOrCreateWallet(input.userId);
  if (wallet.balance < virtualCost) throw new Error("No tienes créditos virtuales suficientes para esta posición.");
  const publicId = makePublicId("MKT");
  const nextBalance = wallet.balance - virtualCost;
  await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
  await db.insert(marketPositions).values({ publicId, userId: input.userId, marketId: market.id, side: input.side, contracts: input.contracts, unitCostCredits, virtualCost, idempotencyKey: input.idempotencyKey });
  await db.insert(walletTransactions).values({ publicId: makePublicId("WAL"), userId: input.userId, type: "market_debit", amount: -virtualCost, balanceAfter: nextBalance, idempotencyKey: `market:${input.idempotencyKey}`, description: `Posición virtual ${input.side.toUpperCase()} en ${market.publicId}`, metadataJson: JSON.stringify({ marketPublicId: market.publicId, positionPublicId: publicId, pilotOnly: true }) });
  await appendAuditEvent({ actorUserId: input.userId, eventType: "market.position_opened", entityType: "market", entityPublicId: market.publicId, payload: { positionPublicId: publicId, side: input.side, contracts: input.contracts, virtualCost } });
  return { publicId, virtualCost, side: input.side, contracts: input.contracts, balanceAfter: nextBalance, recovered: false };
}

export async function createCuratedMarket(actorUserId: number, input: { title: string; description: string; category: string; sourceLabel: string; sourceUrl: string; resolutionRule: string; yesPriceCredits: number; noPriceCredits: number; closesAt: Date }) {
  const db = await requireDatabase();
  if (!isAllowedMarketCategory(input.category)) throw new Error("La categoría de MultiMarket no está permitida en el piloto.");
  if (input.closesAt.getTime() <= Date.now()) throw new Error("El cierre del mercado debe estar en el futuro.");
  const publicId = makePublicId("MKT");
  await db.insert(marketEvents).values({ ...input, publicId, state: "open", payoutCredits: 100, pilotOnly: true, createdByUserId: actorUserId });
  await appendAuditEvent({ actorUserId, eventType: "market.opened", entityType: "market", entityPublicId: publicId, payload: { ...input, pilotOnly: true } });
  return (await db.select().from(marketEvents).where(eq(marketEvents.publicId, publicId)).limit(1))[0];
}

export async function closeCuratedMarket(actorUserId: number, marketPublicId: string) {
  const db = await requireDatabase();
  const market = (await db.select().from(marketEvents).where(eq(marketEvents.publicId, marketPublicId)).limit(1))[0];
  if (!market || market.state !== "open") throw new Error("El mercado no está disponible para cierre.");
  await db.update(marketEvents).set({ state: "closed", closesAt: new Date() }).where(eq(marketEvents.id, market.id));
  await appendAuditEvent({ actorUserId, eventType: "market.closed", entityType: "market", entityPublicId: market.publicId, payload: { closesAt: new Date().toISOString(), reason: "Cierre manual del operador" } });
  return { publicId: market.publicId, state: "closed" as const };
}

export async function resolveCuratedMarket(actorUserId: number, input: { marketPublicId: string; outcome: "yes" | "no"; resolutionUrl: string }) {
  const db = await requireDatabase();
  const market = (await db.select().from(marketEvents).where(eq(marketEvents.publicId, input.marketPublicId)).limit(1))[0];
  if (!market || !["open", "closed"].includes(market.state)) throw new Error("El mercado no está disponible para resolución.");
  const positions = await db.select().from(marketPositions).where(and(eq(marketPositions.marketId, market.id), eq(marketPositions.status, "active")));
  for (const position of positions) {
    const payout = calculateMarketPayout(position.side, input.outcome, position.contracts, market.payoutCredits);
    await db.update(marketPositions).set({ status: "settled", virtualPayout: payout, settledAt: new Date() }).where(eq(marketPositions.id, position.id));
    if (payout > 0) {
      const wallet = await getOrCreateWallet(position.userId);
      const nextBalance = wallet.balance + payout;
      await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
      await db.insert(walletTransactions).values({ publicId: makePublicId("WAL"), userId: position.userId, type: "market_payout", amount: payout, balanceAfter: nextBalance, idempotencyKey: `market-payout:${position.publicId}`, description: `Liquidación virtual de ${market.publicId}`, metadataJson: JSON.stringify({ marketPublicId: market.publicId, outcome: input.outcome, positionPublicId: position.publicId, pilotOnly: true }) });
    }
  }
  await db.update(marketEvents).set({ state: "settled", outcome: input.outcome, resolutionUrl: input.resolutionUrl, resolvesAt: new Date() }).where(eq(marketEvents.id, market.id));
  await appendAuditEvent({ actorUserId, eventType: "market.settled", entityType: "market", entityPublicId: market.publicId, payload: { outcome: input.outcome, resolutionUrl: input.resolutionUrl, positionCount: positions.length } });
  return { publicId: market.publicId, outcome: input.outcome, positionsSettled: positions.length };
}

export async function voidCuratedMarket(actorUserId: number, input: { marketPublicId: string; resolutionUrl: string }) {
  const db = await requireDatabase();
  const market = (await db.select().from(marketEvents).where(eq(marketEvents.publicId, input.marketPublicId)).limit(1))[0];
  if (!market || !["draft", "open", "closed"].includes(market.state)) throw new Error("El mercado no está disponible para anulación.");
  const positions = await db.select().from(marketPositions).where(and(eq(marketPositions.marketId, market.id), eq(marketPositions.status, "active")));
  for (const position of positions) {
    const wallet = await getOrCreateWallet(position.userId);
    const nextBalance = wallet.balance + position.virtualCost;
    await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
    await db.update(marketPositions).set({ status: "refunded", virtualPayout: position.virtualCost, settledAt: new Date() }).where(eq(marketPositions.id, position.id));
    await db.insert(walletTransactions).values({ publicId: makePublicId("WAL"), userId: position.userId, type: "market_refund", amount: position.virtualCost, balanceAfter: nextBalance, idempotencyKey: `market-refund:${position.publicId}`, description: `Reembolso virtual por anulación de ${market.publicId}`, metadataJson: JSON.stringify({ marketPublicId: market.publicId, positionPublicId: position.publicId, pilotOnly: true }) });
  }
  await db.update(marketEvents).set({ state: "voided", resolutionUrl: input.resolutionUrl, resolvesAt: new Date() }).where(eq(marketEvents.id, market.id));
  await appendAuditEvent({ actorUserId, eventType: "market.voided", entityType: "market", entityPublicId: market.publicId, payload: { resolutionUrl: input.resolutionUrl, positionsRefunded: positions.length } });
  return { publicId: market.publicId, positionsRefunded: positions.length };
}

export async function getSocialImpactSummary() {
  const db = await requireDatabase();
  return db.select().from(socialImpactCycles).orderBy(desc(socialImpactCycles.createdAt));
}

export async function updateResponsibleSettings(userId: number, input: { sessionLimitMinutes: number; pauseHours: number; countryCode: string }) {
  const db = await requireDatabase();
  const settings = await getOrCreatePlayerSettings(userId);
  const voluntaryPauseUntil = input.pauseHours > 0 ? new Date(Date.now() + input.pauseHours * 60 * 60 * 1000) : null;
  await db.update(playerSettings).set({ sessionLimitMinutes: input.sessionLimitMinutes, countryCode: input.countryCode, voluntaryPauseUntil }).where(eq(playerSettings.id, settings.id));
  await appendAuditEvent({ actorUserId: userId, eventType: "player_settings.updated", entityType: "player_settings", entityPublicId: String(userId), payload: { sessionLimitMinutes: input.sessionLimitMinutes, pauseHours: input.pauseHours, countryCode: input.countryCode } });
  return (await db.select().from(playerSettings).where(eq(playerSettings.id, settings.id)).limit(1))[0];
}

export async function claimDailyReward(userId: number) {
  const db = await requireDatabase();
  const wallet = await getOrCreateWallet(userId);
  const now = new Date();
  const lastClaim = wallet.lastDailyRewardAt?.getTime() ?? 0;
  if (lastClaim && now.getTime() - lastClaim < 24 * 60 * 60 * 1000) throw new Error("La recompensa diaria ya fue reclamada. Intenta nuevamente después de 24 horas.");
  const nextBalance = wallet.balance + DAILY_REWARD;
  await db.update(virtualWallets).set({ balance: nextBalance, lastDailyRewardAt: now }).where(eq(virtualWallets.id, wallet.id));
  await db.insert(walletTransactions).values({
    publicId: makePublicId("WAL"),
    userId,
    type: "daily_reward",
    amount: DAILY_REWARD,
    balanceAfter: nextBalance,
    idempotencyKey: `daily:${userId}:${now.toISOString().slice(0, 10)}`,
    description: "Recompensa diaria del piloto",
    metadataJson: JSON.stringify({ pilotOnly: true }),
  });
  await appendAuditEvent({ actorUserId: userId, eventType: "wallet.daily_reward", entityType: "wallet", entityPublicId: String(userId), payload: { amount: DAILY_REWARD, balanceAfter: nextBalance } });
  return { balance: nextBalance, reward: DAILY_REWARD };
}

export async function reservePilotTicket(input: { userId: number; roundPublicId: string; picks: number[]; quantity: number; idempotencyKey: string }) {
  const db = await requireDatabase();
  const roundRows = await db.select().from(gameRounds).where(eq(gameRounds.publicId, input.roundPublicId)).limit(1);
  const round = roundRows[0];
  if (!round || round.state !== "open") throw new Error("La ronda no está disponible para participar.");
  if (new Date(round.closesAt).getTime() <= Date.now()) throw new Error("La participación está cerrada para esta ronda.");
  const config = GAME_CONFIG[round.gameType];
  const settings = await getOrCreatePlayerSettings(input.userId);
  if (settings.voluntaryPauseUntil && settings.voluntaryPauseUntil.getTime() > Date.now()) throw new Error("Tu pausa voluntaria está activa. La participación se reanudará cuando finalice el periodo seleccionado.");
  const uniquePicks = Array.from(new Set(input.picks)).sort((left, right) => left - right);
  if (uniquePicks.length !== config.pickLimit || uniquePicks.some((value) => value < (round.gameType === "ruleta" ? 0 : 1) || value > config.range)) throw new Error("La selección no cumple las reglas de esta modalidad.");
  if (!Number.isInteger(input.quantity) || input.quantity < 1 || input.quantity > 10) throw new Error("La cantidad de boletos debe estar entre 1 y 10.");
  const existingDebit = await db.select().from(walletTransactions).where(eq(walletTransactions.idempotencyKey, `ticket:${input.idempotencyKey}`)).limit(1);
  if (existingDebit[0]) {
    const metadata = existingDebit[0].metadataJson ? JSON.parse(existingDebit[0].metadataJson) as { ticketPublicId?: string; ticketHash?: string; benefit?: ReturnType<typeof getBenefit> } : {};
    return {
      publicId: metadata.ticketPublicId ?? "TKT-RECUPERADO",
      virtualCost: Math.abs(existingDebit[0].amount),
      balanceAfter: existingDebit[0].balanceAfter,
      ticketHash: metadata.ticketHash ?? "",
      benefit: metadata.benefit ?? getBenefit(input.quantity),
    };
  }
  const benefit = await resolveBenefit(input.quantity);
  const virtualCost = Math.round(config.price * input.quantity * (1 - benefit.discount / 100));
  const wallet = await getOrCreateWallet(input.userId);
  if (wallet.balance < virtualCost) throw new Error("No tienes suficientes créditos virtuales para esta participación.");
  const nextBalance = wallet.balance - virtualCost;
  const ticketPublicId = makePublicId("TKT");
  const ticketHash = sha256(canonicalJson({ ticketPublicId, roundPublicId: round.publicId, picks: uniquePicks, quantity: input.quantity, virtualCost, benefit }));
  await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
  await db.insert(pilotTickets).values({
    publicId: ticketPublicId,
    userId: input.userId,
    roundId: round.id,
    gameType: round.gameType,
    picksJson: JSON.stringify(uniquePicks),
    quantity: input.quantity,
    virtualCost,
    benefitTier: benefit.tier,
    status: "confirmed",
    ticketHash,
  });
  await db.insert(walletTransactions).values({
    publicId: makePublicId("WAL"),
    userId: input.userId,
    type: "ticket_debit",
    amount: -virtualCost,
    balanceAfter: nextBalance,
    idempotencyKey: `ticket:${input.idempotencyKey}`,
    description: `Boleto ficticio ${ticketPublicId}`,
    metadataJson: JSON.stringify({ roundPublicId: round.publicId, ticketPublicId, ticketHash, benefit, pilotOnly: true }),
  });
  if (round.gameType === "jackpot") await db.update(gameRounds).set({ jackpotPoolCredits: round.jackpotPoolCredits + Math.round(virtualCost * 0.35) }).where(eq(gameRounds.id, round.id));
  await updateTicketMissions(input.userId);
  const streakBonus = await awardStreakBonus(input.userId, ticketPublicId);
  const finalWallet = await getOrCreateWallet(input.userId);
  await appendAuditEvent({ actorUserId: input.userId, eventType: "ticket.confirmed", entityType: "ticket", entityPublicId: ticketPublicId, payload: { roundPublicId: round.publicId, ticketHash, virtualCost, benefit } });
  return { publicId: ticketPublicId, virtualCost, balanceAfter: finalWallet.balance, ticketHash, benefit, streakBonus };
}

export function calculateTicketPrize(gameType: GameType, picks: number[], result: Record<string, unknown>, quantity: number, jackpotShare: number) {
  if (gameType === "ruleta") return picks[0] === result.number ? 360 * quantity : 0;
  if (gameType === "jackpot") {
    const positions = (result.positions as number[]) ?? [];
    const matches = picks.filter((pick) => positions.includes(pick)).length;
    if (matches === 5) return jackpotShare;
    if (matches === 4) return 1200 * quantity;
    if (matches === 3) return 240 * quantity;
    return 0;
  }
  if (gameType === "bingo") return picks[0] === result.winningCartilla ? 450 * quantity : 0;
  if (gameType === "cartas") {
    const cards = (result.cards as number[]) ?? [];
    const matches = picks.filter((pick) => cards.includes(pick)).length;
    if (matches === 3) return 700 * quantity;
    if (matches === 2) return 37 * quantity;
    if (matches === 1) return 5 * quantity;
    return 0;
  }
  const numbers = (result.numbers as number[]) ?? [];
  const matches = picks.filter((pick) => numbers.includes(pick)).length;
  if (matches === 6) return 9000 * quantity;
  if (matches === 5) return 1500 * quantity;
  if (matches === 4) return 250 * quantity;
  if (matches === 3) return 40 * quantity;
  return 0;
}

export async function closeAndDrawRound(actorUserId: number, publicId: string) {
  const db = await requireDatabase();
  const rows = await db.select().from(gameRounds).where(eq(gameRounds.publicId, publicId)).limit(1);
  const round = rows[0];
  if (!round) throw new Error("No se encontró la ronda.");
  if (!["open", "locked"].includes(round.state)) throw new Error("La ronda no está disponible para cierre y sorteo.");
  const tickets = await db.select().from(pilotTickets).where(and(eq(pilotTickets.roundId, round.id), eq(pilotTickets.status, "confirmed"))).orderBy(pilotTickets.publicId);
  const ticketSetHash = sha256(canonicalJson(tickets.map((ticket) => ({ publicId: ticket.publicId, ticketHash: ticket.ticketHash }))));
  const publicSeed = `PILOT:${round.publicId}:${ticketSetHash.slice(0, 16)}`;
  const result = calculateResult(round.gameType, round.serverSeedSecret, publicSeed, round.publicId);
  const now = new Date();
  const jackpotWinners = round.gameType === "jackpot" ? tickets.filter((ticket) => JSON.parse(ticket.picksJson).filter((pick: number) => (result.positions as number[]).includes(pick)).length === 5) : [];
  const jackpotShare = jackpotWinners.length ? Math.floor(round.jackpotPoolCredits / jackpotWinners.length) : 0;
  for (const ticket of tickets) {
    const prize = calculateTicketPrize(round.gameType, JSON.parse(ticket.picksJson), result, ticket.quantity, jackpotShare);
    await db.update(pilotTickets).set({ status: "settled", virtualPrizeAmount: prize, resultJson: JSON.stringify({ result, prize }) }).where(eq(pilotTickets.id, ticket.id));
    if (prize > 0) {
      const wallet = await getOrCreateWallet(ticket.userId);
      const nextBalance = wallet.balance + prize;
      await db.update(virtualWallets).set({ balance: nextBalance }).where(eq(virtualWallets.id, wallet.id));
      await db.insert(walletTransactions).values({ publicId: makePublicId("WAL"), userId: ticket.userId, type: "virtual_prize", amount: prize, balanceAfter: nextBalance, idempotencyKey: `prize:${ticket.publicId}`, description: `Premio virtual de ${round.publicId}`, metadataJson: JSON.stringify({ roundPublicId: round.publicId, ticketPublicId: ticket.publicId, pilotOnly: true }) });
      await appendAuditEvent({ actorUserId, eventType: "ticket.prize_settled", entityType: "ticket", entityPublicId: ticket.publicId, payload: { prize, roundPublicId: round.publicId } });
    }
  }
  await db.update(gameRounds).set({ state: "settled", ticketSetHash, publicSeed, revealedServerSeed: round.serverSeedSecret, resultJson: JSON.stringify(result), lockedAt: round.lockedAt ?? now, drawnAt: now, settledAt: now }).where(eq(gameRounds.id, round.id));
  await appendAuditEvent({ actorUserId, eventType: "round.drawn", entityType: "round", entityPublicId: round.publicId, payload: { ticketSetHash, publicSeed, result, algorithmVersion: ALGORITHM_VERSION } });
  return getRoundProof(round.publicId);
}

export async function getOperationsOverview() {
  const db = await requireDatabase();
  const rounds = await db.select().from(gameRounds).orderBy(desc(gameRounds.createdAt)).limit(20);
  const tickets = await db.select().from(pilotTickets).orderBy(desc(pilotTickets.createdAt)).limit(50);
  const events = await db.select().from(auditEvents).orderBy(desc(auditEvents.createdAt)).limit(30);
  const promotions = await db.select().from(promotionRules).orderBy(desc(promotionRules.createdAt));
  return { rounds: rounds.map(({ serverSeedSecret: _secret, ...round }) => round), ticketCount: tickets.length, auditEvents: events, marketAuditEvents: events.filter((event) => event.entityType === "market"), promotions, payments: { provider: "yape", enabled: false, countryCode: "PE" } };
}

export async function updatePromotionStatus(actorUserId: number, code: string, isActive: boolean) {
  const db = await requireDatabase();
  const promotion = (await db.select().from(promotionRules).where(eq(promotionRules.code, code)).limit(1))[0];
  if (!promotion) throw new Error("No se encontró la promoción.");
  await db.update(promotionRules).set({ isActive }).where(eq(promotionRules.id, promotion.id));
  await appendAuditEvent({ actorUserId, eventType: "promotion.updated", entityType: "promotion", entityPublicId: code, payload: { isActive } });
  return { code, isActive };
}

export async function publishRulesetRevision(actorUserId: number, gameType: GameType) {
  const db = await requireDatabase();
  const latest = (await db.select().from(gameRulesets).where(eq(gameRulesets.gameType, gameType)).orderBy(desc(gameRulesets.createdAt)).limit(1))[0];
  if (!latest) throw new Error("Primero prepara las reglas iniciales del piloto.");
  const parts = latest.version.replace("v", "").split(".").map(Number);
  const nextVersion = `v${parts[0] ?? 1}.${parts[1] ?? 0}.${(parts[2] ?? 0) + 1}`;
  const rules = { ...JSON.parse(latest.rulesJson), revisionNote: "Revisión publicada desde el panel de operador", publishedAt: new Date().toISOString() };
  await db.insert(gameRulesets).values({ gameType, version: nextVersion, title: latest.title, rulesJson: JSON.stringify(rules), prizePolicyJson: latest.prizePolicyJson, isPublished: true, createdByUserId: actorUserId });
  await appendAuditEvent({ actorUserId, eventType: "ruleset.published", entityType: "ruleset", entityPublicId: `${gameType}:${nextVersion}`, payload: { priorVersion: latest.version, nextVersion } });
  return { gameType, version: nextVersion };
}

export async function createDisabledYapeReference(userId: number, virtualAmount: number, idempotencyKey: string) {
  const db = await requireDatabase();
  const existing = await db.select().from(paymentReferences).where(eq(paymentReferences.idempotencyKey, idempotencyKey)).limit(1);
  if (existing[0]) return existing[0];
  const publicId = makePublicId("PAY");
  await db.insert(paymentReferences).values({ publicId, userId, virtualAmount, idempotencyKey, status: "disabled", metadataJson: JSON.stringify({ reason: "Piloto gratuito: integración de pagos desactivada", pilotOnly: true }) });
  await appendAuditEvent({ actorUserId: userId, eventType: "payment_reference.disabled", entityType: "payment_reference", entityPublicId: publicId, payload: { provider: "yape", enabled: false } });
  return { publicId, provider: "yape", status: "disabled" as const };
}
