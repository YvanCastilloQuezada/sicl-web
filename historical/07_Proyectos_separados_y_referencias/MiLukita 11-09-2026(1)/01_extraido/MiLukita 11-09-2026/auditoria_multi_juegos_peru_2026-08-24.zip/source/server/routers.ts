import { COOKIE_NAME } from "../shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { GAME_TYPES, bootstrapPilotRules, claimDailyReward, claimMissionReward, closeAndDrawRound, closeCuratedMarket, createCuratedMarket, createDisabledYapeReference, getMarketSummary, getMissionSummary, getOperationsOverview, getPublicMarkets, getPublicRounds, getRoundProof, getSocialImpactSummary, getWalletSummary, publishRulesetRevision, registerVerificationMission, reserveMarketPosition, reservePilotTicket, resolveCuratedMarket, updatePromotionStatus, updateResponsibleSettings, voidCuratedMarket } from "./pilot";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  games: router({
    rounds: publicProcedure.query(() => getPublicRounds()),
    verify: publicProcedure.input(z.object({ publicId: z.string().min(4).max(40) })).query(({ input }) => getRoundProof(input.publicId)),
    reserveTicket: protectedProcedure.input(z.object({
      roundPublicId: z.string().min(4).max(40),
      picks: z.array(z.number().int()).min(1).max(6),
      quantity: z.number().int().min(1).max(10),
      idempotencyKey: z.string().min(8).max(96),
    })).mutation(({ ctx, input }) => reservePilotTicket({ userId: ctx.user.id, ...input })),
  }),
  wallet: router({
    summary: protectedProcedure.query(({ ctx }) => getWalletSummary(ctx.user.id)),
    claimDailyReward: protectedProcedure.mutation(({ ctx }) => claimDailyReward(ctx.user.id)),
    updateResponsibleSettings: protectedProcedure.input(z.object({
      sessionLimitMinutes: z.number().int().min(15).max(180),
      pauseHours: z.number().int().min(0).max(720),
      countryCode: z.enum(["PE", "CO", "CL", "EC", "BO", "AR", "UY", "PY"]),
    })).mutation(({ ctx, input }) => updateResponsibleSettings(ctx.user.id, input)),
  }),
  missions: router({
    summary: protectedProcedure.query(({ ctx }) => getMissionSummary(ctx.user.id)),
    claim: protectedProcedure.input(z.object({ code: z.string().min(3).max(64) })).mutation(({ ctx, input }) => claimMissionReward(ctx.user.id, input.code)),
    registerVerification: protectedProcedure.mutation(({ ctx }) => registerVerificationMission(ctx.user.id)),
  }),
  payments: router({
    createDisabledReference: protectedProcedure.input(z.object({ virtualAmount: z.number().int().positive(), idempotencyKey: z.string().min(8).max(96) })).mutation(({ ctx, input }) => createDisabledYapeReference(ctx.user.id, input.virtualAmount, input.idempotencyKey)),
  }),
  market: router({
    list: publicProcedure.query(() => getPublicMarkets()),
    summary: protectedProcedure.query(({ ctx }) => getMarketSummary(ctx.user.id)),
    reserve: protectedProcedure.input(z.object({ marketPublicId: z.string().min(4).max(40), side: z.enum(["yes", "no"]), contracts: z.number().int().min(1).max(10), idempotencyKey: z.string().min(8).max(96) })).mutation(({ ctx, input }) => reserveMarketPosition({ userId: ctx.user.id, ...input })),
    socialImpact: publicProcedure.query(() => getSocialImpactSummary()),
  }),
  operations: router({
    overview: adminProcedure.query(() => getOperationsOverview()),
    bootstrapPilot: adminProcedure.mutation(({ ctx }) => bootstrapPilotRules(ctx.user.id)),
    closeAndDraw: adminProcedure.input(z.object({ publicId: z.string().min(4).max(40) })).mutation(({ ctx, input }) => closeAndDrawRound(ctx.user.id, input.publicId)),
    publishRulesetRevision: adminProcedure.input(z.object({ gameType: z.enum(GAME_TYPES) })).mutation(({ ctx, input }) => publishRulesetRevision(ctx.user.id, input.gameType)),
    updatePromotionStatus: adminProcedure.input(z.object({ code: z.string().min(3).max(64), isActive: z.boolean() })).mutation(({ ctx, input }) => updatePromotionStatus(ctx.user.id, input.code, input.isActive)),
    createCuratedMarket: adminProcedure.input(z.object({ title: z.string().min(12).max(220), description: z.string().min(20).max(3000), category: z.enum(["cultura", "entretenimiento", "tecnologia", "educacion"]), sourceLabel: z.string().min(3).max(160), sourceUrl: z.string().url().max(512), resolutionRule: z.string().min(20).max(3000), yesPriceCredits: z.number().int().min(1).max(99), noPriceCredits: z.number().int().min(1).max(99), closesAt: z.date().refine((value) => value.getTime() > Date.now(), "El cierre debe estar en el futuro.") })).mutation(({ ctx, input }) => createCuratedMarket(ctx.user.id, input)),
    closeCuratedMarket: adminProcedure.input(z.object({ marketPublicId: z.string().min(4).max(40) })).mutation(({ ctx, input }) => closeCuratedMarket(ctx.user.id, input.marketPublicId)),
    resolveCuratedMarket: adminProcedure.input(z.object({ marketPublicId: z.string().min(4).max(40), outcome: z.enum(["yes", "no"]), resolutionUrl: z.string().url().max(512) })).mutation(({ ctx, input }) => resolveCuratedMarket(ctx.user.id, input)),
    voidCuratedMarket: adminProcedure.input(z.object({ marketPublicId: z.string().min(4).max(40), resolutionUrl: z.string().url().max(512) })).mutation(({ ctx, input }) => voidCuratedMarket(ctx.user.id, input)),
    supportedGames: publicProcedure.query(() => GAME_TYPES),
  }),
});

export type AppRouter = typeof appRouter;
