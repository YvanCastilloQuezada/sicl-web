# ARKI Next Roadmap

The Bridge is frozen. The next project is ARKI, not a new Bridge feature phase.

1. **ARKI deep capability radiography.** Compare ARKI documentation, code, runtime, tests, knowledge, optimization, BIM semantics, and representation/output. Classify each capability before implementation.
2. **Capability hardening.** Address evidence-backed gaps in the ARKI core.
3. **Trustworthy ARKI core.** Establish durable contracts, validation, provenance, and safe failure behavior.
4. **Optimization.** Improve performance only after correctness and evidence boundaries are clear.
5. **BIM and parametric semantics.** Define and verify domain models and constraints.
6. **Representation and output.** Establish reliable artifacts and interchange behavior.
7. **Frontend.** Build user-facing interaction only after the core is trustworthy.

Frontend is not the current priority. The Bridge must remain external and decoupled. No roadmap item authorizes deployment, ARKI modification, or publication by itself.

## References

[1]: ../03_NEXT_ACTION.md "Next authorized action"
[2]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Bridge boundary"
