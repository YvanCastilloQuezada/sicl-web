# R02 OpenAI Real Minimal Retry Report

**Orden:** `AB-R02-OPENAI-REAL-MINIMAL-RETRY-001`  
**Baseline:** v0.2F / `0.2.0-alpha.8`  
**Fecha:** 2026-09-25

## R2_PRE_FLIGHT

```text
OPENAI_API_KEY_PRESENT      YES
OPENAI_PROJECT_ID_PRESENT   YES
MANUS_API_KEY_PRESENT       YES
PROVIDER_MODE               mock
RUNTIME_REFRESH             COMPLETED
RETRIES                     0
```

The pre-flight was local and passed. The operation used the refreshed `OPENAI_API_KEY` and `OPENAI_PROJECT_ID` sources through `OpenAIRealAdapter` in explicit real mode for this single bounded call. The global provider mode remained `mock`.

## REAL_CALL_COUNT

```text
OPENAI_REAL_RESPONSES_CALLS=1
MAX_REAL_CALLS=1
RETRIES=0
```

Exactly one real `POST /v1/responses` call was performed. No automatic model switching, schema modification or retry occurred.

## ENDPOINT AND TELEMETRY

```text
ENDPOINT=POST /v1/responses
MODEL=gpt-4.1-mini-2025-04-14
START_TIMESTAMP_UTC=2026-09-25T10:20:34.066Z
START_TIMESTAMP_LOCAL=2026-09-25T05:20:34.066-05:00
END_TIMESTAMP_UTC=2026-09-25T10:20:37.751Z
END_TIMESTAMP_LOCAL=2026-09-25T05:20:37.751-05:00
RESPONSE_ID_PRESENT=YES
PROVIDER_REQUEST_ID_PRESENT=YES
```

No response ID or provider request ID value is reproduced.

## BOUNDARY RESULT

```text
HTTP_RESULT=2XX
AUTHENTICATION_ACCEPTED=YES
PROJECT_SCOPED_REQUEST_ACCEPTED=YES
```

The project-scoped request was accepted by the provider. The response was handled by the real adapter and did not invoke tools or external actions.

## STRUCTURED OUTPUT AND CONTRACT

The input was the authorized synthetic case involving a fictional worker returning integer 4. It contained no ARKI content, Manus content, private data, files, tools or external effects.

```text
STRUCTURED_OUTPUT_RECEIVED=YES
STRUCTURED_OUTPUT_SCHEMA_VALID=YES
CONTRACT_V1_VALID=YES
SYNTHETIC_EXPECTED_RESULT_VALID=YES
PROVIDER_OUTPUT_CLASSIFICATION=REVIEW_ALLOWED
```

The provider output was treated as an untrusted external artifact. The synthetic result was checked as model output, not as evidence of an external fact or authorization.

## USAGE / COST

```text
INPUT_TOKENS=386
OUTPUT_TOKENS=146
TOTAL_TOKENS=532
EXACT_COST=UNKNOWN
```

The provider exposed token usage. An exact cost is not recorded because a verifiable price calculation was not available in this run; no cost was invented.

## SECRET BOUNDARY

```text
SECRET_LEAK_SCAN=PASS
```

The real API key, Manus API key, Project ID, Authorization header and secret-bearing payload values were not printed or persisted. The post-call scan compared runtime values internally against source, tests, migrations, reports and controlled temporary logs without displaying them.

## EXTERNAL EFFECTS

```text
MANUS_REAL_CALLS_THIS_PHASE=0
MANUS_TASKS_CREATED=0
WEBHOOKS_REGISTERED=0
ARKI_CONNECTIONS=0
ARKI_MODIFICATIONS=0
TOOLS_EXECUTED_BY_OPENAI=0
EXTERNAL_MUTATIONS=0
```

No Manus or ARKI operation was attempted.

## REGRESSION

After the real call, local verification completed successfully:

```text
npm test                         95/95 PASS
npm run test:provider-contract  20/20 PASS
npm run test:mock-e2e            14/14 PASS
node --check                     PASS
PROVIDER_MODE                   mock
```

## FINAL CLASSIFICATION

```text
OPENAI_REAL_RESPONSES_CALLS           1
OPENAI_REAL_ADAPTER_RUNTIME_VERIFIED  YES
OPENAI_CONTRACT_V1_RUNTIME_VERIFIED   YES
STRUCTURED_OUTPUT_REAL_VERIFIED       YES
OPENAI_PROJECT_BOUNDARY               VERIFIED

SECRET_LEAK_SCAN                      PASS
EXTERNAL_MUTATIONS                    0
ARKI_MODIFICATIONS                    0
MANUS_REAL_CALLS_THIS_PHASE           0

REGRESSION                            PASS
PROVIDER_MODE_RETURNED_TO_MOCK        YES
READY_FOR_NEXT_REAL_PROVIDER_STAGE    YES
```

`READY_FOR_NEXT_REAL_PROVIDER_STAGE=YES` means technically prepared only. It is not authorization to execute R3. R3 was not started.

## STOP

R2 controlled retry is complete. No Manus task, Manus message, webhook, ARKI connection, autonomous loop, deployment or R3 operation was executed.
