# R03E — External Effect Identity Persistence Report

**Orden:** `AB-R03E-EXTERNAL-EFFECT-IDENTITY-PERSISTENCE-001` y alineación de fixtures autorizada.

## Resultado

La identidad operacional del efecto externo Manus queda persistida en el store SQLite existente antes de que el efecto pueda considerarse listo para reconciliación. La reconciliación valida la identidad durable y utiliza el mismo `provider_task_id`; no existe fallback sin identidad persistida.

```text
LEGACY_FIXTURE_ALIGNED=YES
PRODUCT_CODE_CHANGED_FOR_FIXTURE=NO
PROVIDER_TASK_ID_DURABLE_PERSISTENCE=YES
EXISTING_STORE_REUSED=YES
CREATE_PERSIST_RECONCILE_IDENTITY_INVARIANT=PASS
RESTART_RECOVERY=PASS
PERSISTENCE_FAILURE_FAIL_CLOSED=PASS
DUPLICATE_CREATE_PREVENTED=PASS
TASK_ID_LOG_EXPOSURE=PASS

TARGETED_R03E_TESTS=4/4 PASS
LEGACY_RT_G2_NEW_05=PASS
TESTS=109/109 PASS
PROVIDER_CONTRACT_TESTS=20/20 PASS
MOCK_E2E=14/14 PASS
SYNTAX=PASS
SECRET_LEAK_SCAN=PASS

REAL_MANUS_CALLS=0
REAL_OPENAI_CALLS=0
NEW_MANUS_TASKS=0
EXTERNAL_MUTATIONS=0

READY_FOR_CONTROLLED_R3_RETRY=YES
BLOCKER=NONE
```

`READY_FOR_CONTROLLED_R3_RETRY=YES` significa únicamente que el boundary local de identidad y reconciliación está preparado para una revisión humana posterior. No se ejecutó R3 ni se creó una nueva tarea Manus.

## Evidencia de implementación

La migración `005_external_effect_identity.sql` añade al registro `external_effects` los campos `provider`, `provider_task_id`, `correlation_id`, `visibility` y `reconciliation_state`, además de un índice único para la identidad Manus.

`BridgeStore` reutiliza `external_effects` para insertar y actualizar esa identidad. `ExternalEffectCoordinator.recordProviderIdentity()` persiste el identificador del proveedor antes de marcar el efecto como exitoso. Si el registro local falla después del éxito del proveedor, el efecto queda en `EXTERNAL_EFFECT_UNKNOWN` y el dispatch posterior queda bloqueado para impedir una segunda creación automática.

`Orchestrator.reconcile()` obtiene y valida la identidad persistida antes de invocar `detail` o `listMessages`. Las dos operaciones reciben el mismo identificador durable. La recuperación tras reinicio conserva el `provider_task_id` y transforma un efecto en vuelo en estado desconocido fail-closed, sin perder la identidad necesaria para reconciliación.

Los fixtures legacy de `RT-G2-NEW-05`, `F-05` y `F-06` fueron alineados para representar una tarea fake creada con identidad de proveedor durable. No se relajó `PROVIDER_ID_NOT_PERSISTED`, no se introdujo fallback y no se eliminaron assertions de revocación o del LoopGovernor.

## Archivos modificados

| Archivo | Cambio |
|---|---|
| `migrations/005_external_effect_identity.sql` | Nueva migración para identidad y estado de reconciliación del proveedor. |
| `src/store.mjs` | Persistencia, actualización y lookup por `provider_task_id`. |
| `src/external-effects.mjs` | Registro de identidad y transición a reconciliación lista. |
| `src/orchestrator.mjs` | Orden create → persist identity → task record; reconciliación desde identidad durable; replay seguro. |
| `tests/r03e-identity.test.mjs` | Cuatro pruebas R03E de persistencia, restart, fallo y deduplicación. |
| `tests/gate2-closeout.test.mjs` | Fixture `RT-G2-NEW-05` alineado. |
| `tests/redteam-remediation.test.mjs` | Fixtures `F-05` y `F-06` alineados mediante helper local de test. |
| `R03E_EXTERNAL_EFFECT_IDENTITY_PERSISTENCE_REPORT.md` | Este reporte. |

## Diff resumido

Se añadió una migración SQLite y se extendió el repositorio existente sin crear un segundo sistema de persistencia. El coordinador ahora registra la identidad del proveedor antes de `createTask` local y el orquestador rechaza reconciliaciones sin correspondencia durable. Los cambios de tests se limitaron a representar correctamente tareas fake con identidad persistida.

## Verificación y límites

La suite general pasó con 109 tests. Los contract tests pasaron con 20 tests y Mock E2E pasó con 14 escenarios. La sintaxis, el secret scan y la frontera de no-touch de ARKI pasaron. Durante esta fase no hubo llamadas reales a Manus u OpenAI, no se crearon tareas, no se enviaron mensajes, no se registraron webhooks, no se modificó ARKI y no se hizo deploy.

**Estado:** detenido conforme a la orden. No ejecutar R3 ni R4 sin revisión posterior.
