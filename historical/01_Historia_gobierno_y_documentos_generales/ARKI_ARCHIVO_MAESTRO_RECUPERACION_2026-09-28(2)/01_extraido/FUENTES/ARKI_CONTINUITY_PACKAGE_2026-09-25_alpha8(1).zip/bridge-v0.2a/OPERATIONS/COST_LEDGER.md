# Cost Ledger

| Category | Recorded value | Evidence status |
|---|---:|---|
| Useful implementation work | UNKNOWN | No monetary accounting in sandbox evidence. |
| External audit cost | 0 authorized for closeout | POLICY / runtime scope. |
| Retry/failure cost | UNKNOWN | Call counts exist; provider credit usage was not available. |
| OpenAI usage | Token telemetry recorded for R4, monetary cost UNKNOWN | R4 report. |
| Manus usage | Credit usage UNKNOWN | R4 report. |

No audit-overhead ratio is calculated because the numerator and denominator are not both verified.

## References

[1]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 usage evidence"
[2]: COST_AND_AUDIT_POLICY.md "Cost policy"
