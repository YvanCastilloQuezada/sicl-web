# Cost and Audit Policy

Normal work follows: execute the authorized action, run deterministic or local validation, and continue. External AI audits default to zero. An external audit is justified only for security, core architecture, data integrity, autonomy, publication, irreversible loss, credentials, a final critical gate, or a material contradiction.

The Bridge must separate useful work cost, audit cost, retry/failure cost, OpenAI usage, and Manus usage. When a value cannot be verified, record `UNKNOWN`. Do not infer credit cost from call count.

The audit overhead ratio is defined as:

```text
AUDIT_OVERHEAD_RATIO = verified audit cost / verified total cost
```

It is not calculated for this baseline because verified monetary totals are unavailable.

## References

[1]: COST_LEDGER.md "Closeout cost ledger"
[2]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Baseline verification"
