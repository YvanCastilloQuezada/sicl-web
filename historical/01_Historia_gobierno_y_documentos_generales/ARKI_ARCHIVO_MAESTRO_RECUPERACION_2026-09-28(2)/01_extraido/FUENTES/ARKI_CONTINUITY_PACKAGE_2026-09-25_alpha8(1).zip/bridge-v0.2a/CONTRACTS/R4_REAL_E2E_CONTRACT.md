# R4 Real E2E Contract

R4 is a controlled synthetic scenario. The order must be within the authorized Bridge scope and must explicitly prohibit ARKI access, connectors, files, browser use, publication, deployment, confirmation, and external effects.

The Manus task must be private and must receive empty connector and file arrays. The only accepted result is the exact string `ARKI_BRIDGE_R4_EXECUTION_OK`. A result that requests action, permission, confirmation, or external access is a halt condition.

The provider identity must survive a SQLite close/reopen. The result must be reconciled from the same task. OpenAI review must validate against Contract V1 and the governed decision must end in `COMPLETED`.

The contract proves the Bridge circuit only. It does not prove ARKI integration.

## References

[1]: ../src/r4-boundary.mjs "R4 boundary implementation"
[2]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 execution evidence"
