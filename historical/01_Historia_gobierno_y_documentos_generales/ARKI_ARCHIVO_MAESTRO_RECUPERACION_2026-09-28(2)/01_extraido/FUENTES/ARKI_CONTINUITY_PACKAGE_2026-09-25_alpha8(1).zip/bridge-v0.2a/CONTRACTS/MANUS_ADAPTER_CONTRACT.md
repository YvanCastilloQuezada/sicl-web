# Manus Adapter Contract

The Bridge uses Manus API v2 paths for private task creation, task detail, message listing, and optional follow-up messages. Task creation requires private visibility. R4 requires empty connectors and files and does not authorize skills, browser, publication, or external actions.

The adapter uses bounded retries for retryable transport conditions and a single delayed retry for eventual-consistency 404 responses from `task.detail`. It records sanitized status, provider error code, request ID, cursor, status, and background-job interpretation. It does not print secrets or complete task IDs in reports.

Provider task identity must be persisted before an effect is marked successful. Reconciliation must use that same durable identity. Missing identity, ambiguous success, or revocation causes a fail-closed result.

## References

[1]: https://open.manus.ai/docs/v2/task.create "Manus API v2 task.create"
[2]: https://open.manus.ai/docs/v2/task.detail "Manus API v2 task.detail"
[3]: https://open.manus.ai/docs/v2/task.listMessages "Manus API v2 task.listMessages"
[4]: ../src/manus.mjs "Manus adapter implementation"
