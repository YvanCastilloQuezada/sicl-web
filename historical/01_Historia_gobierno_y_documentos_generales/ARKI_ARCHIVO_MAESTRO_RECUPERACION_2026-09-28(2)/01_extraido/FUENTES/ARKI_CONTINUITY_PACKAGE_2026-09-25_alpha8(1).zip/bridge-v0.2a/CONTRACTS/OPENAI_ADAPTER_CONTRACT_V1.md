# OpenAI Adapter Contract V1

The Bridge preserves the existing V1-shaped Architect review interface. A review receives a correlated decision input and returns a structured output containing `decision_id`, `classification`, `assessment`, `next_action`, `scope_delta`, `requires_human`, `reason`, `evidence_to_preserve`, `acceptance_status`, `policy_category`, and `contract`.

Allowed classifications are `AUTO_ALLOWED`, `REVIEW_ALLOWED`, `HUMAN_REQUIRED`, and `PROHIBITED`. Allowed acceptance states are `PASS`, `FAIL`, `PARTIAL`, and `UNKNOWN`. Allowed policy categories are `SCOPE`, `SECURITY`, `COST`, `CREDENTIAL`, `ARCHITECTURE`, `PROFESSIONAL`, `EXECUTION`, `EVIDENCE`, and `NONE`; a null or absent category is normalized to `NONE`. Unknown categories remain invalid.

The real adapter uses the Responses API with tools disabled and strict structured output. Refusals, tool requests, malformed output, correlation mismatches, and policy violations fail closed.

`OPENAI_ADAPTER_CONTRACT_V1` is frozen. This closeout does not define a V2 contract.

## References

[1]: ../src/openai-adapter.mjs "OpenAI V1 contract and validation"
[2]: ../src/openai-real-adapter.mjs "OpenAI Responses real adapter"
[3]: ../src/policy-contract.mjs "Policy category contract"
