# ARKI Agent Bridge v0.2C.3 — Pre-Mock Hardening Report

**Orden:** `AB-V02C3-PRE-MOCK-HARDENING-001`  
**Baseline:** v0.2C.2 / `0.2.0-alpha.5`  
**Versión resultante:** `0.2.0-alpha.6`  
**Scope:** RT-G2-NEW-06, RT-G2-NEW-07, O-1, O-2 y O-3 únicamente.

## Resultado ejecutivo

El hardening pre-Mock fue implementado sin reabrir F-03, F-06, F-07 ni RT-G2-NEW-01…05. La regresión anterior se mantuvo y se añadieron las pruebas específicas de esta orden.

El resultado final es **75 tests, 75 PASS, 0 FAIL, 0 skipped**. Se ejecutaron `npm test` y `node --check src/*.mjs tests/*.mjs`. No se ejecutó Mock E2E, no se conectaron OpenAI o Manus reales y no se modificó ARKI.

## RT-G2-NEW-06 — Retry ownership

### Root cause

`ManusAdapter` mantenía `retryCount` como estado mutable de instancia. Dos requests concurrentes sobre el mismo adapter podían sobrescribir o consumir el contador del otro request. El `Orchestrator` tampoco podía demostrar que un retry pertenecía exclusivamente a una invocación.

### Code change

`src/manus.mjs` ahora mantiene `retryCount` como variable local dentro de `request()`. Cada respuesta exitosa incluye `retry_count` en su propio resultado. Los errores finales incluyen el mismo dato en la excepción.

`src/orchestrator.mjs` ahora lee únicamente `result.retry_count` o `error.retry_count`. `recordManusOutcome()` atribuye esos retries a la decisión que ejecutó la invocación. Ya no existe `consumeRetryCount()` ni contabilidad de retries compartida por instancia.

### Direct test

`RT-G2-NEW-06 concurrent adapter requests return isolated retry counts and counters` ejecuta dos requests concurrentes sobre el mismo adapter. La solicitud A produce un retry y la B produce dos. Cada resultado conserva exclusivamente su propio contador.

### Composition test

`RT-G2-NEW-06 orchestrator attributes concurrent request retries to their decisions` ejecuta dos dispatches pertenecientes a decisiones distintas y verifica que los contadores persistidos quedan en 1 y 2 respectivamente.

### Result

**IMPLEMENTED + VERIFIED** mediante evidencia de código y runtime local. El estado mutable compartido de retries fue eliminado.

### Residual risk

La prueba usa transportes fake. No se verificó concurrencia multiproceso ni comportamiento de un cliente Manus real bajo saturación o cancelación.

## RT-G2-NEW-07 — Atomic review recovery claim

### Root cause

La recuperación anterior hacía un `SELECT` seguido de un `UPDATE` sin exigir que el estado siguiera siendo recuperable. Dos actores podían observar el mismo estado de recovery antes de actualizarlo.

### Code change

`BridgeStore.claimReview()` ahora ejecuta una actualización condicional equivalente a:

```sql
UPDATE review_claims
SET status = 'CLAIMED', updated_at = ?
WHERE review_id = ?
  AND status IN ('RECOVERY_REQUIRED', 'FAILED', 'UNKNOWN')
```

El resultado solo es `claimed: true` cuando `changes === 1`. Si otro actor ganó la recuperación, el resultado es `claimed: false` y se devuelve el claim vencedor.

### Direct test

`RT-G2-NEW-07 recovery claim contention has one winner` coloca un claim en `RECOVERY_REQUIRED` y ejecuta dos recuperaciones. Solo una obtiene `claimed: true`.

### Composition test

`RT-G2-NEW-03 claimed review is recovered after actual store restart` verifica la secuencia `CLAIMED → RECOVERY_REQUIRED → CLAIMED` después de reabrir SQLite. El flujo `reviewWithArchitect()` continúa usando el claim persistente antes de iniciar una review.

### Result

**IMPLEMENTED + VERIFIED** en el store SQLite local. La recuperación es atómica a nivel de la operación condicional.

### Residual risk

No se ejecutó una prueba distribuida entre varios procesos o hosts. La garantía verificada corresponde a SQLite y al runtime local.

## O-2 — Budget preflight

### Root cause

El flujo OpenAI podía contabilizar una llamada y luego iniciar otra sin comprobar si el presupuesto restante permitía el flujo completo. En particular, una sesión nueva podía requerir `createSession` y `review` cuando solo quedaba una llamada.

### Code change

`BudgetEnforcer.checkExternalCalls(decisionId, needed)` comprueba el número total de llamadas necesarias antes de iniciar el flujo. `reviewWithArchitect()` calcula `needed = 2` cuando no existe sesión y `needed = 1` cuando ya existe. El orden es ahora:

```text
CHECK → ALLOW → ACCOUNT → EXTERNAL CALL
```

Si el preflight devuelve un resultado restrictivo, el claim se cierra como bloqueado y la llamada externa no comienza.

`ExternalEffectCoordinator.begin()` ya ejecuta el control antes de persistir el intent o llamar al provider. Por ello `manus.createTask` y `manus.sendMessage` no overshootan `max_external_calls`.

Las transiciones internas continúan usando `budgetKind = control`; no consumen ni requieren presupuesto de llamada externa.

### Direct tests

- `O-2 dispatch budget preflight with zero remaining makes zero Manus calls` verifica cero llamadas Manus con presupuesto restante cero.
- `O-2 new OpenAI session preflights two calls and does not overshoot remaining one` verifica que una sesión nueva no inicia `createSession` cuando solo queda una llamada.

### Composition test

Los tests existentes de dispatch, sendMessage, sesiones OpenAI, post-review gate y usage budget ejecutan el flujo completo con el preflight instalado.

### Result

**IMPLEMENTED + VERIFIED**. Se evita el overshoot de llamadas externas en los bordes probados.

### Residual risk

No se comprobó la aplicación de límites de costo monetario con un provider real. La implementación no inventa precios y depende del usage recibido por el adapter.

## O-3 — Local persistence failure

### Root cause

Después de un éxito del provider, una excepción de persistencia local podía quedar sin observación suficiente. El sistema debía conservar la incertidumbre del efecto externo y no convertirla en un fallo confirmado del provider.

### Code change

Los caminos de persistencia posterior a éxito externo en `dispatch()` y `sendMessage()` ahora:

1. mantienen el efecto como `EXTERNAL_EFFECT_UNKNOWN`;
2. incrementan la observación de fallo del `LoopGovernor`;
3. registran `local.persistence.failed_after_provider_success` en el audit log;
4. no llaman a `markFailure()` del efecto;
5. no asumen que Manus rechazó la operación.

### Direct test

`O-3 local persistence failure records Loop/Audit and keeps provider effect UNKNOWN` fuerza un fallo de `createTask()` después de que el provider fake haya respondido con éxito. Verifica el estado `EXTERNAL_EFFECT_UNKNOWN`, `consecutive_failures = 1` y la entrada de audit.

### Composition test

`F-03 local persistence failure after provider success becomes UNKNOWN and blocks blind redispatch` conserva la prueba previa de redispatch seguro. El nuevo comportamiento añade la observación de Loop/Audit sin cambiar la semántica `UNKNOWN`.

### Result

**IMPLEMENTED + VERIFIED** para dispatch y para el camino de persistencia de mensajes. El efecto externo no se marca como `FAILED`.

### Residual risk

La reconciliación final del provider sigue siendo necesaria para determinar si el efecto desconocido ocurrió, se completó o debe compensarse.

## O-1 — Legacy KillSwitch.set()

### Root cause

`KillSwitch.set(decisionId, ...)` combinaba dos semánticas: modificaba el estado scoped de una decisión y también escribía el archivo out-of-band. Esto permitía que un caller interpretara la operación como scoped cuando en realidad activaba un control global.

### Code change

Las APIs explícitas son ahora:

- `setDecision(decisionId, state, actor, reason)` para control scoped;
- `setGlobal(state, actor, reason)` para control out-of-band global.

El método `set()` se conserva solo por compatibilidad con tests y consumidores legacy. Está marcado `@deprecated` y documentado inequívocamente como alias **global**. El `decisionId` solo se conserva para reflejo de auditoría y compatibilidad de restart; no cambia la semántica global.

Los callers de producción del Bridge usan `setDecision()` para revocación scoped. `revokeDecision()` ya no activa el archivo global.

### Direct test

`O-1 scoped setDecision never writes OOB global file; setGlobal does` verifica que `setDecision()` no escribe el archivo global y que `setGlobal()` sí lo activa.

### Composition test

`RT-G2-NEW-05 revocation is per decision while global OOB kill applies to all` demuestra que una revocación scoped afecta a una decisión, mientras que el kill global afecta a todas.

### Result

**IMPLEMENTED + VERIFIED**. La API nueva elimina la ambigüedad para callers de producción. El alias legacy restante está explícitamente deprecado y documentado.

### Residual risk

Un consumidor externo que invoque deliberadamente `set()` seguirá obteniendo la semántica global legacy. La mitigación es documental y de API; una futura versión mayor puede eliminar definitivamente el alias.

## Regression lock and hard gate

| Control | Resultado |
|---|---|
| Tests baseline antes del hardening | 68/68 PASS |
| Tests adicionales V02C3 | 7/7 PASS |
| Tests totales | 75/75 PASS |
| `node --check src/*.mjs tests/*.mjs` | PASS |
| Mock E2E | 0 |
| OpenAI real | 0 |
| Manus real | 0 |
| Credenciales reales | 0 |
| E2E real | 0 |
| Modificaciones ARKI | 0 |
| Deploy de producción | 0 |
| Webhook público | 0 |

## Files changed

- `src/manus.mjs`
- `src/orchestrator.mjs`
- `src/store.mjs`
- `src/loop-budget.mjs`
- `src/autonomy-control.mjs`
- `tests/gate2-closeout.test.mjs`
- `tests/redteam-remediation.test.mjs`
- `package.json`
- `README.md`
- `V02C3_PRE_MOCK_HARDENING_REPORT.md`

No migration was required.

## Readiness

| Gate | Status | Meaning |
|---|---|---|
| READY FOR CHATGPT VERIFICATION | YES | Source, tests, report, manifest and ZIP are available. |
| READY FOR MOCK E2E | YES | Technical readiness only. This order did not authorize execution. |
| READY FOR REAL CREDENTIALS | NO | No real credentials are configured or validated. |
| READY FOR REAL E2E | NO | No real provider calls or production environment were used. |

**STOP condition:** Mock E2E remains unexecuted. No provider connection or ARKI modification was performed.

## References

The report contains no external factual claims requiring provider documentation. Test execution uses the Node.js test runner semantics documented in [1].

[1]: https://nodejs.org/api/test.html "Node.js test runner documentation"
