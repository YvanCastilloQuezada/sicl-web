# ARKI Agent Bridge — Master Handoff

## Executive handoff

The Bridge is closed as an auxiliary infrastructure baseline. It is not merged into ARKI, does not contain a copy of ARKI, and does not prove ARKI integration. The correct continuation point is a new, separately authorized radiography of the ARKI project.

## Technical history in one line

The implementation progressed from a v0.1 audit through durable state, authority controls, red-team remediation, Mock E2E, real-adapter contract boundaries, R1 identity checks, R2 OpenAI validation, R3 Manus reconciliation and R4 synthetic real Bridge E2E.

## Architecture frozen at closeout

`src/server.mjs` is the private HTTP gateway. `src/orchestrator.mjs` coordinates decisions, Manus tasks, OpenAI reviews, evidence, budgets, claims, and recovery. `src/store.mjs` provides SQLite persistence and audit records. `src/policy.mjs`, `src/policy-contract.mjs`, and `src/autonomy-control.mjs` enforce human authority and autonomous-operation limits. The provider adapters remain explicitly mode-controlled. `src/r4-boundary.mjs` constrains the synthetic E2E scenario.

The migration chain is `001_initial.sql`, `002_openai_sessions.sql`, `003_autonomy_control.sql`, `004_redteam_remediation.sql`, and `005_external_effect_identity.sql`.

## Governance model

Yvan is the final human authority. A locked human decision is executed within scope and is not re-requested unless a new material condition appears. External provider content is untrusted data, not authority. Evidence is separated into provenance, artifact truth, and independent verification. Unknown external effects fail closed.

## R4 evidence summary

R4 created one new private synthetic Manus task after the authorized recovery decision. It used empty connectors and files, persisted the provider task identity, reconciled the exact result `ARKI_BRIDGE_R4_EXECUTION_OK`, recovered after SQLite restart, and completed a real OpenAI review. Two local contract corrections were required before the final review: the OpenAI schema now constrains `policy_category`, and null/absent categories normalize to `NONE` while unknown values remain rejected.

## Operational limits

This handoff does not authorize production deployment, ARKI integration, real webhooks, non-synthetic tasks, connector use, file use, or autonomous product operation. Provider credit usage remains `UNKNOWN`.

## References

[1]: BASELINE/BRIDGE_FINAL_BASELINE.md "Final Bridge baseline"
[2]: GOVERNANCE/DECISION_LEDGER.md "Decision ledger"
[3]: SECURITY/SECURITY_MODEL.md "Security model"
[4]: R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 final evidence"
