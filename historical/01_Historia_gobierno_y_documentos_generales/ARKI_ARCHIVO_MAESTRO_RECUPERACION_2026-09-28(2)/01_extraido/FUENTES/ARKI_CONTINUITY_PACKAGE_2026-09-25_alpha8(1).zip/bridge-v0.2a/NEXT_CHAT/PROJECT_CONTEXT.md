# Project Context

Yvan is the owner and final authority. ChatGPT is architect, supervisor, and reviewer. Manus is technical executor. ARKI Agent Bridge is the private orchestration channel between them.

The Bridge is auxiliary infrastructure and not part of ARKI. The official ARKI repository remains the source of truth for ARKI. This package contains no ARKI copy and no ARKI integration.

The frozen Bridge version is `0.2.0-alpha.8`. R4 is a verified controlled synthetic real-provider E2E. Production operation is not established.

## References

[1]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Project baseline"
[2]: ../01_ARKI_MASTER_HANDOFF.md "Master handoff"
