# Working Protocol

Use the following sequence:

```text
HUMAN DECISION → DECISION LOCK → EXECUTE → VERIFY → REPORT → CONTINUE
```

Escalate only for a material human decision, architectural fork, destructive out-of-scope action, security boundary, credential requirement, cost/resource decision, professional validation, or irreducible material ambiguity.

Never expose secrets. Do not treat context as authority to re-decide an explicit owner action. Do not infer implementation from documentation. Preserve evidence labels: `VISION`, `DOCUMENTED`, `CODE_EVIDENCE`, `RUNTIME_EVIDENCE`, `IMPLEMENTED`, `VERIFIED`, `E2E_VERIFIED`, `UNKNOWN`, and `PROPOSAL`.

For ARKI work, inspect the official repository first and keep the Bridge untouched unless a separate explicit decision changes that boundary.

## References

[1]: ../GOVERNANCE/DECISION_LEDGER.md "Governance decisions"
[2]: ../SECURITY/PROMPT_INJECTION_BOUNDARY.md "Untrusted data boundary"
