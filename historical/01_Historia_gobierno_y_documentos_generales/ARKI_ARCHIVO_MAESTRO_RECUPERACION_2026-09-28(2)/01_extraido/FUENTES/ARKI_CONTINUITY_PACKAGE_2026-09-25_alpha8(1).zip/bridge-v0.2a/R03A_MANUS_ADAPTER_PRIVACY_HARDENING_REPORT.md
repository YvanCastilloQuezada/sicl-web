# R03A Manus Adapter Privacy & Capability Hardening Report

**Baseline:** v0.2F / `0.2.0-alpha.8`  
**Fecha:** 2026-09-25  
**Real provider calls:** 0

## MANUS_SHARE_VISIBILITY_SUPPORTED

```text
YES
```

The official `task.create` documentation identifies `share_visibility` with the values `private`, `team` and `public`; it documents `private` as the provider default and states that `share_url` is only returned when visibility is not private.

## MANUS_PRIVATE_DEFAULT_DOCUMENTED

```text
YES
```

The Bridge no longer relies silently on that provider default.

## Hardening implemented

```text
EXPLICIT_PRIVATE_SERIALIZATION_IMPLEMENTED=YES
PRIVATE_RESPONSE_VALIDATION_IMPLEMENTED=YES
NON_PRIVATE_FAIL_CLOSED_IMPLEMENTED=YES
```

`ManusAdapter.createTask()` now:

- defaults locally to `share_visibility: "private"`;
- serializes `share_visibility: "private"` explicitly in every allowed task creation request;
- rejects caller-requested `public`, `team` or unknown visibility before network access;
- requires the response visibility to be exactly `private`;
- rejects a private response that includes `share_url`;
- rejects non-array connector/skill configuration before network access.

## CONNECTOR_DEFAULT_RISK

```text
CONNECTOR_DEFAULT_RISK=DOCUMENTATION_SEMANTICS_NOT_SUFFICIENTLY_EXPLICIT
CONNECTORS_EXPLICIT_NONE_IMPLEMENTED=SERIALIZED_AS_EMPTY_ARRAY
```

The adapter now sends `message.connectors: []` for the governed default path instead of omitting connector configuration. However, the official page inspected states that the message contains connector/skill configuration but does not explicitly define, in the accessible contract text, that an empty connector array disables all project/user defaults. Therefore this report does not claim the provider-side “none” semantic as verified.

## SKILL_DEFAULT_RISK

```text
SKILL_DEFAULT_RISK=DOCUMENTATION_SEMANTICS_NOT_SUFFICIENTLY_EXPLICIT
SKILLS_EXPLICIT_NONE_IMPLEMENTED=SERIALIZED_AS_EMPTY_ARRAYS
```

The adapter now sends `message.enable_skills: []` and `message.force_skills: []` for the governed default path. The accessible official contract text does not explicitly establish that empty arrays disable every project/user skill default. This remains a provider-contract blocker rather than an assumed success.

## Tests added

Local tests cover:

- explicit private visibility serialization;
- explicit empty connector/skill arrays;
- rejection of public/team/unknown visibility before network access;
- rejection of malformed capability configuration;
- acceptance of private response;
- rejection of non-private response;
- rejection of `share_url` on a private response;
- existing Manus adapter regression and retry behavior.

## Verification

```text
TESTS=99/99 PASS
PROVIDER_CONTRACT_TESTS=20/20 PASS
MOCK_E2E=14/14 PASS
SYNTAX=PASS
SECRET_LEAK_SCAN=PASS
PROVIDER_MODE=mock
```

No real provider was contacted. Secret scanning compared runtime values internally without printing them and found no secret value in source, tests, reports or controlled logs.

## Files modified

```text
src/manus.mjs
 tests/manus-orchestrator.test.mjs
 tests/provider-contract.test.mjs
 tests/gate2-closeout.test.mjs
```

No OpenAI adapter, OpenAI contract, Evidence Taxonomy, Decision Policy, Autonomy Control Layer, webhook cryptography, ARKI source or deployment configuration was modified.

## Diff summary

```text
src/manus.mjs
  createTask changed from implicit provider defaults to explicit private visibility and explicit empty capability arrays.
  Response visibility is validated fail-closed.

tests/manus-orchestrator.test.mjs
  Added four local privacy, capability and response-boundary tests.

tests/provider-contract.test.mjs
  Updated fake task.create response to include share_visibility=private.

tests/gate2-closeout.test.mjs
  Updated fake task.create responses to include share_visibility=private.
```

## Classification

```text
REAL_MANUS_CALLS=0
REAL_OPENAI_CALLS=0
EXTERNAL_MUTATIONS=0
```

## READY_FOR_R3_RETRY

```text
NO
```

## BLOCKER

```text
BLOCKER=MANUS_CONNECTOR_DEFAULT_BOUNDARY + MANUS_SKILL_DEFAULT_BOUNDARY
```

The local adapter now expresses the intended no-capability payload, but the accessible official contract does not prove that empty arrays disable project/user defaults. R3 must not be retried until that provider semantic is established by authoritative documentation or an explicitly authorized contract decision. No automatic assumption or real task creation was made.

## STOP

R3A hardening is complete. No R3 task, reconciliation call, OpenAI call, webhook, ARKI operation, credential change or deployment was performed.
