# Capability and Limitation Ledger

| Capability | Classification | Evidence and limit |
|---|---|---|
| OpenAI real adapter | VERIFIED | R2 and R4 runtime evidence plus contract tests. |
| Manus real adapter | VERIFIED | R3 and R4 runtime evidence plus contract tests. |
| Durable provider identity | VERIFIED | R3/R4 SQLite persistence and restart recovery. |
| SQLite restart recovery | VERIFIED | R3/R4 close and reopen path. |
| Synthetic real Bridge E2E | VERIFIED | R4 exact controlled result and governed completion. |
| Human Authority and Decision Lock | IMPLEMENTED_NOT_REAL_VERIFIED | Local code and deterministic tests; no production deployment. |
| Webhook verification | IMPLEMENTED_NOT_REAL_VERIFIED | Code and fake-HTTP tests; no live webhook registered. |
| Production deployment | OUT_OF_SCOPE | No deployment or publication occurred. |
| ARKI real integration | OUT_OF_SCOPE | Explicitly not connected or verified. |
| Manus credit cost | UNKNOWN | No reliable usage accounting was available in the closeout evidence. |
| Provider key rotation | UNKNOWN | Not tested against live rotation. |
| High-concurrency live behavior | UNKNOWN | Local concurrency tests do not establish provider behavior. |
| Autonomous ARKI operation | OUT_OF_SCOPE | No ARKI integration exists in this baseline. |

`VERIFIED` means runtime or independently reproducible evidence exists for the stated scope. `IMPLEMENTED_NOT_REAL_VERIFIED` means code and local tests exist but the live claim is not established. `DOCUMENTED_ONLY` claims are not elevated in this ledger unless supported. `UNKNOWN` is not a failure; it is an explicit evidence boundary.

## References

[1]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Final baseline"
[2]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 evidence"
