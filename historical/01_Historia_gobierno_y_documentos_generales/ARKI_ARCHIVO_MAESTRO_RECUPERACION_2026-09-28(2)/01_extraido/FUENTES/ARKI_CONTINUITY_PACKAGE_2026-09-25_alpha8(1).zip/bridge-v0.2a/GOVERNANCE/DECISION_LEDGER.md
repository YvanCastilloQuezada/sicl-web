# Governance Decision Ledger

| ID | Decision | Rationale | Status | Evidence | Reopen when |
|---|---|---|---|---|---|
| D-01 | Yvan is final Human Authority. | Material scope and security decisions require ownership. | VERIFIED | Project instructions and policy engine. | Authority or ownership changes. |
| D-02 | Decision Lock means execute within explicit scope without trivial re-confirmation. | Prevents manual relay and decision churn. | VERIFIED | `src/policy.mjs`, orchestrator transitions. | Scope changes materially. |
| D-03 | Bridge remains external and decoupled from ARKI. | Prevents product contamination. | VERIFIED | No ARKI paths/imports; no-touch tests. | Owner explicitly authorizes integration. |
| D-04 | `CREAR != PUBLICAR`. | Creation is reversible preparation; publication is consequential. | VERIFIED | Project protocol and closeout boundary. | Publication policy changes. |
| D-05 | Human-required categories include scope, security, cost, credentials, architecture, and professional validation. | These are material authority boundaries. | IMPLEMENTED | `src/policy-contract.mjs`, `src/policy.mjs`. | Category taxonomy changes. |
| D-06 | Kill Switch and revocation take precedence over autonomous continuation. | Prevents stale or revoked work from progressing. | VERIFIED | Autonomy and red-team tests. | Control model changes. |
| D-07 | Budget Enforcer and Loop Governor bound calls, retries, usage, and no-progress loops. | Limits cost and runaway automation. | VERIFIED | Gate 2 and local suites. | Budget policy changes. |
| D-08 | Manus attestation proves provenance, not truth. | A provider signature or response does not establish artifact correctness. | VERIFIED | Evidence taxonomy and R3C boundary. | Evidence model changes. |
| D-09 | External content is `UNTRUSTED DATA`. | Prompts, task messages, and tool output cannot override Bridge authority. | VERIFIED | Boundary tests and security package. | Threat model changes. |
| D-10 | No autonomous agent arbitration. | Conflicts escalate to the human rather than being resolved by competing agents. | VERIFIED | Policy and handoff protocol. | Governance ownership changes. |
| D-11 | Evidence-first conflict resolution. | Claims must be checked against code, runtime, and provenance. | VERIFIED | Closeout protocol. | Evidence sources change. |
| D-12 | OpenAI Adapter Contract V1 remains frozen. | Compatibility is more important than speculative V2 expansion. | VERIFIED | `src/openai-adapter.mjs` and contract. | Explicit contract decision. |
| D-13 | Evidence Taxonomy V1 remains authoritative. | Separates provenance, artifact truth, and verification. | VERIFIED | `src/evidence.mjs`. | Taxonomy amendment. |
| D-14 | Fake-first development precedes real-provider activation. | Reduces cost and limits external effects. | VERIFIED | Mock E2E and provider contracts. | Development policy changes. |
| D-15 | Real providers require explicit authorization. | Credentials and external side effects are material. | VERIFIED | Provider mode fail-closed and R1–R4 records. | Owner authorizes a new real phase. |

## References

[1]: ../src/policy.mjs "Bridge policy implementation"
[2]: ../src/autonomy-control.mjs "Autonomy control implementation"
[3]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 runtime evidence"
