# ARKI Agent Bridge — Mock E2E Report

**Command:** `npm run test:mock-e2e`
**Classification:** `MOCK_E2E_VERIFIED` is not asserted by this harness; ChatGPT verification remains required.
**Total scenarios:** 14
**PASS:** 14
**FAIL:** 0
**Real OpenAI:** 0
**Real Manus:** 0
**Real credentials:** 0
**Real E2E:** 0
**ARKI modifications:** 0
**Production deploy:** 0

## Scenario results

### E2E-01

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D001","path":"Gateway create → dispatch → reconcile → Orchestrator review"}
- Expected: "AUTHORIZED→DISPATCHED→RUNNING→RESULT_RECEIVED→REVIEW_REQUIRED→COMPLETED"
- Actual: [{"from_state":"CREATED","to_state":"AUTHORIZED"},{"from_state":"AUTHORIZED","to_state":"DISPATCHED"},{"from_state":"DISPATCHED","to_state":"RUNNING"},{"from_state":"RUNNING","to_state":"RESULT_RECEIVED"},{"from_state":"RESULT_RECEIVED","to_state":"REVIEW_REQUIRED"},{"from_state":"REVIEW_REQUIRED","to_state":"COMPLETED"}]
- External effects attempted/executed: 1/1
- Evidence generated: 1
- Final state: COMPLETED
- Verdict: **PASS**

### E2E-02

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D002","path":"execute → review FAIL → correction → re-execute → review PASS"}
- Expected: "...→CORRECTION_REQUIRED→DISPATCHED→RUNNING→RESULT_RECEIVED→COMPLETED"
- Actual: [{"from_state":"CREATED","to_state":"AUTHORIZED"},{"from_state":"AUTHORIZED","to_state":"DISPATCHED"},{"from_state":"DISPATCHED","to_state":"RUNNING"},{"from_state":"RUNNING","to_state":"RESULT_RECEIVED"},{"from_state":"RESULT_RECEIVED","to_state":"REVIEW_REQUIRED"},{"from_state":"REVIEW_REQUIRED","to_state":"CORRECTION_REQUIRED"},{"from_state":"CORRECTION_REQUIRED","to_state":"DISPATCHED"},{"from_state":"DISPATCHED","to_state":"RUNNING"},{"from_state":"RUNNING","to_state":"RESULT_RECEIVED"},{"from_state":"RESULT_RECEIVED","to_state":"REVIEW_REQUIRED"},{"from_state":"REVIEW_REQUIRED","to_state":"COMPLETED"}]
- External effects attempted/executed: 2/2
- Evidence generated: 2
- Final state: COMPLETED
- Verdict: **PASS**

### E2E-03

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D003","architect":"HUMAN_REQUIRED / SECURITY"}
- Expected: "HUMAN_DECISION_REQUIRED with no continuation"
- Actual: [{"from_state":"CREATED","to_state":"AUTHORIZED"},{"from_state":"AUTHORIZED","to_state":"DISPATCHED"},{"from_state":"DISPATCHED","to_state":"RUNNING"},{"from_state":"RUNNING","to_state":"RESULT_RECEIVED"},{"from_state":"RESULT_RECEIVED","to_state":"REVIEW_REQUIRED"},{"from_state":"REVIEW_REQUIRED","to_state":"HUMAN_DECISION_REQUIRED"}]
- External effects attempted/executed: 1/1
- Evidence generated: 1
- Final state: HUMAN_DECISION_REQUIRED
- Verdict: **PASS**

### E2E-04

- Initial state: `DISPATCHED`
- Inputs: {"decision_id":"MOCK-E2E-D004","action":"revoke while detail is pending"}
- Expected: "revoked decision remains DISPATCHED; unrelated decision ALLOW"
- Actual: {"late_event_ignored":true,"other":"AUTHORIZED"}
- External effects attempted/executed: 1/1
- Evidence generated: 0
- Final state: DISPATCHED
- Verdict: **PASS**

### E2E-05

- Initial state: `AUTHORIZED`
- Inputs: {"decisions":["MOCK-E2E-D005-A","MOCK-E2E-D005-B"],"action":"global HARD_HALTED"}
- Expected: "both HALT and zero new external effects"
- Actual: {"a":"HALT","b":"HALT"}
- External effects attempted/executed: 0/0
- Evidence generated: 0
- Final state: HALT
- Verdict: **PASS**

### E2E-06

- Initial state: `AUTHORIZED`
- Inputs: {"decision_id":"MOCK-E2E-D006","budgets":[0,1]}
- Expected: "zero provider calls when required budget is unavailable"
- Actual: {"manus_calls":0,"openai_calls":0}
- External effects attempted/executed: 0/0
- Evidence generated: 0
- Final state: HALT
- Verdict: **PASS**

### E2E-07

- Initial state: `AUTHORIZED`
- Inputs: {"decision_id":"MOCK-E2E-D007","limit":"max_consecutive_failures=1"}
- Expected: "first failure then HALT with no later call"
- Actual: {"calls":1,"result":"HALT"}
- External effects attempted/executed: 1/0
- Evidence generated: 0
- Final state: HALT
- Verdict: **PASS**

### E2E-08

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D008","event":"same logical verified event twice"}
- Expected: "first processed, duplicate ignored, one event row"
- Actual: {"first":false,"duplicate":true,"rows":1}
- External effects attempted/executed: 1/1
- Evidence generated: 1
- Final state: RESULT_RECEIVED
- Verdict: **PASS**

### E2E-09

- Initial state: `INTENT_PERSISTED`
- Inputs: {"decision_id":"MOCK-E2E-D009","action":"restart while IN_FLIGHT"}
- Expected: "IN_FLIGHT→UNKNOWN and blind redispatch prohibited"
- Actual: "EXTERNAL_EFFECT_UNKNOWN"
- External effects attempted/executed: 0/0
- Evidence generated: 0
- Final state: UNKNOWN
- Verdict: **PASS**

### E2E-10

- Initial state: `CLAIMED`
- Inputs: {"decision_id":"MOCK-E2E-D010","action":"restart and atomic claim recovery"}
- Expected: "one recovery winner and zero duplicate reviews"
- Actual: {"winner":1}
- External effects attempted/executed: 1/1
- Evidence generated: 0
- Final state: RECOVERY_REQUIRED→CLAIMED
- Verdict: **PASS**

### E2E-11

- Initial state: `AUTHORIZED`
- Inputs: {"decision_id":"MOCK-E2E-D011","failure":"local persistence after provider success"}
- Expected: "provider success + local failure = UNKNOWN"
- Actual: "EXTERNAL_EFFECT_UNKNOWN"
- External effects attempted/executed: 1/1
- Evidence generated: 0
- Final state: UNKNOWN
- Verdict: **PASS**

### E2E-12

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D012","attack":"producer declares INDEPENDENTLY_VERIFIED"}
- Expected: "laundering rejected, authorized verifier accepted"
- Actual: "INDEPENDENTLY_VERIFIED"
- External effects attempted/executed: 0/0
- Evidence generated: 1
- Final state: VERIFIED
- Verdict: **PASS**

### E2E-13

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D013","attack":"untrusted scope injection"}
- Expected: "untrusted data contained and material result escalated"
- Actual: "HUMAN_DECISION_REQUIRED"
- External effects attempted/executed: 1/1
- Evidence generated: 1
- Final state: HUMAN_DECISION_REQUIRED
- Verdict: **PASS**

### E2E-14

- Initial state: `CREATED`
- Inputs: {"decision_id":"MOCK-E2E-D014","action":"reconstruct persisted record"}
- Expected: "decision, authorization, dispatch, effect, result, evidence, review, final state reconstructable"
- Actual: {"transitions":[{"from_state":"CREATED","to_state":"AUTHORIZED"},{"from_state":"AUTHORIZED","to_state":"DISPATCHED"},{"from_state":"DISPATCHED","to_state":"RUNNING"},{"from_state":"RUNNING","to_state":"RESULT_RECEIVED"},{"from_state":"RESULT_RECEIVED","to_state":"REVIEW_REQUIRED"},{"from_state":"REVIEW_REQUIRED","to_state":"COMPLETED"}],"effects":[{"operation":"manus.createTask","status":"SUCCEEDED"}],"evidence":1,"audit":16,"counters":{"cycles":1,"corrections":0,"external_calls":3,"retries":0}}
- External effects attempted/executed: 1/1
- Evidence generated: 1
- Final state: COMPLETED
- Verdict: **PASS**

## Evidence classification

This report uses CLAIMED, CODE_EVIDENCE, RUNTIME_EVIDENCE, INTEGRITY_VERIFIED, PROVENANCE_VERIFIED, INDEPENDENTLY_VERIFIED and UNKNOWN only. It does not claim REAL_E2E_VERIFIED or REAL_PROVIDER_VERIFIED.

## Readiness

- READY FOR CHATGPT VERIFICATION: YES
- READY FOR REAL-PROVIDER PREPARATION: NO
- READY FOR REAL CREDENTIALS: NO
- READY FOR REAL E2E: NO
- READY FOR ARKI CONNECTION: NO

## References

[1]: https://nodejs.org/api/test.html "Node.js test runner documentation"
