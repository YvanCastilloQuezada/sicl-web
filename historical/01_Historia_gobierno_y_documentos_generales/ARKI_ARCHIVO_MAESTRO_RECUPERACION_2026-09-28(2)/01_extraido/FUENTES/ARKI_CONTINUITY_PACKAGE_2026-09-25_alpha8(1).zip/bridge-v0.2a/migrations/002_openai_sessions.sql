CREATE TABLE IF NOT EXISTS openai_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  decision_id TEXT NOT NULL UNIQUE REFERENCES decisions(id),
  session_id TEXT NOT NULL UNIQUE,
  agent_name TEXT NOT NULL,
  status TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS openai_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  event_type TEXT NOT NULL,
  external_event_id TEXT,
  session_id TEXT NOT NULL,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  payload_json TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL,
  received_at INTEGER NOT NULL,
  processed_at INTEGER,
  processing_status TEXT NOT NULL,
  UNIQUE(source, external_event_id),
  UNIQUE(source, payload_sha256)
);

CREATE INDEX IF NOT EXISTS idx_openai_events_session ON openai_events(session_id, id);
CREATE INDEX IF NOT EXISTS idx_openai_events_decision ON openai_events(decision_id, id);
