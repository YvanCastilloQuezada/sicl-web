ALTER TABLE external_effects ADD COLUMN provider TEXT;
ALTER TABLE external_effects ADD COLUMN provider_task_id TEXT;
ALTER TABLE external_effects ADD COLUMN correlation_id TEXT;
ALTER TABLE external_effects ADD COLUMN visibility TEXT;
ALTER TABLE external_effects ADD COLUMN reconciliation_state TEXT NOT NULL DEFAULT 'PENDING';

CREATE UNIQUE INDEX IF NOT EXISTS idx_external_effect_provider_task
  ON external_effects(provider, provider_task_id)
  WHERE provider IS NOT NULL AND provider_task_id IS NOT NULL;
