ALTER TABLE decisions ADD COLUMN revoked_at INTEGER;
ALTER TABLE decisions ADD COLUMN revoked_by TEXT;
ALTER TABLE decisions ADD COLUMN revocation_reason TEXT;

CREATE TABLE IF NOT EXISTS autonomy_controls (
  decision_id TEXT PRIMARY KEY REFERENCES decisions(id),
  kill_state TEXT NOT NULL DEFAULT 'RUNNING',
  budget_json TEXT NOT NULL DEFAULT '{}',
  loop_json TEXT NOT NULL DEFAULT '{}',
  security_state TEXT NOT NULL DEFAULT 'CLEAR',
  evidence_state TEXT NOT NULL DEFAULT 'UNKNOWN',
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS autonomy_counters (
  decision_id TEXT PRIMARY KEY REFERENCES decisions(id),
  cycles INTEGER NOT NULL DEFAULT 0,
  corrections INTEGER NOT NULL DEFAULT 0,
  external_calls INTEGER NOT NULL DEFAULT 0,
  retries INTEGER NOT NULL DEFAULT 0,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  elapsed_started_at INTEGER NOT NULL,
  usage_json TEXT NOT NULL DEFAULT '{}',
  last_action_hash TEXT,
  last_result_hash TEXT,
  repeated_action_count INTEGER NOT NULL DEFAULT 0,
  stagnant_result_count INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence (
  evidence_id TEXT PRIMARY KEY,
  evidence_type TEXT NOT NULL,
  source TEXT NOT NULL,
  producer TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  artifact_hash TEXT,
  provenance TEXT NOT NULL,
  integrity_status TEXT NOT NULL,
  verification_status TEXT NOT NULL,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  correlation_id TEXT NOT NULL,
  claim TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS external_effects (
  effect_id TEXT PRIMARY KEY,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  operation TEXT NOT NULL,
  idempotency_key TEXT,
  status TEXT NOT NULL,
  intent_hash TEXT NOT NULL,
  provider_reference TEXT,
  result_hash TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE(decision_id, intent_hash)
);

CREATE INDEX IF NOT EXISTS idx_evidence_decision ON evidence(decision_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_external_effects_decision ON external_effects(decision_id, updated_at);
