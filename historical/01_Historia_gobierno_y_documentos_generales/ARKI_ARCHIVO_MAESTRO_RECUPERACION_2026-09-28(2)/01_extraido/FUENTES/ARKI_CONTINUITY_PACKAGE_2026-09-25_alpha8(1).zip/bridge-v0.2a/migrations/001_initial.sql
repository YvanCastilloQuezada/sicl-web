CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS decisions (
  id TEXT PRIMARY KEY,
  owner_subject TEXT NOT NULL,
  project TEXT NOT NULL,
  context TEXT NOT NULL,
  why TEXT NOT NULL,
  objective TEXT NOT NULL,
  execution TEXT NOT NULL,
  preserve TEXT NOT NULL,
  do_not_touch TEXT NOT NULL,
  acceptance TEXT NOT NULL,
  validation TEXT NOT NULL,
  policy_version TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  authorized_at INTEGER,
  expires_at INTEGER
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  manus_task_id TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  last_cursor TEXT,
  last_manus_updated_at INTEGER,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  event_type TEXT NOT NULL,
  external_event_id TEXT,
  payload_sha256 TEXT NOT NULL,
  raw_payload TEXT NOT NULL,
  signature_timestamp INTEGER,
  received_at INTEGER NOT NULL,
  processed_at INTEGER,
  processing_status TEXT NOT NULL,
  error_code TEXT,
  UNIQUE(source, external_event_id),
  UNIQUE(source, payload_sha256)
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id),
  manus_message_id TEXT,
  direction TEXT NOT NULL,
  message_type TEXT NOT NULL,
  content_redacted TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  cursor TEXT,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS transitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  task_id INTEGER REFERENCES tasks(id),
  from_state TEXT,
  to_state TEXT NOT NULL,
  reason TEXT NOT NULL,
  actor_type TEXT NOT NULL,
  actor_subject TEXT NOT NULL,
  policy_result TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS escalations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  task_id INTEGER REFERENCES tasks(id),
  category TEXT NOT NULL,
  question TEXT NOT NULL,
  required_action TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  resolved_at INTEGER,
  resolved_by TEXT,
  resolution_hash TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  correlation_id TEXT NOT NULL,
  actor_type TEXT NOT NULL,
  actor_subject TEXT NOT NULL,
  action TEXT NOT NULL,
  object_type TEXT NOT NULL,
  object_id TEXT NOT NULL,
  decision_id TEXT,
  before_hash TEXT,
  after_hash TEXT,
  metadata_redacted_json TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  key TEXT PRIMARY KEY,
  operation TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  result_json TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_decision ON tasks(decision_id);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(processing_status);
CREATE INDEX IF NOT EXISTS idx_messages_task ON messages(task_id, id);
CREATE INDEX IF NOT EXISTS idx_transitions_decision ON transitions(decision_id, id);
CREATE INDEX IF NOT EXISTS idx_audit_decision ON audit_log(decision_id, id);
