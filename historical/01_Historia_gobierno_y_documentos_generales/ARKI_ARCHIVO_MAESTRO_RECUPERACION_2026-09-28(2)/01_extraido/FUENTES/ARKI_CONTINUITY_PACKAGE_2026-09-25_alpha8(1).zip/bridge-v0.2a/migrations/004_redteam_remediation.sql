CREATE TABLE IF NOT EXISTS dispatch_claims (
  decision_id TEXT PRIMARY KEY REFERENCES decisions(id),
  claim_id TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  intent_hash TEXT NOT NULL,
  task_id INTEGER REFERENCES tasks(id),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS review_claims (
  review_id TEXT PRIMARY KEY,
  decision_id TEXT NOT NULL REFERENCES decisions(id),
  task_id INTEGER NOT NULL REFERENCES tasks(id),
  input_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  output_hash TEXT,
  action_status TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE(decision_id, input_hash)
);

CREATE INDEX IF NOT EXISTS idx_review_claims_decision ON review_claims(decision_id, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_external_effect_idempotency ON external_effects(decision_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
