# Test Commands

Run from the extracted Bridge root:

```bash
node --version
npm --version
for f in src/*.mjs tests/*.mjs tests/r03-real/*.mjs; do node --check "$f"; done
npm test
npm run test:provider-contract
npm run test:mock-e2e
```

Expected closeout results for this baseline are `111/111`, `22/22`, and `MOCK_E2E_PASS scenarios=14`. These commands are local and do not call OpenAI or Manus.

For a secret scan, search for private-key blocks and compare actual runtime secret values without printing them. Do not use a broad regex result as proof without distinguishing test fixtures from real values.

## References

[1]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Expected baseline results"
