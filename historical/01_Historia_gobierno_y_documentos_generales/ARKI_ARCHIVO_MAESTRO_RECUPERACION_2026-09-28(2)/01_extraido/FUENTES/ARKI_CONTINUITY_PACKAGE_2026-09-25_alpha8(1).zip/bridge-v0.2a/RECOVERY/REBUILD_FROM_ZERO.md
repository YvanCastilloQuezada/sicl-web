# Rebuild From Zero

1. Obtain this ZIP through a trusted channel and verify `MASTER_ZIP_SHA256`.
2. Extract it into a private working directory. Do not extract secrets or `node_modules`.
3. Confirm `package.json`, `src/`, `migrations/`, and `tests/` are present.
4. Use Node `v22.13.0` or a compatible Node 22 release. Do not run a global install for this package.
5. Keep `PROVIDER_MODE=mock` for deterministic reconstruction.
6. Run the commands in `RECOVERY/TEST_COMMANDS.md`.
7. Only after a new human decision may a secure connector provide provider credentials and a real adapter be constructed.
8. Do not connect ARKI, deploy, publish, create webhooks, or create provider tasks during reconstruction.

The package is private infrastructure. Rebuilding it does not publish or activate it.

## References

[1]: TEST_COMMANDS.md "Deterministic test commands"
[2]: VERIFY_PACKAGE.md "Package verification"
