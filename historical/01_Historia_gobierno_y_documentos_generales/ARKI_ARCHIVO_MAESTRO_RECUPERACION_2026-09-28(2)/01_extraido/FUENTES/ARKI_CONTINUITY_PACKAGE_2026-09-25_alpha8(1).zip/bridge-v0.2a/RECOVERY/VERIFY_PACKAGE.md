# Verify Package

After extracting the master ZIP into a clean directory:

```bash
unzip -t ARKI_CONTINUITY_PACKAGE_2026-09-25_alpha8.zip
sha256sum -c SHA256_MANIFEST.txt
find . -type f | grep -E 'node_modules|\.git|\.env$' && exit 1 || true
find . -type f -name '*.sqlite' -o -name '*.db'
```

The last command must return no packaged temporary databases. Inspect `00_START_HERE.md`, `BASELINE/BRIDGE_FINAL_BASELINE.md`, `03_NEXT_ACTION.md`, and `CONTINUITY/COLD_START_TEST.md`. Confirm the source, migration, test, contract, report, recovery, and manifest directories exist.

Do not run external providers during package verification.

## References

[1]: ../SHA256_MANIFEST.txt "Package manifest"
[2]: ../CONTINUITY/COLD_START_TEST.md "Cold-start continuity result"
