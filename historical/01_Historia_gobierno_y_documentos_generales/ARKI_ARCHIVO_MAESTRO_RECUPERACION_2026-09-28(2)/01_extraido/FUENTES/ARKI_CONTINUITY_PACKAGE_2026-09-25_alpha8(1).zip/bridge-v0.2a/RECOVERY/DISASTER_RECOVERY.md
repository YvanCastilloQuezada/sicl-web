# Disaster Recovery

If a provider call may have succeeded while local persistence failed, stop automation and mark the external effect `UNKNOWN`. Do not create a replacement task or send a follow-up blindly. Recover the exact durable provider identity through an official, authorized read-only mechanism. If identity cannot be recovered, escalate to Human Authority.

If the SQLite file is lost, preserve any sanitized logs and reports, but do not reconstruct a provider task ID by guessing. A new task requires a new explicit owner authorization because it can create cost and an external effect.

If a decision is revoked or the kill switch is hard halted, late provider events may be retained as evidence but cannot reactivate autonomy.

## References

[1]: ../src/external-effects.mjs "External effect recovery"
[2]: ../src/autonomy-control.mjs "Revocation and kill switch"
[3]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 recovery incident and resolution"
