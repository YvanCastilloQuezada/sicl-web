import {existsSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {BridgeStore} from '../../src/store.mjs';
import {Orchestrator} from '../../src/orchestrator.mjs';
import {ManusRealAdapter} from '../../src/manus-real-adapter.mjs';

const mode=process.argv[2];
const state=process.env.R03_STATE_PATH;
if(!state||!['create','reconcile'].includes(mode)) throw new Error('Usage: R03_STATE_PATH=/path node tests/r03-real/run.mjs create|reconcile');
const counts={create:0,detail:0,list:0,other:0};
const baseFetch=globalThis.fetch;
const fetchImpl=async(url,options)=>{const p=new URL(url).pathname;if(p.endsWith('/task.create'))counts.create++;else if(p.endsWith('/task.detail'))counts.detail++;else if(p.endsWith('/task.listMessages'))counts.list++;else counts.other++;return baseFetch(url,options)};
const store=new BridgeStore(state);
const manus=new ManusRealAdapter({apiKey:process.env.MANUS_API_KEY,mode:'real',maxRetries:0,timeoutMs:15000,fetchImpl});
const orchestrator=new Orchestrator({store,manus});
const safeError=e=>({code:e?.code||'ERROR',http_status:e?.http_status??null,provider_error_code:e?.provider_error_code??null,provider_request_id:e?.provider_request_id??null,provider_error_message:e?.provider_error_message||'REDACTED'});
try{
 if(mode==='create'){
  const d=orchestrator.createDecision({decision_id:`D-R03-PERSIST-${Date.now()}`,project:'bridge-r3-synthetic',context:'Synthetic provider validation only.',why:'Verify persistent identity across process restart.',objective:'Return exactly: ARKI_BRIDGE_MANUS_R3_OK',execution:'Return exactly: ARKI_BRIDGE_MANUS_R3_OK',preserve:'Only the exact synthetic result.',do_not_touch:'No connectors, files, project references, skills selection, follow-up, confirmation, or external action.',acceptance:'Exact result ARKI_BRIDGE_MANUS_R3_OK.',validation:'Return the exact synthetic result and no other action.'});
  const created=await orchestrator.dispatch(d.id,{r3:true,share_visibility:'private',connectors:[],files:[],enable_skills:[],force_skills:[]});
  const taskId=created.task.manus_task_id,effect=store.getExternalEffectByProviderTaskId(d.id,taskId);
  if(effect?.provider_task_id!==taskId)throw new Error('DURABLE_IDENTITY_NOT_PERSISTED');
  console.log(JSON.stringify({phase:'create',counts,taskIdPresent:true,identityPersisted:true,createVisibility:created.response?.share_visibility??'UNKNOWN',shareUrlPresent:Object.prototype.hasOwnProperty.call(created.response||{},'share_url'),stateExists:existsSync(state)}));
 } else {
  const task=store.db.prepare('SELECT * FROM tasks ORDER BY id DESC LIMIT 1').get();
  if(!task)throw new Error('NO_PERSISTED_TASK');
  const effect=store.getExternalEffectByProviderTaskId(task.decision_id,task.manus_task_id);
  if(!effect||effect.provider_task_id!==task.manus_task_id)throw new Error('DURABLE_IDENTITY_RECOVERY_FAILED');
  const reconciled=await orchestrator.reconcile(task.manus_task_id,{r3:true});
  const detail=reconciled.detail||{},assistantText=(reconciled.messages||[]).map(m=>m?.assistant_message?.content||'').join('\n'),exact=assistantText.includes('ARKI_BRIDGE_MANUS_R3_OK');
  console.log(JSON.stringify({phase:'reconcile',counts,identityRecovered:true,taskVisibility:detail?.task?.share_visibility??'UNKNOWN',status:detail?.task?.status??'UNKNOWN',shareUrlPresent:Object.prototype.hasOwnProperty.call(detail?.task||{},'share_url'),expectedResultReceived:exact,expectedResultExact:exact,skillsObserved:'UNKNOWN',externalActionsObserved:reconciled.observation?.external_action_observed?'YES':'NO',creditUsage:detail?.task?.credit_usage??'UNKNOWN',reconcileStatus:reconciled.status||'OK',reasonCode:reconciled.reasonCode||'NONE'}));
 }
} catch(e){console.log(JSON.stringify({phase:mode,counts,error:safeError(e)}));process.exitCode=2}
finally{store.close();}
