import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {BridgeStore} from '../src/store.mjs';

const decision={decision_id:'D-STORE-1',project:'bridge',context:'ctx',why:'why',objective:'obj',execution:'exec',acceptance:'ok'};
test('SQLite migrations, repositories, transitions and restart recovery',()=>{
 const dir=mkdtempSync(join(tmpdir(),'bridge-')); const file=join(dir,'state.sqlite');
 let store=new BridgeStore(file); const d=store.createDecision(decision,'c1'); assert.equal(d.state,'CREATED');
 store.transition(d.id,'AUTHORIZED',{reason:'owner',actorType:'human',actorSubject:'yvan',correlationId:'c1'});
 const task=store.createTask({decisionId:d.id,manusTaskId:'m-1'},'c2');
 store.transition(d.id,'DISPATCHED',{taskId:task.id,reason:'dispatch',correlationId:'c2'});
 store.addMessage({taskId:task.id,direction:'inbound',messageType:'assistant_message',content:'{"token":"SECRET"}'});
 const claim=store.claimIdempotency('key-1','op',{x:1}); assert.equal(claim.claimed,true); store.finishIdempotency('key-1',{value:'ok'});
 assert.equal(store.getAudit(d.id).length>=3,true); assert.equal(store.counts().idempotency_keys,1); store.close();
 store=new BridgeStore(file); assert.equal(store.getDecision(d.id).state,'DISPATCHED'); assert.equal(store.getTaskByManusId('m-1').decision_id,d.id); assert.equal(store.db.prepare('SELECT content_redacted FROM messages').get().content_redacted.includes('[REDACTED]'),true); const replay=store.claimIdempotency('key-1','op',{x:1}); assert.equal(replay.claimed,false); assert.deepEqual(replay.result,{value:'ok'}); assert.throws(()=>store.claimIdempotency('key-1','op',{x:2}),/IDEMPOTENCY_CONFLICT/); store.close(); rmSync(dir,{recursive:true,force:true});
});
test('transaction rolls back on failure',()=>{
 const dir=mkdtempSync(join(tmpdir(),'bridge-')); const store=new BridgeStore(join(dir,'state.sqlite')); assert.throws(()=>store.transaction(()=>{store.createDecision({...decision,decision_id:'D-TX'},'tx');throw new Error('boom');}),/boom/); assert.equal(store.getDecision('D-TX'),undefined); store.close(); rmSync(dir,{recursive:true,force:true});
});
