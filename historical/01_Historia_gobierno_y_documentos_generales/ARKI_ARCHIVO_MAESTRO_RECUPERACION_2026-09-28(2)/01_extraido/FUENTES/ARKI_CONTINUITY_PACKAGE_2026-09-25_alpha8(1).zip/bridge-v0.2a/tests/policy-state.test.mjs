import test from 'node:test';
import assert from 'node:assert/strict';
import {STATES, canTransition, assertTransition} from '../src/state-machine.mjs';
import {POLICY, classifyAction} from '../src/policy.mjs';

test('state machine accepts authorized dispatch path and rejects illegal transitions',()=>{
  assert.equal(canTransition(STATES.CREATED,STATES.AUTHORIZED),true);
  assert.equal(canTransition(STATES.COMPLETED,STATES.RUNNING),false);
  assert.doesNotThrow(()=>assertTransition(STATES.REVIEW_REQUIRED,STATES.HUMAN_DECISION_REQUIRED));
  assert.throws(()=>assertTransition(STATES.COMPLETED,STATES.RUNNING),/Illegal transition/);
});
test('policy classifies material categories and safe actions',()=>{
  assert.equal(classifyAction({}).classification,POLICY.AUTO_ALLOWED);
  assert.equal(classifyAction({review_required:true}).classification,POLICY.REVIEW_ALLOWED);
  assert.equal(classifyAction({category:'CREDENTIAL_REQUIRED'}).classification,POLICY.HUMAN_REQUIRED);
  assert.equal(classifyAction({scope_delta:true}).classification,POLICY.HUMAN_REQUIRED);
  assert.equal(classifyAction({prohibited:true}).classification,POLICY.PROHIBITED);
});
