import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {BridgeStore} from '../src/store.mjs';
import {Orchestrator} from '../src/orchestrator.mjs';
import {validateDecision, validateMessage, LIMITS} from '../src/schemas.mjs';

const base={decision_id:'D-REQ-1',project:'bridge',context:'ctx',why:'why',objective:'obj',execution:'exec',acceptance:'ok'};
test('schemas reject missing fields and oversized messages',()=>{ assert.throws(()=>validateDecision({}),e=>e.code==='VALIDATION_ERROR'); assert.throws(()=>validateMessage({content:'x'.repeat(LIMITS.message+1)}),e=>e.code==='PAYLOAD_TOO_LARGE'); });
async function stateFor(detail) { const dir=mkdtempSync(join(tmpdir(),'bridge-')); const store=new BridgeStore(join(dir,'state.sqlite')); const manus={createTask:async()=>({task:{id:'m-state'}}),detail:async()=>({task:{id:'m-state',...detail}}),listMessages:async()=>({messages:[],has_more:false})}; const o=new Orchestrator({store,manus}); const d=o.createDecision({...base,decision_id:`D-${detail.status}-${String(detail.has_running_background_jobs)}`}); await o.dispatch(d.id); const out=await o.reconcile('m-state'); const state=out.decision.state; store.close(); rmSync(dir,{recursive:true,force:true}); return state; }
test('Manus waiting, stopped/background true and unknown are not treated as complete',async()=>{ assert.equal(await stateFor({status:'waiting'}),'WAITING_EXTERNAL'); assert.equal(await stateFor({status:'stopped',has_running_background_jobs:true}),'WAITING_EXTERNAL'); assert.equal(await stateFor({status:'stopped'}),'WAITING_EXTERNAL'); });
test('Manus stopped/background false reaches result received after lifecycle reconciliation',async()=>{ assert.equal(await stateFor({status:'stopped',has_running_background_jobs:false}),'RESULT_RECEIVED'); });
