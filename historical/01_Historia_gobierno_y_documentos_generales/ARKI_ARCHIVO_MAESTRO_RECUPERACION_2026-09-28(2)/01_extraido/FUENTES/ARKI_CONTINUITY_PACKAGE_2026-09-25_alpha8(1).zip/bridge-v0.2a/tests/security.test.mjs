import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {requireBridgeAuth, verifyManusWebhook, canonicalWebhookUrl} from '../src/security.mjs';
const {privateKey,publicKey}=crypto.generateKeyPairSync('rsa',{modulusLength:2048});
const body=Buffer.from(JSON.stringify({event_type:'task.stopped',event_id:'e1'})); const url='https://bridge.example.test/webhooks/manus'; const timestamp=Math.floor(Date.now()/1000); const digest=crypto.createHash('sha256').update(body).digest('hex'); const signature=crypto.sign('RSA-SHA256',Buffer.from(`${timestamp}.${url}.${digest}`),privateKey).toString('base64');

test('valid webhook signature and canonical URL pass',()=>{ assert.equal(verifyManusWebhook({rawBody:body,url,timestamp,signature,publicKeyPem:publicKey.export({type:'spki',format:'pem'})}).payloadSha,digest); assert.equal(canonicalWebhookUrl(url),url); });
test('missing key, invalid signature, expired timestamp and URL mismatch reject',()=>{
 assert.throws(()=>verifyManusWebhook({rawBody:body,url,timestamp,signature,publicKeyPem:''}),e=>e.code==='WEBHOOK_KEY_NOT_CONFIGURED');
 assert.throws(()=>verifyManusWebhook({rawBody:body,url,timestamp,signature:'bad',publicKeyPem:publicKey.export({type:'spki',format:'pem'})}),e=>e.code==='INVALID_WEBHOOK_SIGNATURE');
 assert.throws(()=>verifyManusWebhook({rawBody:body,url,timestamp:timestamp-301,signature,publicKeyPem:publicKey.export({type:'spki',format:'pem'})}),e=>e.code==='EXPIRED_WEBHOOK');
 assert.throws(()=>verifyManusWebhook({rawBody:body,url:'http://bridge',timestamp,signature,publicKeyPem:publicKey.export({type:'spki',format:'pem'})}),e=>e.code==='INVALID_WEBHOOK_URL');
});
test('bridge authentication fails closed and uses constant-time comparison path',()=>{ assert.throws(()=>requireBridgeAuth({'x-bridge-auth':'x'},''),e=>e.code==='BRIDGE_AUTH_NOT_CONFIGURED'); assert.throws(()=>requireBridgeAuth({'x-bridge-auth':'bad'},'secret'),e=>e.code==='UNAUTHORIZED'); assert.doesNotThrow(()=>requireBridgeAuth({'x-bridge-auth':'secret'},'secret')); });
