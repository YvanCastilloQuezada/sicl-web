import test from 'node:test';
import assert from 'node:assert/strict';
import {readdirSync, readFileSync} from 'node:fs';
import {join} from 'node:path';
const root=join(process.cwd(),'src');
test('Bridge source has no ARKI repository mutation or external product path',()=>{
  const files=readdirSync(root).filter(f=>f.endsWith('.mjs'));
  for(const file of files){
    const source=readFileSync(join(root,file),'utf8');
    assert.equal(/(?:writeFile|rename|rm|unlink|mkdir).*arki/i.test(source),false,`${file} contains ARKI mutation path`);
    assert.equal(/\.\.\/arki|\/arki\//i.test(source),false,`${file} references an ARKI product path`);
  }
});
