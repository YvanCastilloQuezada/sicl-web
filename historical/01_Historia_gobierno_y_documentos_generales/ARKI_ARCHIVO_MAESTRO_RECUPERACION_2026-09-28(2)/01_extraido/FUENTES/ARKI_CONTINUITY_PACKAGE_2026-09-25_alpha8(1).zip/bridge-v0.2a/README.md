# ARKI Agent Bridge v0.2A

Implementación determinista y privada de las fases 0–4 autorizadas por `AB-V02A-IMPLEMENT-001`.

## Incluye

- SQLite durable con migración versionada.
- Repositorios de decisiones, tareas, eventos, mensajes, transiciones, escalaciones e idempotencia.
- Audit log append-only a nivel de aplicación.
- Máquina de estados explícita.
- Decision Policy Engine.
- Gateway autenticado mediante secreto interno.
- Schemas, límites de cuerpo y errores públicos estructurados.
- Receptor Manus fail-closed con RSA-SHA256, timestamp, URL canónica y deduplicación persistente.
- Manus Adapter con timeout, retries bounded, exponential backoff, paginación y reconciliación de estados.
- Persistent Orchestrator con correlación y recuperación desde SQLite.
- Fake OpenAI Adapter únicamente para contratos y pruebas.
- OpenAI Agents API Adapter interface para `ARKI Architect`, con sesiones, eventos normalizados y schema estricto.
- Policy enforcement posterior a la salida OpenAI, correcciones acotadas a Manus y escalamiento `HUMAN_DECISION_REQUIRED`.
- Autonomy Control Layer con envelope determinista, kill switch local/out-of-band, budget configurable, loop governor y revocación durable.
- Evidence Taxonomy V1, separación `policy_category`/`reason` y coordinación de side effects con estado `EXTERNAL_EFFECT_UNKNOWN`.
- Red Team remediation v0.2C.1: claims durables de dispatch/review, recheck post-await, verifier registry estructural, idempotencia de mensajes y usage budget.
- Gate 2 closeout v0.2C.2: recovery fail-closed de `IN_FLIGHT` y claims, retries reales del ManusAdapter, separación call-count/usage, budget de control interno, revocación por decisión frente a kill global y revocation mid-fetch.
- Pre-Mock hardening v0.2C.3: retry ownership por invocación, recovery atómico de review claims, budget preflight sin overshoot, persistencia local observada tras éxito externo y APIs explícitas `setDecision()`/`setGlobal()`.
- Mock E2E v0.2D: harness determinista sobre Gateway/Orchestrator con 14 escenarios, fake Manus, fake OpenAI Architect, restart/recovery, revocación, kill global, budgets, idempotencia, evidence laundering, scope containment y audit reconstruction.
- V02F local provider boundary: OpenAI Responses adapter y Manus v2 adapter reales implementados pero desactivados por defecto; `PROVIDER_MODE` ausente o desconocido permanece en `mock`.
- V02F contract tests: 20 escenarios con fake HTTP para Responses, Manus v2, public-key cache, RSA-SHA256, replay, redaction, refusal, schema errors, rate limits y timeouts.

## No incluido por decisión

- No se ejecutan llamadas reales a Manus.
- No se ejecutan llamadas reales a OpenAI.
- No se solicitan ni se incluyen credenciales.
- No se registra un webhook real.
- No se publica ni despliega el proceso.
- No se modifica ningún archivo de ARKI.
- No se activa el runtime OpenAI real ni el adapter Manus real.
- No se ejecuta la validación E2E real de la fase 6.
- No se usa Agents SDK como runtime principal.

## Pruebas

```bash
npm test
```

La suite usa únicamente SQLite temporal, fakes y claves RSA efímeras generadas durante las pruebas.

## Ejecución local privada

La configuración mínima para arrancar el Gateway requiere `BRIDGE_INTERNAL_SECRET`. Las rutas privadas se deben mantener en loopback o red privada. El webhook exige además `MANUS_WEBHOOK_PUBLIC_URL` HTTPS y `MANUS_WEBHOOK_PUBLIC_KEY_PEM`; si faltan, el servidor rechaza la solicitud.

La API key de Manus solo sería necesaria para una fase posterior de integración real. Esta versión no la utiliza durante las pruebas.

## Estructura

```text
src/store.mjs             SQLite, migraciones, repositorios y audit log
src/state-machine.mjs     estados y transiciones
src/policy.mjs            política de Human Authority
src/security.mjs          auth interna y webhooks
src/manus.mjs             adapter Manus aislado
src/orchestrator.mjs      orquestador persistente
src/fake-openai.mjs       fake adapter y schema de contrato
src/openai-adapter.mjs    contrato Agents API, ARKI Architect y eventos
src/openai-real-adapter.mjs Responses API real, estricta y desactivada
src/manus-real-adapter.mjs Manus API v2 real, desactivada
src/manus-webhook-key-cache.mjs cache TTL de public key con transporte inyectable
src/manus-webhook-schema.mjs validación explícita del envelope webhook v2
src/provider-config.mjs    modo mock por defecto y redacción de secretos
migrations/001_initial.sql
migrations/002_openai_sessions.sql
migrations/003_autonomy_control.sql persistencia de controles, evidencia y side effects
migrations/004_redteam_remediation.sql claims durables e idempotencia de review
tests/                    suite unitaria, integración y seguridad
tests/provider-contract.test.mjs contract tests HTTP falsos V02F
```
