# ARKI Agent Bridge v0.2C — Autonomy Control & Evidence Governance

**Orden:** `AB-V02C-AUTONOMY-CONTROL-001`  
**Estado:** implementada y probada con fakes; detenida antes de E2E real, credenciales y APIs reales.

## VERSION

`0.2.0-alpha.3`.

## BASELINE

Baseline recibido: `0.2.0-alpha.2` / v0.2B source evidence. Los 23 tests existentes se conservaron. No se eliminaron ni debilitaron.

## FILES CREATED

Se añadieron:

- `src/autonomy-control.mjs`
- `src/loop-budget.mjs`
- `src/evidence.mjs`
- `src/external-effects.mjs`
- `src/policy-contract.mjs`
- `migrations/003_autonomy_control.sql`
- `tests/autonomy-control.test.mjs`
- `V02C_IMPLEMENTATION_REPORT.md`

## FILES MODIFIED

Se modificaron `src/store.mjs`, `src/orchestrator.mjs`, `src/openai-adapter.mjs`, `package.json` y `README.md`. No se modificó ARKI, ningún webhook público, ningún deployment, ni se realizaron llamadas externas.

## MIGRATIONS

`003_autonomy_control.sql` añade columnas de revocación a `decisions` y tablas para `autonomy_controls`, `autonomy_counters`, `evidence` y `external_effects`. La migración se descubre automáticamente junto con las migraciones anteriores y queda registrada en `schema_migrations`.

## AUTONOMY CONTROL LAYER

La capa está implementada mediante `evaluateEnvelope`, `KillSwitch`, `BudgetEnforcer`, `LoopGovernor`, la persistencia durable del store y la integración del Orchestrator.

La capa solo produce `ALLOW`, `PAUSE`, `HALT` o `HUMAN_REQUIRED`. La precedencia determinista es:

```text
HALT > HUMAN_REQUIRED > PAUSE > ALLOW
```

Ningún resultado de agente puede degradar un estado más restrictivo.

## AUTONOMY ENVELOPE

El envelope evalúa `authorized_scope`, kill state, budget state, loop state, revocation state, security state y evidence state. El estado revocado se trata como `HALT`. La evidencia contradicha y los bloqueos de seguridad producen `HUMAN_REQUIRED`.

Los defaults conservadores del governor están marcados como `PROPOSED` en código. No se presentan como una decisión permanente de producción ni contienen precios inventados.

## KILL SWITCH

Implementados:

- `SOFT_PAUSED`: impide nuevas operaciones automáticas.
- `HARD_HALTED`: impide nuevas operaciones externas.
- Out-of-band local: archivo atómico configurable por `BRIDGE_KILL_SWITCH_PATH`.

El archivo se escribe mediante temporal y `rename`, evitando una escritura parcial deliberada. Cada cambio queda en audit log. Las pruebas cubren soft pause, hard halt, out-of-band stop, persistencia, reinicio y kill durante correction loop.

## BUDGET ENFORCER

Implementados contadores durables por decisión para ciclos, correcciones, llamadas externas, retries, tokens y costo reportado. Los valores de costo solo se acumulan si un provider los entrega; no se inventan precios.

El chequeo ocurre antes de dispatch Manus, corrección Manus, creación de sesión OpenAI y revisión OpenAI. Al alcanzar un límite hard no se realiza la operación externa siguiente.

Los defaults son configurables. Para tests se usan límites sintéticos.

## LOOP GOVERNOR

Implementados `max_cycles`, `max_corrections`, `max_external_calls`, `max_retries`, `max_elapsed_time`, `max_consecutive_failures`, detección por hash de acciones repetidas, estancamiento de resultados y circuit breaker.

El governor conserva hashes canónicos de acción y resultado. Repetición, estancamiento y ausencia de progreso producen `PAUSE`; fallos consecutivos sobre el límite producen `HALT`.

## DECISION REVOCATION

Implementada revocación explícita y durable con actor, timestamp y razón. Una decisión revocada no puede dispatchar, corregir, reactivarse mediante OpenAI ni reactivarse mediante Manus. La revocación activa hard halt y queda auditada.

Si existe una operación externa activa, la implementación no afirma que fue cancelada. Los eventos tardíos se registran, pero no reactivan autonomía.

## EVIDENCE TAXONOMY V1

Implementados los tipos `SOURCE_ARTIFACT`, `EXECUTION_ARTIFACT`, `SYSTEM_ARTIFACT`, `EXTERNAL_ARTIFACT` y `HUMAN_AUTHORITY_ARTIFACT`.

Implementados los estados `CLAIMED`, `CAPTURED`, `INTEGRITY_VERIFIED`, `PROVENANCE_VERIFIED`, `INDEPENDENTLY_VERIFIED`, `CONTRADICTED` y `UNKNOWN`.

La captura calcula hash local cuando existe artefacto, pero el hash no eleva la verificación. Un proveedor o agente no puede declararse `INDEPENDENTLY_VERIFIED`; esa prueba es rechazada. Las respuestas Manus se almacenan como `EXTERNAL_ARTIFACT` con verificación `UNKNOWN`.

## POLICY CONTRACT CHANGES

`OPENAI_ADAPTER_CONTRACT_V1` se conserva. Se añadió una extensión compatible `OPENAI_ADAPTER_CONTRACT_V2_COMPAT` mediante `policy_category` enum-validado, separado de `reason`.

`reason` permanece texto explicativo. No puede transformarse implícitamente en categoría de policy. Las categorías V2 incluyen `SCOPE`, `SECURITY`, `COST`, `CREDENTIAL`, `ARCHITECTURE`, `PROFESSIONAL`, `EXECUTION`, `EVIDENCE` y `NONE`.

## EXTERNAL SIDE-EFFECT SEMANTICS

Implementado `ExternalEffectCoordinator` con la secuencia persistente de intent, estado in-flight, resultado exitoso, fallo o `EXTERNAL_EFFECT_UNKNOWN`.

La semántica es explícitamente **at-least-once + idempotency + reconciliation**. No se afirma exactly-once. Un estado desconocido bloquea redispatch ciego hasta reconciliación. Un intent idéntico no crea un segundo efecto persistido.

No se implementó un mecanismo de attestation Manus inventado. No se implementó certificate pinning, HMAC, response signature ni hash atribuido a Manus sin evidencia oficial.

## TESTS BEFORE

Los 23 tests baseline estaban pasando antes de añadir la batería v0.2C. No se modificaron los archivos de tests baseline para ocultar fallos.

## TESTS AFTER

```text
ℹ tests 38
ℹ pass 38
ℹ fail 0
```

Los 38 tests incluyen los 23 baseline y 15 tests nuevos de autonomía y evidencia.

## FAILURE-INJECTION TESTS

Pasaron escenarios de rollback transaccional, SQLite locked, intent persistido con resultado ambiguo, resultado externo duplicado, webhook tardío sobre decisión revocada, kill durante correction loop y recuperación tras reinicio.

## SECURITY TESTS

Pasaron precedence restrictiva, prompt/scope injection como datos no autoritativos, revocación, policy category separada de reason, self-verification prohibida, contradicción de evidencia, límites de payload, idempotencia, webhook fail-closed y redacción existente de secretos.

## RESTART RECOVERY

PASS. Kill state, counters, usage sintético, evidencia, intents externos, sesiones OpenAI, eventos y audit log sobreviven al cierre y reapertura de SQLite.

## AUDIT

Cada control registra decisión, correlación, actor, acción, objeto, hashes cuando corresponde, estado efectivo y código de razón. Los cambios de kill switch, evaluación de autonomy, revocación y policy output quedan auditados.

No se almacenan secretos.

## ARKI NO-TOUCH

PASS. El Bridge continúa aislado en `bridge-v0.2a/`. No se modificó ningún archivo, repositorio, base de datos, motor, frontend, backend, deployment o Project State de ARKI.

## REAL OPENAI CALLS

`0`.

## REAL MANUS CALLS

`0`.

## CREDENTIALS USED

Ninguna. No se solicitaron, introdujeron ni registraron credenciales.

## BLOCKERS

No existen bloqueadores para el alcance mock autorizado de v0.2C. `node:sqlite` mantiene la advertencia experimental del runtime utilizado.

## UNRESOLVED

El mecanismo definitivo de Manus attestation permanece pendiente de evidencia oficial. Los valores concretos de límites de producción siguen siendo configurables y `PROPOSED`; no se han convertido en decisiones humanas permanentes.

La implementación no demuestra cancelación de operaciones externas en curso porque no se realizaron llamadas reales. La reconciliación real contra proveedores queda pendiente de una fase posterior autorizada.

## READY FOR MOCK E2E: YES

Evidencia: 38/38 tests pasan, con transportes fake, SQLite temporal, control de autonomía, policy, revocación, evidencia y side effects ambiguos cubiertos.

## READY FOR REAL CREDENTIALS: NO

Evidencia: la orden prohíbe credenciales y llamadas reales. El mecanismo de attestation Manus aún está pendiente y los límites de producción siguen en estado `PROPOSED`.

## READY FOR REAL E2E: NO

Evidencia: la orden prohíbe conectar OpenAI o Manus, registrar webhook público, introducir credenciales y realizar E2E real.

La ejecución se detiene aquí conforme a la orden AB-V02C-AUTONOMY-CONTROL-001.
