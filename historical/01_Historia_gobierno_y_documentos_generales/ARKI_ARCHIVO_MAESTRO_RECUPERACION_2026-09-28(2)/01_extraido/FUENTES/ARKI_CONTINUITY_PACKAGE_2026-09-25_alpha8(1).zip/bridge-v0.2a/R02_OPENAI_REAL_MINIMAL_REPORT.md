# R02 OpenAI Real Minimal Validation Report

**Orden:** `AB-R02-OPENAI-REAL-MINIMAL-001`  
**Baseline:** v0.2F / `0.2.0-alpha.8`  
**Fecha:** 2026-09-25  
**Final state:** `HALT / HUMAN_REQUIRED`

## R2_PRE_FLIGHT

The pre-flight passed before the real operation:

```text
OPENAI_API_KEY_PRESENT      YES
OPENAI_PROJECT_ID_PRESENT   YES
PROVIDER_MODE               mock
npm test                    PASS — 95/95
provider-contract           PASS — 20/20
mock-e2e                    PASS — 14/14
node --check                PASS
```

The real operation was invoked through `OpenAIRealAdapter` with synthetic-only input, no ARKI content, no Manus content, no tools and `maxRetries=0`. The selected model was `gpt-4.1-mini`. The input represented a fictional worker returning integer 4 and contained no project material.

## REAL_CALL_COUNT

```text
OPENAI_REAL_RESPONSES_CALLS = 1
```

Exactly one `POST /v1/responses` operation was attempted. No retry was performed.

## ENDPOINT

```text
POST /v1/responses
```

## RESULT

The provider returned HTTP `401` and the adapter raised its sanitized `OPENAI_AUTH_ERROR` before Structured Output parsing or Contract V1 validation. The provider supplied a request identifier internally, but it is not reproduced in this report.

No response body, Authorization header, API key, project ID, secret metadata or provider error body was persisted.

## CONTRACT_V1_RUNTIME_VALIDATION

```text
FAIL — not reached because provider authentication was rejected
```

## STRUCTURED_OUTPUT_VALIDATION

```text
NOT_EXECUTED — no valid Structured Output response was received
```

## PROVIDER_RESPONSE_CLASS

```text
AUTHENTICATION_REJECTED
```

## USAGE / COST

```text
INPUT_TOKENS       UNKNOWN
OUTPUT_TOKENS      UNKNOWN
TOTAL_TOKENS       UNKNOWN
EXACT_COST         UNKNOWN
```

No usage or cost evidence was available from the rejected response. No value was invented.

## SECRET_LEAK_SCAN

```text
NOT_COMPLETED — HALT occurred immediately on credential rejection
```

The temporary runner was removed. No credential-bearing response body or header was written by the runner.

## EXTERNAL_EFFECTS

```text
MANUS_REAL_CALLS_THIS_PHASE = 0
MANUS_TASKS_CREATED         = 0
WEBHOOKS_REGISTERED         = 0
ARKI_CONNECTIONS            = 0
ARKI_MODIFICATIONS          = 0
TOOLS_EXECUTED_BY_OPENAI   = 0
EXTERNAL_MUTATIONS          = 0
```

## REGRESSION

```text
NOT_EXECUTED AFTER R2 — HALT required by credential rejection
```

The pre-flight regression was healthy. No post-R2 regression was run because the order requires immediate halt on credential rejection and prohibits an automatic correction or retry.

## FINAL CLASSIFICATION

```text
OPENAI_REAL_RESPONSES_CALLS           1
OPENAI_REAL_ADAPTER_RUNTIME_VERIFIED  NO
OPENAI_CONTRACT_V1_RUNTIME_VERIFIED   NO
STRUCTURED_OUTPUT_REAL_VERIFIED       NO
OPENAI_PROJECT_BOUNDARY               VERIFIED at R1; not re-evaluated after 401

SECRET_LEAK_SCAN                      NOT_COMPLETED — HALT
EXTERNAL_MUTATIONS                     0
ARKI_MODIFICATIONS                    0
MANUS_REAL_CALLS_THIS_PHASE           0

REGRESSION                            PRE_FLIGHT_PASS / POST_R2_NOT_EXECUTED
PROVIDER_MODE_RETURNED_TO_MOCK        YES — no global mode change was made

READY_FOR_R3_MANUS                    NO
READY_FOR_NEXT_REAL_PROVIDER_STAGE    NO
```

## BLOCKER

`OPENAI_AUTH_ERROR` / HTTP 401 occurred through the real adapter. This is a credential or provider-boundary failure and must not be corrected automatically. Although R1 read-only connectivity previously succeeded, the R2 adapter request was rejected. The discrepancy requires human review of the configured OpenAI credential/project boundary or adapter/provider header compatibility before any further real call is authorized.

## STOP

R2 halted after the single rejected operation. No retry, Responses generation retry, Manus call, task, webhook, ARKI connection or deployment was performed.
