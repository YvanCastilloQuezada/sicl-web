# R02 Authentication Diagnostic Report

**Orden:** `AB-R02-AUTH-DIAGNOSTIC-001`  
**Fase:** R2 Authentication Diagnostic — No External Calls  
**Fecha:** 2026-09-25  
**External calls during diagnostic:** 0

## R1_AUTH_PATH

The successful R1 request was constructed by a local `curl` command:

```text
method                         GET
path                           /v1/models
authorization header           PRESENT — Bearer scheme
OpenAI project header          ABSENT
content type                   not set by the diagnostic request
credential source              OPENAI_API_KEY environment variable
project source                not used in request
```

The R1 request returned HTTP 200. Because it did not send the project header, that result did not independently prove acceptance of a project-scoped request.

## R2_AUTH_PATH

The failed R2 request was constructed by `OpenAIRealAdapter` and inspected locally with a fake transport:

```text
method                         POST
path                           /v1/responses
authorization header           PRESENT — Bearer scheme
OpenAI project header          PRESENT
content type                   application/json
client request ID header       PRESENT
credential source              OPENAI_API_KEY environment variable
project source                OPENAI_PROJECT_ID environment variable
credential injected adapter   YES
project injected adapter      YES
provider mode                 explicit adapter mode real; global mode remained mock
```

The adapter source constructs the endpoint as `${base}/responses` where the default base is `https://api.openai.com/v1`. The Authorization value is not printed or persisted. The Project ID value is not printed or persisted.

## DIFFERENCES_FOUND

| Property | R1 | R2 adapter | Interpretation |
|---|---|---|---|
| HTTP method | GET | POST | Expected operation difference |
| Path | `/v1/models` | `/v1/responses` | Expected R1/R2 difference |
| Authorization header | Present | Present | No local absence found |
| Auth scheme | Bearer | Bearer | No local scheme difference found |
| Project header | Absent | Present | Material boundary difference |
| Project source | Not used | `OPENAI_PROJECT_ID` | R2-only configuration input |
| Content-Type | Not set | `application/json` | Expected for JSON POST |
| Client request ID | Not set | Present | Operational metadata only |
| Retry count | N/A | 0 | No uncontrolled retry |

## ROOT_CAUSE

```text
ROOT_CAUSE=CONFIGURATION_DEFECT
```

More precisely: the first project-scoped Responses request was rejected with HTTP 401, while the earlier unscoped model-list request succeeded. Static inspection found no missing Authorization header, wrong Bearer scheme, missing credential injection or missing Project ID injection in the adapter. The evidence therefore does not support an `ADAPTER_AUTH_HEADER_DEFECT` or `ADAPTER_CREDENTIAL_INJECTION_DEFECT` classification.

The exact provider-side reason cannot be determined without exposing or retaining the authentication error body, which is prohibited. The most conservative interpretation is a project/credential boundary configuration mismatch or provider-side rejection of that boundary. The previous R1 claim `OPENAI_PROJECT_BOUNDARY=VERIFIED` should be treated as incomplete because the successful request did not include the project header.

```text
ADAPTER_AUTH_HEADER_DEFECT         NO EVIDENCE
ADAPTER_PROJECT_HEADER_DEFECT      NO LOCAL EVIDENCE
ADAPTER_CREDENTIAL_INJECTION_DEFECT NO EVIDENCE
R1_R2_CREDENTIAL_SOURCE_MISMATCH   NO — both use OPENAI_API_KEY environment source
CONFIGURATION_DEFECT               PRIMARY CLASSIFICATION
PROVIDER_BEHAVIOR_REQUIRES_FURTHER_EVIDENCE YES
```

## LOCAL_FIX_REQUIRED

```text
LOCAL_FIX_REQUIRED=NO
```

No unequivocal local adapter bug was found. The adapter sends the expected project header and should not be altered merely to conceal or bypass a provider authentication failure.

## CREDENTIAL_ROTATION_REQUIRED

```text
CREDENTIAL_ROTATION_REQUIRED=UNKNOWN
```

Credential rotation is not authorized and is not recommended based only on this diagnostic. The credential was accepted by R1, so the failure may instead concern project association, project permissions or provider boundary semantics.

## PROJECT_CHANGE_REQUIRED

```text
PROJECT_CHANGE_REQUIRED=UNKNOWN
```

No project change was made. A human owner must resolve any project/credential association question in the provider configuration before a retry can be considered.

## MODEL_COMPATIBILITY

```text
MODEL_COMPATIBILITY=NOT_YET_TESTED
```

The 401 occurred before a valid model response. No model change was attempted.

## SECRET_LEAK_SCAN

```text
SECRET_LEAK_SCAN=PASS
```

The diagnostic used only synthetic values in the fake transport. The real API key and Project ID were compared internally for absence from files and logs without printing their values, lengths, hashes or fingerprints. No external response body or authentication header was stored.

## REGRESSION

```text
npm test                         95/95 PASS
npm run test:provider-contract  20/20 PASS
npm run test:mock-e2e            14/14 PASS
node --check                     PASS
PROVIDER_MODE                   mock
```

## SAFE_TO_RETRY_R2

```text
SAFE_TO_RETRY_R2=NO
```

A retry is not safe or authorized until the human owner resolves the project/credential boundary discrepancy. No external calls were made during this diagnostic and no automatic correction was applied.

## STOP

The diagnostic is complete. No OpenAI call, Manus call, credential rotation, retry, R2 operation, R3 operation, ARKI operation, webhook operation or deployment was performed during this phase.
