# Bridge History

The v0.1 audit established that the seed contained a Manus client, protocol ideas, webhook code, and tests, but did not prove bidirectional OpenAI/Manus operation. The v0.2 specification then defined durable state, policy, authority, and provider boundaries.

v0.2A implemented SQLite state, migrations, state transitions, policy, security, Manus integration, a fake OpenAI adapter, and the first deterministic tests. v0.2B added OpenAI sessions, events, structured review, and correction flow. v0.2C added autonomy controls, evidence, budgets, loop governance, revocation, external-effect intents, and kill semantics.

The deep red-team gates identified out-of-band kill precedence, Human Authority categories, coordinator integration, post-review rechecks, late-event handling, loop integration, structural verification, idempotency, usage budgets, HALT semantics, concurrent dispatch, and duplicate reviews. v0.2C.1 and v0.2C.2 addressed those findings with direct and compositional tests. v0.2C.3 hardened retry ownership, claims, preflight, and persistence failure handling.

v0.2D added fourteen deterministic Mock E2E scenarios. V02E documented the gap between local adapters and real providers. V02F added inactive real adapters and fake-HTTP contract tests. R1 verified provider identity boundaries. R2 verified one controlled OpenAI path. R3 verified private Manus creation, durable identity, reconciliation, and restart recovery. R03E repaired provider identity persistence ordering. R4 verified the complete synthetic real Bridge circuit.

## References

[1]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Frozen milestone baseline"
[2]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 evidence"
