# Rejected Approaches

The Bridge rejected treating documentation as proof of capability. It rejected activating real providers before explicit authorization, using provider output as authority, and treating a webhook signature as proof of artifact truth.

It rejected blind retry after unknown external success, reconstructing lost task IDs, and creating replacement tasks without owner authorization. It rejected shared mutable retry counters, automatic ARKI integration, deployment during development, and a frontend-first roadmap.

It also rejected DeepSeek or external audits for this closeout. The cold-start test is local and documentary by design.

## References

[1]: ../SECURITY/PROMPT_INJECTION_BOUNDARY.md "Prompt and authority boundary"
[2]: ../RECOVERY/DISASTER_RECOVERY.md "Recovery rules"
