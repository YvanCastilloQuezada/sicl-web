# Lessons Learned

The most important lesson is that an external provider identity must be persisted before the local effect is marked successful. A temporary SQLite file is not restart evidence if the runner deletes it before the next process can reopen it.

Provider eventual consistency must be treated explicitly. `task.detail` may return a transient 404 immediately after creation, but retries must remain bounded and scoped to reads. Diagnostics must preserve sanitized HTTP status, provider error code, and request identity without exposing secrets.

Structured-output schemas must constrain enums at the provider boundary, not only after the response arrives. Local validation remains necessary, but a permissive provider schema can produce avoidable invalid responses. A null or absent optional policy category can be normalized only when the contract explicitly defines that behavior.

Finally, a successful synthetic Bridge E2E does not establish ARKI integration. Scope labels are part of the evidence.

## References

[1]: ../src/openai-real-adapter.mjs "OpenAI structured schema"
[2]: ../src/manus.mjs "Manus retry and diagnostics"
[3]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 closeout evidence"
