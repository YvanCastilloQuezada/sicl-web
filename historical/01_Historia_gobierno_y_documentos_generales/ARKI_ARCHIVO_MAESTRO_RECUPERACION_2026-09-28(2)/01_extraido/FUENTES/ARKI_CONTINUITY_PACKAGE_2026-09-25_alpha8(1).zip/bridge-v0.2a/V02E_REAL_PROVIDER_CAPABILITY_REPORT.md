# ARKI Agent Bridge v0.2E — Real Provider Capability Discovery Report

**Orden:** `AB-V02E-REAL-PROVIDER-CAPABILITY-DISCOVERY-001`  
**Fecha de consulta:** 2026-09-25  
**Baseline:** v0.2D / `0.2.0-alpha.7`  
**Alcance:** discovery documental, inspección estática y análisis de contratos. No se ejecutaron proveedores reales.

## Conclusión

**Manus v2 está suficientemente documentado para diseñar una implementación real del adapter, pero no para afirmar compatibilidad runtime.** El adapter local ya apunta a `https://api.manus.ai/v2`, usa `x-manus-api-key`, implementa las operaciones centrales y reproduce correctamente la construcción criptográfica de firmas de webhook. Las brechas principales son la captura sistemática de `request_id`, la diferencia entre `status=stopped` y trabajo background desconocido, la ausencia de cache/rotación de clave pública, la falta de garantías documentadas de idempotencia del proveedor y la cobertura incompleta de campos v2.

**OpenAI tiene una API oficial actual y documentada para este caso: Responses API con Structured Outputs.** El contrato V1 del Bridge puede mantenerse congelado como contrato interno. Sin embargo, `OpenAIAgentsAPIAdapter` no es todavía un adapter HTTP real: es una interfaz de transporte con fake transport. El mapeo a Responses API es conceptualmente compatible, pero requiere un adapter-only implementation y validación real posterior.

La orden de implementación debe ser **separada por provider**, empezar por identidad y lecturas controladas, y conservar `ExternalEffectCoordinator` porque no se obtuvo evidencia documental suficiente de idempotencia nativa para `task.create`, `task.sendMessage` o Responses review.

## Clasificación global

| Capacidad | Clasificación | Base | Nota |
|---|---|---|---|
| Manus API v2 base URL y operaciones centrales | DOCUMENTED | Docs oficiales y `src/manus.mjs` | La compatibilidad de runtime sigue REQUIRES_REAL_VALIDATION. |
| Manus task lifecycle y `has_running_background_jobs` | DOCUMENTED | Docs y reconciler | El adapter necesita preservar estados desconocidos. |
| Manus webhook RSA-SHA256 | DOCUMENTED | Docs y `src/security.mjs` | La construcción local coincide. |
| Manus public-key cache/rotation | DOCUMENTED parcial + CODE_EVIDENCE parcial | Endpoint oficial y código local | Cache y rotación no están implementados localmente. |
| Manus idempotencia nativa | UNKNOWN | No localizada en las páginas oficiales consultadas | Mantener coordinator local. |
| OpenAI Responses API | DOCUMENTED | Docs oficiales OpenAI | No hay implementación real en el Bridge. |
| OpenAI Structured Outputs | DOCUMENTED | Docs oficiales OpenAI | Compatible por mapeo, no por runtime. |
| OpenAI response/request IDs | DOCUMENTED | Docs oficiales OpenAI | Falta persistencia completa local. |
| OpenAI review adapter real | UNKNOWN | No hay transporte HTTP local | Requiere adapter-only implementation. |
| OPENAI_ADAPTER_CONTRACT_V1 | CODE_EVIDENCE | `src/openai-adapter.mjs` | Se conserva congelado. |
| REAL_PROVIDER_COMPATIBILITY | REQUIRES_REAL_VALIDATION | Prohibición expresa de esta fase | No se ejecutaron credenciales ni llamadas. |

## Manus v2

La documentación consultada describe `task.create`, `task.detail`, `task.listMessages`, `task.sendMessage`, `webhook.create` y `webhook.publicKey`. El servicio es asíncrono. La fuente recomienda polling mediante `task.listMessages` o webhooks para recibir cambios de estado [1] [2] [3].

El código local coincide con la base URL `https://api.manus.ai/v2`, con los paths v2 principales y con el header `x-manus-api-key`. También implementa timeout, retry bounded, backoff y paginación. Estas coincidencias son **CODE_EVIDENCE**, no validación de una cuenta real.

La documentación actual añade campos que el adapter local no modela completamente: `locale`, `allow_questions`, `hide_in_task_list`, `share_visibility`, `agent_profile`, `task_title` y `structured_output_schema` en creación; además define el comportamiento de connectors en mensajes posteriores [1] [4]. La omisión no invalida el mínimo actual, pero debe convertirse en una decisión explícita del adapter real.

El ciclo de vida requiere tratar `running`, `stopped`, `waiting` y `error` de forma diferente. `stopped` no significa necesariamente que todo trabajo haya terminado: `has_running_background_jobs=true` indica trabajo activo y un valor omitido debe tratarse como desconocido. Las preguntas usan `task.sendMessage` cuando el tipo es `messageAskUser` o `cascadeAskUser`; otras confirmaciones requieren la operación específica `task.confirmAction`, que no existe en el adapter local [2] [3] [4] [5].

La documentación de autenticación permite API key mediante `x-manus-api-key` o OAuth Bearer, con scopes como `create_task` y `manage_all_tasks`. La implementación actual solo soporta API key [6]. Para este Bridge privado, API key server-side es la opción mínima; OAuth es una extensión futura, no un requisito de la primera implementación.

La documentación expone `request_id` en las respuestas. El adapter local devuelve el JSON del provider, pero no persiste ni propaga `request_id` como identificador de correlación de primer nivel. Esto es una brecha de observabilidad y debe corregirse en el adapter real.

No se encontró una garantía oficial de idempotency key para `task.create` o `task.sendMessage` en las páginas consultadas. La clasificación es **UNKNOWN**, no NOT_SUPPORTED. El Bridge debe continuar usando intents locales, estados `IN_FLIGHT` y `EXTERNAL_EFFECT_UNKNOWN`, y reconciliación antes de redispatch.

## Manus D5 — attestation

La documentación oficial define RSA-SHA256 con clave de 2048 bits. El receiver debe leer `X-Webhook-Signature` y `X-Webhook-Timestamp`, rechazar timestamps con más de cinco minutos, construir `{timestamp}.{url}.{sha256_hex(body)}` y verificar la firma con la clave pública [8]. La clave pública se obtiene mediante `webhook.publicKey`; la documentación recomienda cachearla porque cambia rara vez [9].

El código local coincide en algoritmo, material firmado, timestamp de cinco minutos, URL HTTPS completa, hash SHA-256 del body y verificación de firma. Esto es **CODE_EVIDENCE** y el contrato está **DOCUMENTED** por la fuente externa.

La firma válida demuestra autenticidad e integridad del mensaje según ese contrato. No demuestra que el resultado del agente sea verdadero. Por tanto, un webhook verificado debe producir evidencia de tipo externa con procedencia `Manus webhook`, pero no `INDEPENDENTLY_VERIFIED`. El estado propuesto para esa evidencia es:

```text
PROVENANCE_VERIFIED
verification_basis = MANUS_WEBHOOK_RSA_SHA256
artifact_truth = UNKNOWN
```

`INDEPENDENTLY_VERIFIED` solo debe aparecer después de un acto separado del `VerifierRegistry` autorizado. `HASH` tampoco equivale a verdad semántica.

La documentación consultada no especifica ciclo de rotación, identificador de versión de clave ni un mecanismo de cache invalidation. Esos puntos permanecen **UNKNOWN** y requieren configuración operacional conservadora: cache con TTL, refresh controlado ante firma inválida y no aceptación automática de una clave no autenticada.

## Webhook comparison

| Elemento | Manus v2 | Bridge actual | Resultado |
|---|---|---|---|
| Header signature | `X-Webhook-Signature` | Lee header equivalente en lowercase HTTP | MATCH |
| Header timestamp | `X-Webhook-Timestamp` | Lee header equivalente en lowercase HTTP | MATCH |
| Algoritmo | RSA-SHA256, 2048-bit | `crypto.verify('RSA-SHA256', ...)` | MATCH |
| Material firmado | `timestamp.url.sha256_hex(body)` | Igual | MATCH |
| URL | URL HTTPS completa | URL canónica desde env | REQUIRES_REAL_VALIDATION |
| Replay window | 5 minutos | 5 minutos | MATCH |
| Public key | `webhook.publicKey` | Solo PEM en env | REQUIRES_REAL_VALIDATION |
| Key cache | Recomendada | Ausente | MISSING |
| Registration | `webhook.create` | Método adapter existe; no se ejecuta | CODE_EVIDENCE |
| Events | `task_created`, `task_stopped` | Eventos genéricos persistidos | REQUIRES_REAL_VALIDATION |
| Duplicate event | Provider envelope `event_id` | Dedupe durable por event ID/hash | CODE_EVIDENCE |
| Request ID | Provider response field | No first-class persistence | MISSING |
| HTTP response | 2xx, 10-second response expectation | Responde 200 después de processing | REQUIRES_REAL_VALIDATION |
| Schema validation | Payload documented | Parsing general, schema event incompleto | MISSING |

No se modificó el receiver porque no apareció un defecto local que impidiera continuar el análisis.

## OpenAI current capability

La documentación actual recomienda Responses API para requests directos de texto, JSON, herramientas y conversaciones stateful [11] [13]. `POST /v1/responses` devuelve un `Response` con `id`; la API ofrece recuperación y cancelación de respuestas. Structured Outputs usa JSON Schema estricto; en Responses el formato se expresa bajo `text.format` y los schemas deben declarar propiedades requeridas y `additionalProperties: false` en el subconjunto soportado [12] [15].

La autenticación usa Bearer API key o short-lived workload identity token. OpenAI recomienda mantener claves server-side, separarlas por proyectos/staging/production, rotarlas y usar límites de gasto y acceso por proyecto [13] [14].

Las respuestas exponen usage. OpenAI documenta `x-request-id`, límites y headers `x-ratelimit-*`, además de `X-Client-Request-Id` para correlación propia [13]. El Bridge debe persistir esos identificadores y no confundir `response.id` con un request ID HTTP.

No se obtuvo evidencia documental de una idempotency key nativa para una review semántica de Responses. La clasificación es **UNKNOWN**. El coordinator local sigue siendo obligatorio.

## OPENAI_ADAPTER_CONTRACT_V1

El contrato V1 del Bridge permanece congelado. La implementación futura debe adaptar Responses API a `createSession()` y `review()` sin exponer Responses-specific fields al Core. Una primera versión puede representar una review como una Response independiente con `decision_id`, `task_id` y `correlation_id` dentro del input; una futura conversación stateful puede usar `previous_response_id` o Conversations, pero eso requiere decisión propia porque cambia la semántica de almacenamiento y retención.

La salida debe validarse localmente contra `validateArchitectOutput()` incluso cuando Structured Outputs esté activo. Una refusal, output incompleto, schema violation, tool call inesperado o respuesta sin texto estructurado debe conservar el resultado como revisión no aplicable y no ejecutar una corrección.

## Security boundary

El Core debe recibir solo interfaces provider-neutral. `OPENAI_API_KEY`, workload tokens, `MANUS_API_KEY`, OAuth tokens y public-key material deben entrar únicamente en sus respectivos adapters. Ningún secreto debe entrar en `decision`, `audit_log`, error público, evidencia o texto enviado al otro provider.

Los errores públicos deben reducirse a códigos locales. Los logs internos pueden conservar provider request IDs y status codes, pero nunca Authorization headers, API keys, raw error bodies que puedan contener secretos o prompts completos sin redacción.

Los timeouts después de enviar una operación mutante deben producir `EXTERNAL_EFFECT_UNKNOWN`, no retry ciego. Los retries automáticos solo son seguros cuando la operación no fue enviada o existe garantía documentada de idempotencia. Para Manus create/send y OpenAI review, la garantía no está documentada en las fuentes consultadas.

## Implementation delta

| Archivo | Rol actual | Cambio requerido futuro | Riesgo | Test requerido |
|---|---|---|---|---|
| `src/manus.mjs` | Adapter v2 con fake-compatible fetch | Capturar `request_id`, mapear campos v2, clasificar errores, soportar API key y timeout configurable | Redispatch tras timeout | Contract tests con HTTP fake y replay/reconcile tests |
| `src/security.mjs` | Verifica firma local | Extraer key cache/refresh como componente separado; mantener URL exacta | Key rotation y URL mismatch | Official-vector signature tests y stale-key tests |
| `src/server.mjs` | Receiver fail-closed | Validar schema de eventos y responder rápido antes de reconciliación pesada | Provider retry por timeout | Signed webhook integration tests |
| `src/openai-adapter.mjs` | Transport abstraction/fake | Implementar Responses transport; mapear `text.format`, response ID, request ID, usage y refusals | Schema/retention mismatch | Responses adapter contract tests |
| `src/orchestrator.mjs` | Core provider-neutral | Persistir provider IDs y conservar gates actuales | Accidental provider coupling | Composition tests with real-shaped responses |
| `src/store.mjs` | Durable state/audit | Añadir campos o metadata redacted para provider IDs | Secret leakage | Redaction and restart tests |
| `package.json` | No real SDK dependency | Añadir SDK solo después de implementation order | Dependency drift | Lockfile and import tests |

## Implementation order recommendation

1. Implementar y testear el Manus adapter real con HTTP fake, sin credenciales.
2. Añadir persistencia redacted de `request_id`, task ID y webhook event ID.
3. Añadir public-key cache con invalidación controlada.
4. Implementar OpenAI Responses adapter con un transport fake de forma compatible con V1.
5. Ejecutar contract tests provider-shaped, todavía sin red real.
6. Solicitar una orden separada para R0–R1 cuando el propietario decida configurar credenciales.

## Final status

```text
MANUS_V2_CONTRACT_UNDERSTOOD       REQUIRES_REAL_VALIDATION
OPENAI_CONTRACT_UNDERSTOOD         REQUIRES_REAL_VALIDATION
D5_ATTESTATION_RESOLVED            REQUIRES_REAL_VALIDATION
OPENAI_V1_ADAPTER_COMPATIBLE       YES (by design; not runtime verified)
MANUS_ADAPTER_COMPATIBLE           REQUIRES_REAL_VALIDATION
SECURITY_MODEL_READY               REQUIRES_REAL_VALIDATION
REAL_E2E_PLAN_READY                YES

REAL_OPENAI_CALLS                  0
REAL_MANUS_CALLS                   0
REAL_CREDENTIALS                   0
ARKI_MODIFICATIONS                 0

READY FOR IMPLEMENTATION ORDER     YES, limited to adapter-only contract work
```

This is not authorization to implement real adapters, configure credentials, register webhooks, connect ARKI or execute real E2E.

## References

[1]: https://open.manus.ai/docs/v2/task.create "Manus API v2 task.create"
[2]: https://open.manus.ai/docs/v2/task-lifecycle "Manus API v2 task lifecycle"
[3]: https://open.manus.ai/docs/v2/task.listMessages "Manus API v2 task.listMessages"
[4]: https://open.manus.ai/docs/v2/task.sendMessage "Manus API v2 task.sendMessage"
[5]: https://open.manus.ai/docs/v2/task.detail "Manus API v2 task.detail"
[6]: https://open.manus.ai/docs/v2/authentication "Manus API v2 authentication"
[7]: https://open.manus.ai/docs/v2/webhooks-overview "Manus API v2 webhooks overview"
[8]: https://open.manus.ai/docs/v2/webhooks-security "Manus API v2 webhook security"
[9]: https://open.manus.ai/docs/v2/webhook.publicKey "Manus API v2 webhook.publicKey"
[10]: https://open.manus.ai/docs/v2/webhook.create "Manus API v2 webhook.create"
[11]: https://developers.openai.com/api/reference/resources/responses/methods/create "OpenAI Responses API create response"
[12]: https://developers.openai.com/api/docs/guides/structured-outputs "OpenAI Structured Outputs"
[13]: https://platform.openai.com/docs/api-reference/errors "OpenAI API authentication, errors, rate limits and request IDs"
[14]: https://platform.openai.com/docs/guides/production-best-practices "OpenAI production best practices"
[15]: https://platform.openai.com/docs/api-reference/responses "OpenAI Responses API reference"

**Source consultation date for all references:** 2026-09-25.
