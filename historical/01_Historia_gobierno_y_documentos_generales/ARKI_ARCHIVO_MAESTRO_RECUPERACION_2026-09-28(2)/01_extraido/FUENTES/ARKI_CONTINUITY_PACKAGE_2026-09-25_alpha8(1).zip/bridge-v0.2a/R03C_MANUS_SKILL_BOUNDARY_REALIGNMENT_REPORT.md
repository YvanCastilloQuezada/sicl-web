# R3C Manus Skill Boundary Realignment Report

**Orden:** `AB-R03C-MANUS-SKILL-BOUNDARY-REALIGNMENT-001`  
**Tipo:** Local only / no provider calls  
**Fecha:** 2026-09-25

## False assumption removed

```text
FALSE_SKILLS_NONE_ASSUMPTION_REMOVED=YES
DEFAULT_SKILLS_STATE=PROVIDER_CONTROLLED
DEFAULT_SKILLS_COUNT=UNKNOWN
```

The Bridge no longer represents `enable_skills: []` as proof that no skills are available or enabled. The provider-controlled state is preserved explicitly and unknown evidence remains `UNKNOWN`.

## R3 security boundary

```text
TASK_VISIBILITY=PRIVATE
CONNECTORS_ALLOWED=NONE
FILES_ALLOWED=NONE
TASK_REFERENCES_ALLOWED=NONE
FOLLOWUP_MESSAGES_ALLOWED=NONE
ACTION_CONFIRMATIONS_ALLOWED=NONE
EXTERNAL_EFFECTS_AUTHORIZED=NONE
```

`message.connectors: []` remains the explicit connector boundary. Skills are not selected manually; `force_skills` is rejected for R3. The local prompt remains defense in depth and does not substitute for the code boundary.

## Local implementation

Added `src/r3-boundary.mjs`, which defines the R3 boundary, rejects project/task references, files, connectors, selected skills, follow-up messages and confirmation operations, and classifies unavailable skill evidence as `UNKNOWN`.

Integrated R3C behavior into the existing flow:

- `ManusAdapter.createTask(..., {r3:true})` enforces private visibility and no requested connectors/files/selected skills.
- `ManusAdapter.sendMessage(..., {r3:true})` fails closed.
- `Orchestrator.dispatch(..., {r3:true})` applies the R3 creation gate and adds the bounded prompt defense.
- `Orchestrator.sendMessage(..., {r3:true})` blocks follow-ups.
- `Orchestrator.reconcile(..., {r3:true})` halts on waiting, confirmation, permission, connector authorization or observed external-action indicators instead of continuing as if authorized.
- Skill observations remain `UNKNOWN` unless the provider supplies sufficient evidence.

No OpenAI contract, Evidence Taxonomy, Decision Policy, webhook cryptography, ARKI source or deployment configuration was modified.

## Tests

Added `tests/r3c-boundary.test.mjs` covering:

- no false `SKILLS_NONE` claim;
- provider-controlled skill state;
- explicit connector none;
- private visibility;
- selected-skill rejection;
- files and task-reference rejection;
- follow-up and confirmation fail-closed behavior;
- waiting/external-action halt;
- preservation of `UNKNOWN` evidence.

Existing tests were preserved and all local suites passed:

```text
TESTS=105/105 PASS
PROVIDER_CONTRACT_TESTS=20/20 PASS
MOCK_E2E=14/14 PASS
SYNTAX=PASS
SECRET_LEAK_SCAN=PASS
PROVIDER_MODE=mock
```

## External-operation boundary

```text
REAL_MANUS_CALLS=0
REAL_OPENAI_CALLS=0
EXTERNAL_MUTATIONS=0
MANUS_TASKS_CREATED=0
MANUS_SEND_MESSAGES=0
CONNECTORS_USED=0
SKILLS_EXECUTED=0
ARKI_MODIFICATIONS=0
```

No provider call, task creation, follow-up, connector use, skill execution, confirmation or deployment occurred.

## Readiness

```text
WAITING_ACTION_FAIL_CLOSED=YES
UNKNOWN_EVIDENCE_PRESERVED=YES
READY_FOR_R3_RETRY=YES
BLOCKER=NONE_FOR_LOCAL_R3_AUTHORITY_BOUNDARY
```

`READY_FOR_R3_RETRY=YES` means the Bridge can now prevent itself from authorizing the R3 external actions covered by this phase without making a false claim that provider-controlled skills are absent. It does not authorize execution of R3; the separate R3 Decision Lock remains required.

## STOP

R3C is complete. R3, R4, real Manus calls and real OpenAI calls were not started.
