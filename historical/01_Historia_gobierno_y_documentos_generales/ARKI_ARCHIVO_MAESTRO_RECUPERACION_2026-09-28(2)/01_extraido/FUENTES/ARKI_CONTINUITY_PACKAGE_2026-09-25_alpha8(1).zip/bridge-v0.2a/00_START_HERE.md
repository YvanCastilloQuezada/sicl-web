# Start Here — ARKI Agent Bridge Closeout

## What this package is

This package contains the frozen baseline and continuity materials for **ARKI Agent Bridge**, a private auxiliary integration layer between ChatGPT/OpenAI and Manus. The Bridge is not ARKI and is deliberately decoupled from ARKI.

## What was verified

R4 is `E2E_VERIFIED` for the scope `SYNTHETIC_CONTROLLED_ARKI_AGENT_BRIDGE`. A real OpenAI order was governed by the Bridge, a private synthetic Manus task was created with empty connectors and files, the result was reconciled, the SQLite store was closed and reopened, and a real OpenAI review completed the decision in governed state `COMPLETED`.

## What was not verified

`ARKI_INTEGRATION_VERIFIED=NO`. No ARKI code, runtime, repository, deployment, webhook, or product workflow was connected. Production operation and credit cost are not established.

## Read next

1. Read `BASELINE/BRIDGE_FINAL_BASELINE.md` for the frozen claims.
2. Read `02_CURRENT_STATE.md` and `03_NEXT_ACTION.md` for the handoff.
3. Read `GOVERNANCE/CAPABILITY_LEDGER.md` before making capability claims.
4. Read `RECOVERY/VERIFY_PACKAGE.md` before rebuilding or moving the package.

## Non-negotiable boundaries

Do not modify ARKI while working on the Bridge. Do not activate real providers without explicit authorization. Do not create tasks, webhooks, deployments, publications, merges, or external effects from a cold start. `CREAR ≠ PUBLICAR`.

## Evidence location

The primary R4 evidence is `R04_REAL_BRIDGE_E2E_FINAL_REPORT.md`. The source of truth for behavior is the code and tests under `src/`, `migrations/`, and `tests/`; reports are claims that must be checked against those artifacts.

## Next work

The next authorized action is **ARKI deep capability radiography**, not Bridge feature development. That work must begin as a separate ARKI audit and must preserve the no-touch boundary.

## References

[1]: BASELINE/BRIDGE_FINAL_BASELINE.md "Frozen Bridge baseline"
[2]: GOVERNANCE/CAPABILITY_LEDGER.md "Capability and limitation ledger"
[3]: 03_NEXT_ACTION.md "Next authorized action"
