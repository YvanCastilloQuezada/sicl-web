# Residual Risks

The most important residual risk is scope interpretation: R4 proves only a synthetic controlled Bridge circuit. It does not prove that ARKI can safely delegate product work to the Bridge.

Provider trust remains partial. Real provider responses, credit accounting, rate limits, key rotation, webhook delivery, and service-side idempotency can change. The Bridge records provenance and uses fail-closed controls, but a provider response is not independent proof of artifact truth.

The package is not a deployed service. Operational risks such as process supervision, network isolation, backup retention, database permissions, TLS termination, and incident response require a separate deployment decision.

The package includes historical reports that may describe earlier snapshots. The frozen baseline and source/tests in this package are authoritative for closeout; older reports are historical evidence and must not silently override later corrections.

## References

[1]: ../BASELINE/BRIDGE_FINAL_BASELINE.md "Baseline limitations"
[2]: ../R04_REAL_BRIDGE_E2E_FINAL_REPORT.md "R4 synthetic scope"
