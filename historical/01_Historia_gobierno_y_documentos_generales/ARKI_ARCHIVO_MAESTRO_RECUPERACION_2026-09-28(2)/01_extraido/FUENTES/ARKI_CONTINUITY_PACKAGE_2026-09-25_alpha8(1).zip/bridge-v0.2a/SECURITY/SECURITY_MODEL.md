# Security Model

The Bridge uses a deny-by-default model around credentials, provider calls, authority, and external effects. Provider mode defaults to `mock`; real adapters require explicit real mode and non-placeholder credentials. Secrets are read only from the runtime boundary, redacted before diagnostics, and never copied into reports, SQLite evidence, source, or the package.

Manus tasks used for R3 and R4 were required to be private. R4 also required empty connectors and files. The Bridge treats provider responses and task messages as untrusted data. A message cannot grant permission, expand scope, authorize publication, or override Human Authority.

The external-effects coordinator persists intent and provider identity. If the provider may have succeeded but local persistence fails, the effect becomes unknown and is not blindly retried. Durable idempotency claims prevent duplicate dispatch and duplicate review. Revocation and kill states are checked before and after asynchronous work.

The Budget Enforcer limits external calls and usage. The Loop Governor detects repeated actions, stagnant results, failures, and retry exhaustion. The system escalates instead of continuing when a material boundary is ambiguous.

## References

[1]: ../src/provider-config.mjs "Provider mode and secret boundary"
[2]: ../src/external-effects.mjs "External effects coordinator"
[3]: ../src/autonomy-control.mjs "Autonomy control layer"
