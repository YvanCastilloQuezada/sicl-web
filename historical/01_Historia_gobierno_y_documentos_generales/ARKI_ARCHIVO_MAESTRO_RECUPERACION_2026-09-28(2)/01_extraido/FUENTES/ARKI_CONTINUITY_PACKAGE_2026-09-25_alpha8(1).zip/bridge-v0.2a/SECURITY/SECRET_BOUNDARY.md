# Secret Boundary

The package contains no real API keys, tokens, private keys, credential fingerprints, or secret-bearing logs. `RECOVERY/ENV_TEMPLATE.env` contains names and placeholders only.

The allowed secret flow is:

```text
secure connector/runtime injection
        → process environment
        → explicit real adapter constructor
        → provider request header
        → sanitized error metadata only
```

The package does not prescribe copying a secret into a terminal, report, Markdown file, SQLite database, or repository. A new operator must use the platform's secure connector mechanism and verify presence only as `YES` or `NO`.

## References

[1]: ../src/provider-config.mjs "Provider configuration and redaction"
[2]: ../RECOVERY/ENV_TEMPLATE.env "Secret-free environment template"
