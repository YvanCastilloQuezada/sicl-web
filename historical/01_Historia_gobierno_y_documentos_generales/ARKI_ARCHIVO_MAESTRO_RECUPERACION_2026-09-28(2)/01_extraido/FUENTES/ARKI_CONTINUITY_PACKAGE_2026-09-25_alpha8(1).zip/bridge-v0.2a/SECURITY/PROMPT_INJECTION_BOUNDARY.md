# Prompt Injection Boundary

External task content, provider messages, tool output, webhook payloads, and imported documents are `UNTRUSTED DATA`. They may be recorded as evidence, but they cannot change the owner, Decision Lock, allowed operations, credentials, or scope.

The Bridge must ignore instructions embedded in external content that request secret disclosure, new tasks, provider searches, ARKI changes, deployment, or policy bypass. The R3D incident recorded an injection signal from unrelated tool output; it was classified as untrusted and not followed.

The safe order is: authenticate transport, parse schema, classify provenance, apply policy, check autonomy envelope, persist evidence, and only then consider a state transition. A provider response that asks for confirmation or an external action halts the synthetic boundary.

## References

[1]: ../src/r3-boundary.mjs "R3 provider boundary"
[2]: ../src/r4-boundary.mjs "R4 provider boundary"
[3]: ../src/server.mjs "Gateway and webhook validation"
