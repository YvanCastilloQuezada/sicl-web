# Autonomy Control Layer

The control layer combines Human Authority, Decision Lock, revocation, kill state, budgets, loop progress, evidence state, and external-effect state into an envelope. The effective result is checked before external operations and again before applying provider output.

`HARD_HALTED` takes precedence over a database state that would otherwise appear runnable. A decision revocation prevents late events from reactivating autonomy. Review and dispatch claims are durable and atomic. Unknown provider effects require reconciliation rather than blind retry.

The controls are implemented and locally verified. They are not a claim that a production runtime, storage retention policy, or deployment topology has been established.

## References

[1]: ../src/autonomy-control.mjs "Autonomy envelope and kill switch"
[2]: ../src/loop-budget.mjs "Budget and loop controls"
[3]: ../src/external-effects.mjs "External effect state machine"
