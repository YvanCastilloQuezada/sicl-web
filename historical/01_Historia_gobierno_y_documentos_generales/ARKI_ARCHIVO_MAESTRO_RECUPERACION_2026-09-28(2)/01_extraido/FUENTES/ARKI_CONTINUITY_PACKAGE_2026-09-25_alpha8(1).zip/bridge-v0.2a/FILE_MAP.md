# File Map

| Path | Purpose | Authority | Type | Modify when |
|---|---|---|---|---|
| `src/orchestrator.mjs` | Core coordination and gates | Authoritative source | Source | A governed workflow changes. |
| `src/store.mjs` | SQLite persistence and audit | Authoritative source | Source | Durable state changes. |
| `src/policy.mjs` | Human Authority policy | Authoritative source | Source | Governance decision changes. |
| `src/policy-contract.mjs` | OpenAI policy fields | Authoritative source | Source | Frozen contract is explicitly reopened. |
| `src/autonomy-control.mjs` | Kill, revocation, envelope | Authoritative source | Source | Autonomy control changes. |
| `src/external-effects.mjs` | External effect lifecycle | Authoritative source | Source | Side-effect semantics change. |
| `src/openai-real-adapter.mjs` | OpenAI Responses adapter | Authoritative source | Source | Provider contract or schema changes. |
| `src/manus.mjs` | Manus v2 adapter | Authoritative source | Source | Manus contract changes. |
| `src/manus-real-adapter.mjs` | Real-mode boundary wrapper | Authoritative source | Source | Activation policy changes. |
| `src/security.mjs` | Internal auth and webhook security | Authoritative source | Source | Security boundary changes. |
| `src/r3-boundary.mjs` / `src/r4-boundary.mjs` | Synthetic provider boundaries | Authoritative source | Source | Synthetic contract changes. |
| `migrations/*.sql` | Durable schema evolution | Authoritative source | Source | Store schema changes. |
| `tests/` | Local proof and contract tests | Verification artifacts | Tests | Behavior changes. |
| `tests/r04-real-run.mjs` | R4 real runner | Operational fixture | Test runner | Controlled real R4 only. |
| `R*.md`, `V02*.md` | Historical and phase reports | Not authoritative alone | Generated/report | When evidence is corrected. |
| `BASELINE/` | Frozen closeout claims | Handoff authority | Generated/document | Closeout changes only. |
| `GOVERNANCE/`, `SECURITY/`, `CONTRACTS/` | Control and contract package | Handoff authority | Generated/document | Governance or contract changes. |
| `RECOVERY/`, `NEXT_CHAT/`, `CONTINUITY/` | Rebuild and continuity | Handoff authority | Generated/document | Recovery process changes. |
| `SHA256_MANIFEST.txt` | File integrity | Package authority | Generated | After package content changes. |

## References

[1]: BASELINE/BRIDGE_FINAL_BASELINE.md "Final baseline"
[2]: 00_START_HERE.md "Package entry point"
