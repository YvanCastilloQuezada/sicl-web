import {PublicError} from './schemas.mjs';
export class VerifierRegistry {
  constructor(entries={}){this.entries=new Map(Object.entries(entries).filter(([,v])=>v===true));}
  register(verifierId){if(typeof verifierId!=='string'||!verifierId.trim())throw new PublicError('VERIFIER_INVALID','Verifier identity is invalid',422);this.entries.set(verifierId,true);return verifierId;}
  isAuthorized(verifierId){return this.entries.get(verifierId)===true;}
  verify(evidenceId,verifierId,{store}={}){if(!this.isAuthorized(verifierId))throw new PublicError('VERIFIER_UNAUTHORIZED','Verifier is not authorized by Bridge',403);if(!store)throw new PublicError('VERIFIER_STORE_REQUIRED','Verifier store is required',500);const row=store.getEvidence(evidenceId);if(!row)throw new PublicError('EVIDENCE_NOT_FOUND','Evidence not found',404);store.markEvidenceVerified(evidenceId,verifierId);return store.getEvidence(evidenceId);}
}
