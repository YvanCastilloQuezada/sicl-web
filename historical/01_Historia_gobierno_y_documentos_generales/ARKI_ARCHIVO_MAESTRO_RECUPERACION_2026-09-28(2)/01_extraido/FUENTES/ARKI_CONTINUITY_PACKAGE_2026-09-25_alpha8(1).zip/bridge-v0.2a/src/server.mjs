import http from 'node:http';
import {BridgeStore} from './store.mjs';
import {ManusAdapter} from './manus.mjs';
import {Orchestrator} from './orchestrator.mjs';
import {PublicError, LIMITS, parseJson, validateDecision, validateMessage, validateTaskId} from './schemas.mjs';
import {assertBodySize, canonicalWebhookUrl, requireBridgeAuth, verifyManusWebhook} from './security.mjs';
import {validateManusWebhookEnvelope} from './manus-webhook-schema.mjs';

async function readBody(req) { const chunks=[]; let size=0; for await(const chunk of req) { size+=chunk.length; if(size>LIMITS.body) throw new PublicError('PAYLOAD_TOO_LARGE','Request body too large',413); chunks.push(chunk); } const body=Buffer.concat(chunks); assertBodySize(body); return body; }
const response=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));};
export function createServer({store=new BridgeStore(),manus=new ManusAdapter(),orchestrator=new Orchestrator({store,manus})}={}) {
 return http.createServer(async(req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try {
   if(req.method==='GET'&&url.pathname==='/health') return response(res,200,{ok:true,bridge:'ARKI Agent Bridge',version:'0.2a'});
   if(url.pathname==='/webhooks/manus'&&req.method==='POST') { const raw=await readBody(req); const canonical=canonicalWebhookUrl(process.env.MANUS_WEBHOOK_PUBLIC_URL); const verified=verifyManusWebhook({rawBody:raw,url:canonical,timestamp:req.headers['x-webhook-timestamp'],signature:req.headers['x-webhook-signature'],publicKeyPem:process.env.MANUS_WEBHOOK_PUBLIC_KEY_PEM}); const event=validateManusWebhookEnvelope(parseJson(raw)); const out=await orchestrator.handleVerifiedEvent({event,signatureTimestamp:verified.timestamp}); return response(res,200,{ok:true,transport_authenticity:'VERIFIED',verification_status:'PROVENANCE_VERIFIED',artifact_truth:'UNKNOWN',...out}); }
   requireBridgeAuth(req.headers);
   if(url.pathname==='/decisions'&&req.method==='POST') { const body=validateDecision(parseJson(await readBody(req))); const key=String(req.headers['idempotency-key']||''); const claim=store.claimIdempotency(key,'decision.create',body); if(!claim.claimed) return response(res,200,{ok:true,replayed:true,...claim.result}); const decision=orchestrator.createDecision(body); const result={decision}; store.finishIdempotency(key,result); return response(res,201,{ok:true,...result}); }
   const decisionMatch=url.pathname.match(/^\/decisions\/([^/]+)\/dispatch$/); if(decisionMatch&&req.method==='POST') { const out=await orchestrator.dispatch(decisionMatch[1],parseJson(await readBody(req))); return response(res,202,{ok:true,...out}); }
   const msgMatch=url.pathname.match(/^\/tasks\/([^/]+)\/messages$/); if(msgMatch&&req.method==='POST') { const body=validateMessage(parseJson(await readBody(req))); const key=String(req.headers['idempotency-key']||''); const out=await orchestrator.sendMessage(validateTaskId(msgMatch[1]),body.content,{idempotencyKey:key||null}); return response(res,200,{ok:true,result:out}); }
   const taskMatch=url.pathname.match(/^\/tasks\/([^/]+)$/); if(taskMatch&&req.method==='GET') { const result=await orchestrator.reconcile(validateTaskId(taskMatch[1])); return response(res,200,{ok:true,...result}); }
   return response(res,404,{ok:false,error:{code:'NOT_FOUND',message:'Not found'}});
  } catch(error) { const e=error instanceof PublicError?error:(error?.message==='IDEMPOTENCY_CONFLICT'?new PublicError('IDEMPOTENCY_CONFLICT','Idempotency key reused with different payload',409):new PublicError('INTERNAL_ERROR','Internal error',500)); return response(res,e.status,{ok:false,error:{code:e.code,message:e.message,retryable:e.retryable||false}}); }
 });
}
if(process.argv[1]===new URL(import.meta.url).pathname) { const server=createServer(); const port=Number(process.env.BRIDGE_PORT||8787); server.listen(port,'127.0.0.1',()=>console.log(`Bridge v0.2A listening on ${port}`)); }
