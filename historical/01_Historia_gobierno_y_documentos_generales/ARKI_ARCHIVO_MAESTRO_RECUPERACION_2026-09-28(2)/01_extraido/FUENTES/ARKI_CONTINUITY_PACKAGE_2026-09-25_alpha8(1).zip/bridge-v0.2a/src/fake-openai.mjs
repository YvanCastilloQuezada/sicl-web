export class FakeOpenAIAdapter {
  constructor(response={classification:'REVIEW_ALLOWED',summary:'fake review',next_action:'hold',scope_delta:false,requires_human:false,reason:'test'}) { this.response=response; this.calls=[]; }
  async review(input) { this.calls.push(input); return {...this.response,decision_id:input.decision_id}; }
}
export function validateOpenAIResult(result) {
  const allowed=['AUTO_ALLOWED','REVIEW_ALLOWED','HUMAN_REQUIRED','PROHIBITED'];
  if (!result || typeof result.decision_id!=='string' || !allowed.includes(result.classification) || typeof result.summary!=='string' || typeof result.next_action!=='string' || typeof result.scope_delta!=='boolean' || typeof result.requires_human!=='boolean') throw new Error('Invalid structured OpenAI result');
  return result;
}
