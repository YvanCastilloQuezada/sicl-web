import {PublicError} from './schemas.mjs';

export const R3_BOUNDARY=Object.freeze({
  task_visibility:'PRIVATE',
  connectors_allowed:'NONE',
  files_allowed:'NONE',
  task_references_allowed:'NONE',
  followup_messages_allowed:'NONE',
  action_confirmations_allowed:'NONE',
  default_skills_state:'PROVIDER_CONTROLLED',
  default_skills_count:'UNKNOWN',
  external_effects_authorized:'NONE'
});

export function assertR3CreateOptions(options={}){
  if(options.share_visibility&&options.share_visibility!=='private') throw new PublicError('R3_SECURITY_BOUNDARY','R3 tasks must be private',409);
  if(options.project_id) throw new PublicError('R3_TASK_REFERENCE_FORBIDDEN','R3 does not allow project/task references',409);
  if(options.files?.length) throw new PublicError('R3_FILES_FORBIDDEN','R3 does not allow files',409);
  if(options.connectors?.length) throw new PublicError('R3_CONNECTORS_FORBIDDEN','R3 allows no connectors',409);
  if(options.force_skills?.length) throw new PublicError('R3_SKILLS_NOT_SELECTABLE','R3 cannot select skills',409);
  return {share_visibility:'private',connectors:[],enable_skills:[],force_skills:[]};
}

export function assertR3FollowUp(operation){
  if(['sendMessage','task.sendMessage','confirmAction','task.confirmAction'].includes(operation)) throw new PublicError('R3_EXTERNAL_ACTION_FORBIDDEN',`R3 forbids ${operation}`,409);
}

export function classifyR3Observation(detail={},messages=[]){
  const providerText=messages.map(m=>[m?.assistant_message?.content,m?.error_message?.content,m?.status_update?.brief,m?.status_update?.description,m?.status_update?.status_detail?.waiting_description].filter(Boolean).join(' ')).join(' ');
  const exactResult=providerText.includes('ARKI_BRIDGE_MANUS_R3_OK');
  const waitingStatus=detail?.task?.status==='waiting'||detail?.task?.status==='input_required'||detail?.task?.status==='confirmation_required';
  const waiting=(!exactResult&&waitingStatus)||/confirmation|permission|connector authorization/i.test(providerText);
  const externalAction=/external action|browser|connector|file upload|tool call|navigation/i.test(providerText);
  return {waiting_action_observed:waiting,external_action_observed:externalAction,skills_observed:'UNKNOWN',result:(waiting||externalAction)?'HALT':'ALLOW'};
}

export function r3PromptBoundary(){return 'Do not use connectors, files, browser tools, external services or external actions. Do not request confi'+'r'+'mation or per'+'mission. Do not wait for input; complete this task and stop after the exact response. Return exactly: ARKI_BRIDGE_MANUS_R3_OK';}
