import crypto from 'node:crypto';
import {PublicError} from './schemas.mjs';
import {buildArchitectRequest, validateArchitectOutput} from './openai-adapter.mjs';
import {providerHeaders, providerMode, requireRealProvider, redactSecrets} from './provider-config.mjs';

const BASE='https://api.openai.com/v1';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const OUTPUT_SCHEMA={type:'object',properties:{decision_id:{type:'string'},classification:{type:'string',enum:['AUTO_ALLOWED','REVIEW_ALLOWED','HUMAN_REQUIRED','PROHIBITED']},assessment:{type:'string'},next_action:{type:'string'},scope_delta:{type:'boolean'},requires_human:{type:'boolean'},reason:{type:'string'},evidence_to_preserve:{type:'array',items:{type:'string'}},acceptance_status:{type:'string',enum:['PASS','FAIL','PARTIAL','UNKNOWN']},policy_category:{anyOf:[{type:'string',enum:['SCOPE','SECURITY','COST','CREDENTIAL','ARCHITECTURE','PROFESSIONAL','EXECUTION','EVIDENCE','NONE']},{type:'null'}]},contract:{type:['string','null']}},required:['decision_id','classification','assessment','next_action','scope_delta','requires_human','reason','evidence_to_preserve','acceptance_status','policy_category','contract'],additionalProperties:false};
function responseText(data){
  if(typeof data?.output_text==='string') return data.output_text;
  for(const item of data?.output||[]) for(const part of item?.content||[]) if(typeof part?.text==='string') return part.text;
  return null;
}
function detectTool(data){ return (data?.output||[]).some(x=>['function_call','custom_tool_call','computer_call','web_search_call','file_search_call'].includes(x?.type)); }
export class OpenAIRealAdapter {
  constructor({apiKey=null,projectId=null,base=BASE,fetchImpl=fetch,timeoutMs=10000,maxRetries=0,mode=providerMode()}={}){this.apiKey=apiKey;this.projectId=projectId;this.base=base;this.fetch=fetchImpl;this.timeoutMs=timeoutMs;this.maxRetries=maxRetries;this.mode=mode;}
  assertEnabled(){return requireRealProvider('OpenAI',{mode:this.mode,apiKey:this.apiKey,projectId:this.projectId});}
  async request(input,{correlationId=crypto.randomUUID()}={}){
    this.assertEnabled(); const body={model:input.model||process.env.OPENAI_MODEL||'gpt-5.6-terra',input:JSON.stringify(input.request),text:{format:{type:'json_schema',name:'architect_v1',strict:true,schema:OUTPUT_SCHEMA}},tools:[]}; let attempts=0;
    for(let attempt=0;;attempt++){
      const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),this.timeoutMs);let response;
      try{response=await this.fetch(`${this.base}/responses`,{method:'POST',signal:controller.signal,headers:providerHeaders({apiKey:this.apiKey,projectId:this.projectId,clientRequestId:correlationId}),body:JSON.stringify(body)});const data=await response.json().catch(()=>null);const requestId=response.headers?.get?.('x-request-id')||null;const metadata={response_id:data?.id||null,request_id:requestId,client_request_id:correlationId,model:data?.model||body.model,usage:data?.usage||null,rate_limits:{}};for(const [k,v] of response.headers?.entries?.()||[])if(k.toLowerCase().startsWith('x-ratelimit-'))metadata.rate_limits[k.toLowerCase()]=v;if(response.ok){if(detectTool(data))throw new PublicError('UNEXPECTED_PROVIDER_TOOL','OpenAI returned an unexpected tool request',409);const refusal=(data?.output||[]).flatMap(x=>x?.content||[]).find(x=>x?.type==='refusal'||x?.refusal);if(refusal)throw new PublicError('NON_EXECUTABLE_PROVIDER_RESULT','OpenAI refused the Architect review',422);const text=responseText(data);if(!text)throw new PublicError('OPENAI_MALFORMED_RESPONSE','OpenAI response contained no structured output',502);let output;try{output=JSON.parse(text);}catch{throw new PublicError('OPENAI_MALFORMED_RESPONSE','OpenAI structured output was not valid JSON',502);}return {output:validateArchitectOutput(output),usage:data?.usage||null,metadata};}const retryable=response.status===429||response.status>=500;if(retryable&&attempt<this.maxRetries){attempts++;await sleep(50*2**attempt);continue;}const err=new PublicError(response.status===401||response.status===403?'OPENAI_AUTH_ERROR':'OPENAI_API_ERROR',`OpenAI request failed (${response.status})`,response.status===429||response.status>=500?503:502,retryable);err.retry_count=attempts;err.provider_request_id=requestId;throw err;}
      catch(e){if(e instanceof PublicError){if(!e.retryable||attempt>=this.maxRetries){e.retry_count=attempts;throw e;}}if(attempt<this.maxRetries){attempts++;await sleep(50*2**attempt);continue;}const err=new PublicError('OPENAI_TIMEOUT_OR_NETWORK','OpenAI provider unavailable',504,true);err.retry_count=attempts;throw err;}finally{clearTimeout(timer);}
    }
  }
  async createSession(input,{sessionId=crypto.randomUUID()}={}){this.assertEnabled();return {sessionId,event:{type:'session.created',id:`${sessionId}:created`}};}
  async review(input,{sessionId}={}){this.assertEnabled();if(!sessionId)throw new PublicError('OPENAI_SESSION_REQUIRED','OpenAI session_id is required',422);const request=buildArchitectRequest(input);const result=await this.request({request},{correlationId:input.correlation_id});return {output:result.output,events:[{type:'session.idle',id:`${sessionId}:idle`}],usage:result.usage,metadata:result.metadata};}
}
export function safeProviderError(error){return redactSecrets({code:error?.code,message:error?.message,provider_request_id:error?.provider_request_id});}
