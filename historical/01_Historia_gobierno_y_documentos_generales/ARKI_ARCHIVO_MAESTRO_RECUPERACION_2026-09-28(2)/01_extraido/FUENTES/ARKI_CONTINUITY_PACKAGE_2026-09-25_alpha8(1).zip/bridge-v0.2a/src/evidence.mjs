import crypto from 'node:crypto';
import {PublicError} from './schemas.mjs';
export const EVIDENCE_TYPES=Object.freeze(['SOURCE_ARTIFACT','EXECUTION_ARTIFACT','SYSTEM_ARTIFACT','EXTERNAL_ARTIFACT','HUMAN_AUTHORITY_ARTIFACT']);
export const EVIDENCE_STATES=Object.freeze(['CLAIMED','CAPTURED','INTEGRITY_VERIFIED','PROVENANCE_VERIFIED','INDEPENDENTLY_VERIFIED','CONTRADICTED','UNKNOWN']);
export function artifactHash(value){return crypto.createHash('sha256').update(typeof value==='string'?value:JSON.stringify(value??{})).digest('hex');}
export function validateEvidence(input){
  const fields=['evidence_id','evidence_type','source','producer','timestamp','provenance','integrity_status','verification_status','decision_id','correlation_id'];
  if(!input||typeof input!=='object'||fields.some(k=>input[k]===undefined))throw new PublicError('EVIDENCE_SCHEMA_INVALID','Evidence metadata is incomplete',422);
  if(!EVIDENCE_TYPES.includes(input.evidence_type)||!EVIDENCE_STATES.includes(input.integrity_status)||!EVIDENCE_STATES.includes(input.verification_status))throw new PublicError('EVIDENCE_SCHEMA_INVALID','Evidence enum is invalid',422);
  if(input.verification_status==='INDEPENDENTLY_VERIFIED')throw new PublicError('EVIDENCE_SELF_VERIFICATION_FORBIDDEN','INDEPENDENTLY_VERIFIED requires a Bridge VerifierRegistry act',422);
  return input;
}
export function captureEvidence({evidence_id, evidence_type, source, producer, timestamp=Date.now(), artifact, provenance, decision_id, correlation_id, claim=null, verification_status='UNKNOWN', metadata={}}){
  const integrity_status=artifact===undefined?'UNKNOWN':'INTEGRITY_VERIFIED';
  return validateEvidence({evidence_id,evidence_type,source,producer,timestamp,artifact_hash:artifact===undefined?null:artifactHash(artifact),provenance,integrity_status,verification_status,decision_id,correlation_id,claim,metadata});
}
export function externalArtifact({decisionId,correlationId,source,producer,artifact,claim=null}){return captureEvidence({evidence_id:crypto.randomUUID(),evidence_type:'EXTERNAL_ARTIFACT',source,producer,artifact,provenance:'provider-response',decision_id:decisionId,correlation_id:correlationId,claim});}
export function verificationAct({evidenceId,verifierId,registry,store}){if(!registry?.isAuthorized(verifierId))throw new PublicError('VERIFIER_UNAUTHORIZED','Verifier is not authorized by Bridge',403);return registry.verify(evidenceId,verifierId,{store});}
