import crypto from 'node:crypto';
import {PublicError, LIMITS} from './schemas.mjs';

export function requireBridgeAuth(headers, secret=process.env.BRIDGE_INTERNAL_SECRET) {
  if (!secret) throw new PublicError('BRIDGE_AUTH_NOT_CONFIGURED','Bridge authentication is not configured',503);
  const supplied = String(headers['x-bridge-auth'] || '');
  const a=Buffer.from(supplied), b=Buffer.from(secret);
  if (!a.length || a.length !== b.length || !crypto.timingSafeEqual(a,b)) throw new PublicError('UNAUTHORIZED','Authentication required',401);
}
export function verifyManusWebhook({rawBody,url,timestamp,signature,publicKeyPem,now=Date.now()}) {
  if (!publicKeyPem) throw new PublicError('WEBHOOK_KEY_NOT_CONFIGURED','Webhook verification key is not configured',503);
  if (!timestamp || !signature) throw new PublicError('INVALID_WEBHOOK_SIGNATURE','Webhook signature headers are required',401);
  const ts=Number(timestamp); if (!Number.isFinite(ts) || Math.abs(Math.floor(now/1000)-ts)>300) throw new PublicError('EXPIRED_WEBHOOK','Webhook timestamp expired',401);
  if (!/^https:\/\//.test(url)) throw new PublicError('INVALID_WEBHOOK_URL','Webhook canonical URL must be HTTPS',401);
  const digest=crypto.createHash('sha256').update(rawBody).digest('hex');
  const signed=`${timestamp}.${url}.${digest}`;
  let valid=false; try { valid=crypto.verify('RSA-SHA256',Buffer.from(signed),publicKeyPem,Buffer.from(signature,'base64')); } catch { valid=false; }
  if (!valid) throw new PublicError('INVALID_WEBHOOK_SIGNATURE','Invalid webhook signature',401);
  return {timestamp:ts,payloadSha:digest};
}
export function assertBodySize(raw) { if (raw.length > LIMITS.body) throw new PublicError('PAYLOAD_TOO_LARGE','Request body too large',413); }
export function canonicalWebhookUrl(configured, requestUrl) { if (!configured || !/^https:\/\//.test(configured)) throw new PublicError('WEBHOOK_URL_NOT_CONFIGURED','Canonical HTTPS webhook URL is required',503); return configured; }
