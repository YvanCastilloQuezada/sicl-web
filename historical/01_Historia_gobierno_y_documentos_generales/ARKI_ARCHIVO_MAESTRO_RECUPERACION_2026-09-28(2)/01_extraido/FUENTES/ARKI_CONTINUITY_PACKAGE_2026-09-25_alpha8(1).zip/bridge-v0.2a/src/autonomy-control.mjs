import crypto from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, renameSync, writeFileSync} from 'node:fs';
import {dirname} from 'node:path';

export const AUTONOMY_RESULT=Object.freeze({ALLOW:'ALLOW',PAUSE:'PAUSE',HALT:'HALT',HUMAN_REQUIRED:'HUMAN_REQUIRED'});
export const KILL_STATE=Object.freeze({RUNNING:'RUNNING',SOFT_PAUSED:'SOFT_PAUSED',HARD_HALTED:'HARD_HALTED'});
export const CONTROL_REASON=Object.freeze({KILL_SWITCH:'KILL_SWITCH',BUDGET:'BUDGET',LOOP:'LOOP',REVOCATION:'REVOCATION',SECURITY:'SECURITY',EVIDENCE:'EVIDENCE',SCOPE:'SCOPE'});
const rank=Object.freeze({ALLOW:0,PAUSE:1,HUMAN_REQUIRED:2,HALT:3});
export const CONSERVATIVE_DEFAULTS=Object.freeze({max_cycles:10,max_corrections:3,max_external_calls:20,max_retries:3,max_elapsed_time_ms:15*60*1000,max_consecutive_failures:3,max_repeated_actions:2,max_stagnant_results:2});
export const PROPOSAL_STATUS='PROPOSED';
export function canonicalHash(value){return crypto.createHash('sha256').update(typeof value==='string'?value:JSON.stringify(value??{})).digest('hex');}
export function mostRestrictive(results){return results.reduce((best,current)=>rank[current.result]>rank[best.result]?current:best,{result:AUTONOMY_RESULT.ALLOW,reason_code:null});}
export function evaluateEnvelope(envelope){
  const results=[{result:AUTONOMY_RESULT.ALLOW,reason_code:null}];
  if(envelope.authorized_scope===false) results.push({result:AUTONOMY_RESULT.HUMAN_REQUIRED,reason_code:CONTROL_REASON.SCOPE});
  if(envelope.killState===KILL_STATE.HARD_HALTED) results.push({result:AUTONOMY_RESULT.HALT,reason_code:CONTROL_REASON.KILL_SWITCH});
  else if(envelope.killState===KILL_STATE.SOFT_PAUSED) results.push({result:AUTONOMY_RESULT.PAUSE,reason_code:CONTROL_REASON.KILL_SWITCH});
  if(envelope.budgetState==='HARD_LIMIT') results.push({result:AUTONOMY_RESULT.HALT,reason_code:CONTROL_REASON.BUDGET});
  else if(envelope.budgetState==='HUMAN_REQUIRED') results.push({result:AUTONOMY_RESULT.HUMAN_REQUIRED,reason_code:CONTROL_REASON.BUDGET});
  else if(envelope.budgetState==='PAUSED') results.push({result:AUTONOMY_RESULT.PAUSE,reason_code:CONTROL_REASON.BUDGET});
  if(envelope.loopState==='CIRCUIT_OPEN') results.push({result:AUTONOMY_RESULT.HALT,reason_code:CONTROL_REASON.LOOP});
  else if(envelope.loopState==='STAGNANT'||envelope.loopState==='LIMIT_REACHED') results.push({result:AUTONOMY_RESULT.PAUSE,reason_code:CONTROL_REASON.LOOP});
  if(envelope.revocationState==='REVOKED') results.push({result:AUTONOMY_RESULT.HALT,reason_code:CONTROL_REASON.REVOCATION});
  if(envelope.securityState==='BLOCKED') results.push({result:AUTONOMY_RESULT.HUMAN_REQUIRED,reason_code:CONTROL_REASON.SECURITY});
  if(envelope.evidenceState==='CONTRADICTED') results.push({result:AUTONOMY_RESULT.HUMAN_REQUIRED,reason_code:CONTROL_REASON.EVIDENCE});
  return mostRestrictive(results);
}
export class KillSwitch {
  constructor({store,filePath=process.env.BRIDGE_KILL_SWITCH_PATH||null}={}){this.store=store;this.filePath=filePath;}
  state(decisionId){const row=this.store.getAutonomyControl(decisionId); const outOfBand=this.outOfBandState(); if(outOfBand===KILL_STATE.HARD_HALTED)return KILL_STATE.HARD_HALTED; if(outOfBand===KILL_STATE.SOFT_PAUSED&&row?.kill_state!==KILL_STATE.HARD_HALTED)return KILL_STATE.SOFT_PAUSED; return row?.kill_state||KILL_STATE.RUNNING;}
  /** @deprecated Use setDecision() for scoped control or setGlobal() for OOB control. This compatibility alias is explicitly global and mirrors the supplied decision row only for legacy audit/restart compatibility. */
  set(decisionId,state,actor='system',reason='operator control'){if(!Object.values(KILL_STATE).includes(state))throw new Error('Invalid kill state'); this.setGlobal(state,actor,reason); this.store.setKillState(decisionId,state,{actor,reason}); return state;}
  setDecision(decisionId,state,actor='system',reason='operator control'){if(!Object.values(KILL_STATE).includes(state))throw new Error('Invalid kill state');return this.store.setKillState(decisionId,state,{actor,reason})&&state;}
  setGlobal(state,actor='system',reason='global operator control'){if(!Object.values(KILL_STATE).includes(state))throw new Error('Invalid kill state'); if(!this.filePath)throw new Error('Global kill switch path is not configured'); mkdirSync(dirname(this.filePath),{recursive:true});const tmp=`${this.filePath}.${process.pid}.tmp`;if(state===KILL_STATE.RUNNING){if(existsSync(this.filePath))renameSync(this.filePath,`${this.filePath}.cleared`);}else{writeFileSync(tmp,`${state}\n`);renameSync(tmp,this.filePath);} return state;}
  outOfBandState(){return this.filePath&&existsSync(this.filePath)?String(readFileSync(this.filePath)).trim():KILL_STATE.RUNNING;}
}
