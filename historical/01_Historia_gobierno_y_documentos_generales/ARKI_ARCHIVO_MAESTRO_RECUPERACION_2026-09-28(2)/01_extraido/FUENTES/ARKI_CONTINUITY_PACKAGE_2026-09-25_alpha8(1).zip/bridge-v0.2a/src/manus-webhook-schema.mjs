import {PublicError} from './schemas.mjs';
const TYPES=new Set(['task_created','task_stopped','task.created','task.stopped']);
export function validateManusWebhookEnvelope(event){
  if(!event||typeof event!=='object'||Array.isArray(event))throw new PublicError('WEBHOOK_ENVELOPE_INVALID','Webhook envelope must be an object',422);
  if(typeof event.event_id!=='string'||!event.event_id.trim())throw new PublicError('WEBHOOK_ENVELOPE_INVALID','Webhook event_id is required',422);
  if(typeof event.event_type!=='string'||!TYPES.has(event.event_type))throw new PublicError('WEBHOOK_ENVELOPE_INVALID','Unsupported Manus webhook event_type',422);
  const detail=event.task_detail||event.task;
  if(!detail||typeof detail!=='object'||typeof (detail.task_id||detail.id)!=='string')throw new PublicError('WEBHOOK_ENVELOPE_INVALID','Webhook task identity is required',422);
  return {...event,task_detail:{...detail,task_id:detail.task_id||detail.id}};
}
