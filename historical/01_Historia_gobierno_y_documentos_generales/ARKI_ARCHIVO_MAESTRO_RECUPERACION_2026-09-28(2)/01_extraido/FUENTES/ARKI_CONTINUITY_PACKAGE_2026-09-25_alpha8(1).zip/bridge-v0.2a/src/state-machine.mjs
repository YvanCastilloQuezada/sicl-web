export const STATES = Object.freeze({
  CREATED: 'CREATED', AUTHORIZED: 'AUTHORIZED', DISPATCHED: 'DISPATCHED', RUNNING: 'RUNNING',
  WAITING_EXTERNAL: 'WAITING_EXTERNAL', RESULT_RECEIVED: 'RESULT_RECEIVED', REVIEW_REQUIRED: 'REVIEW_REQUIRED',
  CORRECTION_REQUIRED: 'CORRECTION_REQUIRED', HUMAN_DECISION_REQUIRED: 'HUMAN_DECISION_REQUIRED',
  COMPLETED: 'COMPLETED', FAILED: 'FAILED', CANCELLED: 'CANCELLED'
});

const transitions = new Map([
  ['CREATED', new Set(['AUTHORIZED', 'FAILED', 'CANCELLED'])],
  ['AUTHORIZED', new Set(['DISPATCHED', 'HUMAN_DECISION_REQUIRED', 'FAILED', 'CANCELLED'])],
  ['DISPATCHED', new Set(['RUNNING', 'FAILED', 'CANCELLED'])],
  ['RUNNING', new Set(['WAITING_EXTERNAL', 'RESULT_RECEIVED', 'FAILED', 'CANCELLED'])],
  ['WAITING_EXTERNAL', new Set(['RUNNING', 'HUMAN_DECISION_REQUIRED', 'RESULT_RECEIVED', 'FAILED', 'CANCELLED'])],
  ['RESULT_RECEIVED', new Set(['REVIEW_REQUIRED', 'COMPLETED', 'FAILED'])],
  ['REVIEW_REQUIRED', new Set(['CORRECTION_REQUIRED', 'COMPLETED', 'HUMAN_DECISION_REQUIRED', 'FAILED'])],
  ['CORRECTION_REQUIRED', new Set(['DISPATCHED', 'HUMAN_DECISION_REQUIRED', 'FAILED', 'CANCELLED'])],
  ['HUMAN_DECISION_REQUIRED', new Set(['AUTHORIZED', 'CORRECTION_REQUIRED', 'CANCELLED', 'FAILED'])],
  ['COMPLETED', new Set([])], ['FAILED', new Set([])], ['CANCELLED', new Set([])]
]);

export function canTransition(from, to) {
  return Boolean(transitions.get(from)?.has(to));
}

export function assertTransition(from, to) {
  if (!from || !Object.values(STATES).includes(from)) throw new Error(`Unknown current state: ${from}`);
  if (!Object.values(STATES).includes(to)) throw new Error(`Unknown target state: ${to}`);
  if (!canTransition(from, to)) throw new Error(`Illegal transition: ${from} -> ${to}`);
}
