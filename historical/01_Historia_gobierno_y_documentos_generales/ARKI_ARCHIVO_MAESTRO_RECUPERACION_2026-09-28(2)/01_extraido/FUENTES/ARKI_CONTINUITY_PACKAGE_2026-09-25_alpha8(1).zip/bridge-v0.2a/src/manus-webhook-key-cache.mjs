import {PublicError} from './schemas.mjs';
import {providerMode,requireRealProvider} from './provider-config.mjs';
const BASE='https://api.manus.ai/v2';
export class ManusPublicKeyCache {
  constructor({apiKey=null,base=BASE,fetchImpl=fetch,ttlMs=15*60*1000,mode=providerMode()}={}){this.apiKey=apiKey;this.base=base;this.fetch=fetchImpl;this.ttlMs=Math.max(1000,Math.min(ttlMs,24*60*60*1000));this.mode=mode;this.cached=null;}
  enabled(){return requireRealProvider('Manus',{mode:this.mode,apiKey:this.apiKey});}
  async fetchKey(){this.enabled();let res;try{res=await this.fetch(`${this.base}/webhook.publicKey`,{headers:{'x-manus-api-key':this.apiKey}});}catch{throw new PublicError('MANUS_KEY_FETCH_FAILED','Manus public key unavailable',503,true);}const data=await res.json().catch(()=>null);if(!res.ok||!data?.public_key&&!data?.key&&!data?.publicKey)throw new PublicError('MANUS_KEY_FETCH_FAILED','Manus public key response invalid',502);const pem=data.public_key||data.key||data.publicKey;this.cached={pem,fetchedAt:Date.now(),requestId:data.request_id||null};return this.cached;}
  async get({force=false}={}){this.enabled();if(!force&&this.cached&&Date.now()-this.cached.fetchedAt<this.ttlMs)return {...this.cached,cache:'hit'};const key=await this.fetchKey();return {...key,cache:'refresh'};}
  async refresh(){return this.get({force:true});}
  clear(){this.cached=null;}
}
