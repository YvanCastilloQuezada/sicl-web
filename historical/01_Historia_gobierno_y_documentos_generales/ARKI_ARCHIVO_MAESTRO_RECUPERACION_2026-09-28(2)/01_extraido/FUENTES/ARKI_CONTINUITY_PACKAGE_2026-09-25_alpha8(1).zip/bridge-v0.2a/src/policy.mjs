export const POLICY = Object.freeze({AUTO_ALLOWED:'AUTO_ALLOWED', REVIEW_ALLOWED:'REVIEW_ALLOWED', HUMAN_REQUIRED:'HUMAN_REQUIRED', PROHIBITED:'PROHIBITED'});
export const HUMAN_CATEGORIES = Object.freeze(['ARCHITECTURAL_FORK','DESTRUCTIVE_OUT_OF_SCOPE','SECURITY_BOUNDARY','CREDENTIAL_REQUIRED','COST_OR_RESOURCE_DECISION','PROFESSIONAL_VALIDATION_REQUIRED','AMBIGUOUS_MATERIAL_SCOPE']);

export function classifyAction(action = {}) {
  if (action.prohibited === true || action.out_of_scope === true) return {classification: POLICY.PROHIBITED, reason:'Action is prohibited or outside authorized scope'};
  if (action.category && HUMAN_CATEGORIES.includes(action.category)) return {classification: POLICY.HUMAN_REQUIRED, reason:`Material category: ${action.category}`};
  if (action.scope_delta === true || action.requires_human === true) return {classification: POLICY.HUMAN_REQUIRED, reason:'Action changes scope or explicitly requires human authority'};
  if (action.review_required === true) return {classification: POLICY.REVIEW_ALLOWED, reason:'Review is required before execution'};
  return {classification: POLICY.AUTO_ALLOWED, reason:'Deterministic action within existing scope'};
}

export function assertDecisionOwner(decision, subject = 'yvan') {
  if (!decision || decision.owner_subject !== subject) throw new Error('Decision owner mismatch');
}
