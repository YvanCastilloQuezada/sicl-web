import {PublicError} from './schemas.mjs';

export const PROVIDER_MODES=Object.freeze(['mock','real']);
export function providerMode(env=process.env){ return env.PROVIDER_MODE==='real'?'real':'mock'; }
export function requireRealProvider(name,{mode=providerMode(),apiKey,projectId=null}={}){
  if(mode!=='real') throw new PublicError('PROVIDER_DISABLED',`${name} provider is disabled`,503);
  if(typeof apiKey!=='string'||!apiKey.trim()||/^(changeme|replace|placeholder|test|fake|dummy)/i.test(apiKey.trim())) throw new PublicError('PROVIDER_NOT_CONFIGURED',`${name} credentials are not configured`,503);
  return {name,projectId:projectId||null};
}
export function redactSecrets(value){
  const text=typeof value==='string'?value:JSON.stringify(value??{});
  return text
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi,'Bearer [REDACTED]')
    .replace(/(authorization\s*[:=]\s*)([^,}\s]+)/gi,'$1[REDACTED]')
    .replace(/((?:api[_-]?key|token|password|secret|cookie)\s*[:=]\s*)([^,}\s]+)/gi,'$1[REDACTED]')
    ;
}
export function providerHeaders({apiKey,projectId,clientRequestId}){
  const h={'content-type':'application/json','authorization':`Bearer ${apiKey}`};
  if(projectId) h['openai-project']=projectId;
  if(clientRequestId) h['x-client-request-id']=clientRequestId;
  return h;
}
