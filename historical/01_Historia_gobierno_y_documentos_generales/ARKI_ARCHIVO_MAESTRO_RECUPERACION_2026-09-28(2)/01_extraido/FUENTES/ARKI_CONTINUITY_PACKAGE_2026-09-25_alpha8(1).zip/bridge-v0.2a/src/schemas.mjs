export const LIMITS = Object.freeze({body: 128 * 1024, message: 16 * 1024, field: 32 * 1024});
export class PublicError extends Error { constructor(code, message, status=400, retryable=false) { super(message); this.code=code; this.status=status; this.retryable=retryable; } }
const required = (obj, fields) => { for (const field of fields) if (typeof obj?.[field] !== 'string' || !obj[field].trim()) throw new PublicError('VALIDATION_ERROR', `Missing or invalid field: ${field}`); };
const bounded = (obj) => { for (const [key,value] of Object.entries(obj)) if (typeof value === 'string' && value.length > LIMITS.field) throw new PublicError('PAYLOAD_TOO_LARGE', `Field too large: ${key}`, 413); };
export function validateDecision(body) { required(body,['decision_id','project','context','why','objective','execution','acceptance']); bounded(body); if (!/^[A-Za-z0-9._:-]{1,128}$/.test(body.decision_id)) throw new PublicError('VALIDATION_ERROR','Invalid decision_id'); return body; }
export function validateTaskId(value) { if (typeof value !== 'string' || !/^[A-Za-z0-9._:-]{1,256}$/.test(value)) throw new PublicError('VALIDATION_ERROR','Invalid task_id'); return value; }
export function validateMessage(body) { required(body,['content']); if (body.content.length > LIMITS.message) throw new PublicError('PAYLOAD_TOO_LARGE','Message too large',413); return body; }
export function parseJson(raw) { try { return JSON.parse(raw.toString('utf8')); } catch { throw new PublicError('INVALID_JSON','Invalid JSON body'); } }
