import {DatabaseSync} from 'node:sqlite';
import {readFileSync, readdirSync, mkdirSync} from 'node:fs';
import {dirname, join} from 'node:path';
import crypto from 'node:crypto';
import {STATES, assertTransition} from './state-machine.mjs';

const now = () => Math.floor(Date.now() / 1000);
const json = value => JSON.stringify(value ?? {});
const hash = value => crypto.createHash('sha256').update(typeof value === 'string' ? value : json(value)).digest('hex');
const safe = value => {
  const text = typeof value === 'string' ? value : json(value);
  return text
    .replace(/("?(?:api[_-]?key|authorization|token|password|secret|cookie)"?\s*:\s*)"[^"]*"/gi, '$1"[REDACTED]"')
    .replace(/(api[_-]?key|authorization|token|password|secret|cookie)\s*[:=]\s*[^,}\s]+/gi, '$1:[REDACTED]');
};

export class BridgeStore {
  constructor(file = process.env.BRIDGE_DB_PATH || join(process.cwd(), 'data', 'bridge.sqlite')) {
    mkdirSync(dirname(file), {recursive:true});
    this.db = new DatabaseSync(file);
    this.db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');
    this.migrate();
    this.recoverAfterRestart();
  }
  migrate() {
    this.db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
    const applied = new Set(this.db.prepare('SELECT version FROM schema_migrations').all().map(r => r.version));
    const migrationDir = new URL('../migrations/', import.meta.url);
    for (const file of readdirSync(migrationDir).filter(f => /^\d+_.+\.sql$/.test(f)).sort()) {
      const version = Number(file.split('_',1)[0]);
      if (applied.has(version)) continue;
      this.db.exec(readFileSync(new URL(file, migrationDir), 'utf8'));
      this.db.prepare('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)').run(version, now());
    }
  }
  close() { this.db.close(); }
  recoverAfterRestart() {
    const t=now();
    this.db.prepare("UPDATE external_effects SET status='EXTERNAL_EFFECT_UNKNOWN',updated_at=? WHERE status='IN_FLIGHT'").run(t);
    this.db.prepare("UPDATE dispatch_claims SET status='RECONCILIATION_REQUIRED',updated_at=? WHERE status='CLAIMED'").run(t);
    this.db.prepare("UPDATE review_claims SET status='RECOVERY_REQUIRED',updated_at=? WHERE status='CLAIMED'").run(t);
  }
  transaction(fn) { this.db.exec('BEGIN IMMEDIATE'); try { const out = fn(); this.db.exec('COMMIT'); return out; } catch (e) { this.db.exec('ROLLBACK'); throw e; } }
  audit({correlationId, actorType, actorSubject, action, objectType, objectId, decisionId=null, before=null, after=null, metadata={}}) {
    this.db.prepare(`INSERT INTO audit_log(correlation_id,actor_type,actor_subject,action,object_type,object_id,decision_id,before_hash,after_hash,metadata_redacted_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(
      correlationId, actorType, actorSubject, action, objectType, objectId, decisionId, before ? hash(before) : null, after ? hash(after) : null, safe(metadata), now());
  }
  createDecision(input, correlationId) {
    const row = {...input, owner_subject: input.owner_subject || 'yvan', state: STATES.CREATED, policy_version: input.policy_version || 'v0.2a.1', preserve: input.preserve || '', do_not_touch: input.do_not_touch || '', validation: input.validation || '', created_at: now()};
    this.db.prepare(`INSERT INTO decisions(id,owner_subject,project,context,why,objective,execution,preserve,do_not_touch,acceptance,validation,policy_version,state,created_at) VALUES (@decision_id,@owner_subject,@project,@context,@why,@objective,@execution,@preserve,@do_not_touch,@acceptance,@validation,@policy_version,@state,@created_at)`).run(row);
    this.audit({correlationId, actorType:'human', actorSubject:row.owner_subject, action:'decision.created', objectType:'decision', objectId:row.decision_id, decisionId:row.decision_id, after:row});
    return this.getDecision(row.decision_id);
  }
  getDecision(id) { return this.db.prepare('SELECT * FROM decisions WHERE id=?').get(id); }
  ensureAutonomy(decisionId) { const t=now(); this.db.prepare('INSERT OR IGNORE INTO autonomy_controls(decision_id,updated_at) VALUES (?,?)').run(decisionId,t); this.db.prepare('INSERT OR IGNORE INTO autonomy_counters(decision_id,elapsed_started_at,updated_at) VALUES (?,?,?)').run(decisionId,t,t); }
  getAutonomyControl(decisionId) { this.ensureAutonomy(decisionId); return this.db.prepare('SELECT * FROM autonomy_controls WHERE decision_id=?').get(decisionId); }
  getAutonomyCounters(decisionId) { this.ensureAutonomy(decisionId); return this.db.prepare('SELECT * FROM autonomy_counters WHERE decision_id=?').get(decisionId); }
  setKillState(decisionId,killState,{actor='system',reason='operator control'}={}) { this.ensureAutonomy(decisionId); const before=this.getAutonomyControl(decisionId); this.db.prepare('UPDATE autonomy_controls SET kill_state=?,updated_at=? WHERE decision_id=?').run(killState,now(),decisionId); this.audit({correlationId:`kill-${now()}-${decisionId}`,actorType:'control',actorSubject:actor,action:'autonomy.kill_state.changed',objectType:'decision',objectId:decisionId,decisionId,before,after:{...before,kill_state:killState},metadata:{reason}}); return this.getAutonomyControl(decisionId); }
  incrementAutonomyCounter(decisionId,kind='external_call',usage={}) { const c=this.getAutonomyCounters(decisionId); const old=JSON.parse(c.usage_json||'{}'); const usageJson={...old,tokens:(Number(old.tokens)||0)+(Number(usage.tokens)||0),cost:(Number(old.cost)||0)+(Number(usage.cost)||0)}; this.db.prepare('UPDATE autonomy_counters SET cycles=?,corrections=?,external_calls=?,retries=?,usage_json=?,updated_at=? WHERE decision_id=?').run(c.cycles+(kind==='cycle'?1:0),c.corrections+(kind==='correction'?1:0),c.external_calls+(kind==='external_call'?1:0),c.retries+(kind==='retry'?1:0),json(usageJson),now(),decisionId); return this.getAutonomyCounters(decisionId); }
  accountExternalCall(decisionId) { return this.incrementAutonomyCounter(decisionId,'external_call'); }
  accumulateUsage(decisionId,usage={}) { return this.incrementAutonomyCounter(decisionId,'usage',usage); }
  observeAutonomyProgress(decisionId,{actionHash=null,resultHash=null,failed=false}={}) { const c=this.getAutonomyCounters(decisionId); const repeated=actionHash&&actionHash===c.last_action_hash?c.repeated_action_count+1:0; const stagnant=resultHash&&resultHash===c.last_result_hash?c.stagnant_result_count+1:0; this.db.prepare('UPDATE autonomy_counters SET consecutive_failures=?,last_action_hash=?,last_result_hash=?,repeated_action_count=?,stagnant_result_count=?,updated_at=? WHERE decision_id=?').run(failed?c.consecutive_failures+1:0,actionHash,resultHash,repeated,stagnant,now(),decisionId); return this.getAutonomyCounters(decisionId); }
  setAutonomyState(decisionId,patch={}) { this.ensureAutonomy(decisionId); const current=this.getAutonomyControl(decisionId); this.db.prepare('UPDATE autonomy_controls SET budget_json=?,loop_json=?,security_state=?,evidence_state=?,updated_at=? WHERE decision_id=?').run(patch.budget_json??current.budget_json,patch.loop_json??current.loop_json,patch.security_state??current.security_state,patch.evidence_state??current.evidence_state,now(),decisionId); return this.getAutonomyControl(decisionId); }
  revokeDecision(decisionId,{actor='yvan',reason='explicit revocation',correlationId=`revoke-${now()}`}={}) { const d=this.getDecision(decisionId); if(!d) throw new Error('Decision not found'); if(d.revoked_at)return d; const t=now(); this.db.prepare('UPDATE decisions SET revoked_at=?,revoked_by=?,revocation_reason=? WHERE id=?').run(t,actor,reason,decisionId); this.audit({correlationId,actorType:'human',actorSubject:actor,action:'decision.revoked',objectType:'decision',objectId:decisionId,decisionId,before:d,after:{...d,revoked_at:t,revoked_by:actor,revocation_reason:reason},metadata:{reason}}); return this.getDecision(decisionId); }
  isRevoked(decisionId) { return Boolean(this.getDecision(decisionId)?.revoked_at); }
  transition(decisionId, to, {taskId=null, reason, actorType='orchestrator', actorSubject='bridge', policyResult='AUTO_ALLOWED', correlationId}) {
    const decision = this.getDecision(decisionId); if (!decision) throw new Error('Decision not found');
    assertTransition(decision.state, to);
    const t = now();
    this.db.prepare('UPDATE decisions SET state=?, authorized_at=CASE WHEN ?=? THEN ? ELSE authorized_at END WHERE id=?').run(to, to, STATES.AUTHORIZED, t, decisionId);
    this.db.prepare('INSERT INTO transitions(decision_id,task_id,from_state,to_state,reason,actor_type,actor_subject,policy_result,correlation_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)').run(decisionId,taskId,decision.state,to,reason,actorType,actorSubject,policyResult,correlationId,t);
    this.audit({correlationId,actorType,actorSubject,action:'state.transition',objectType:'decision',objectId:decisionId,decisionId,before:decision,after:{...decision,state:to},metadata:{reason,policyResult}});
    return this.getDecision(decisionId);
  }
  createTask({decisionId, manusTaskId, status='DISPATCHED', metadata={}}, correlationId) {
    const t=now(); this.db.prepare('INSERT INTO tasks(decision_id,manus_task_id,status,metadata_json,created_at,updated_at) VALUES (?,?,?,?,?,?)').run(decisionId,manusTaskId,status,json(metadata),t,t);
    const task=this.getTaskByManusId(manusTaskId); this.audit({correlationId,actorType:'orchestrator',actorSubject:'bridge',action:'task.created',objectType:'task',objectId:String(task.id),decisionId,after:task}); return task;
  }
  getTask(id) { return this.db.prepare('SELECT * FROM tasks WHERE id=?').get(id); }
  getTaskByManusId(id) { return this.db.prepare('SELECT * FROM tasks WHERE manus_task_id=?').get(id); }
  updateTask(taskId, patch) { const task=this.getTask(taskId); if (!task) throw new Error('Task not found'); const metadata=patch.metadata?{...JSON.parse(task.metadata_json||'{}'),...patch.metadata}:null; this.db.prepare('UPDATE tasks SET status=COALESCE(?,status),last_cursor=COALESCE(?,last_cursor),last_manus_updated_at=COALESCE(?,last_manus_updated_at),metadata_json=COALESCE(?,metadata_json),updated_at=? WHERE id=?').run(patch.status ?? null,patch.last_cursor ?? null,patch.last_manus_updated_at ?? null,metadata?safe(metadata):null,now(),taskId); return this.getTask(taskId); }
  insertEvent({source='manus',eventType,externalEventId=null,payload,signatureTimestamp=null}) {
    const payloadText=JSON.stringify(payload); const payloadSha=hash(payloadText);
    try { const result=this.db.prepare('INSERT INTO events(source,event_type,external_event_id,payload_sha256,raw_payload,signature_timestamp,received_at,processing_status) VALUES (?,?,?,?,?,?,?,?)').run(source,eventType,externalEventId,payloadSha,safe(payloadText),signatureTimestamp,now(),'accepted'); return {duplicate:false,id:Number(result.lastInsertRowid),payloadSha}; }
    catch (e) { if (String(e.message).includes('UNIQUE')) return {duplicate:true,payloadSha}; throw e; }
  }
  markEventProcessed(id, status='processed', errorCode=null) { this.db.prepare('UPDATE events SET processed_at=?,processing_status=?,error_code=? WHERE id=?').run(now(),status,errorCode,id); }
  addMessage({taskId,manusMessageId=null,direction,messageType,content,cursor=null}) { this.db.prepare('INSERT INTO messages(task_id,manus_message_id,direction,message_type,content_redacted,content_hash,cursor,created_at) VALUES (?,?,?,?,?,?,?,?)').run(taskId,manusMessageId,direction,messageType,safe(content),hash(content),cursor,now()); }
  addEscalation({decisionId,taskId=null,category,question,requiredAction}) { this.db.prepare('INSERT INTO escalations(decision_id,task_id,category,question,required_action,status,created_at) VALUES (?,?,?,?,?,?,?)').run(decisionId,taskId,category,question,requiredAction,'open',now()); }
  claimIdempotency(key, operation, payload) {
    if (!key) return {claimed:true};
    const payloadHash=hash(payload); const existing=this.db.prepare('SELECT * FROM idempotency_keys WHERE key=?').get(key);
    if (existing && existing.payload_hash!==payloadHash) throw new Error('IDEMPOTENCY_CONFLICT');
    if (existing) return {claimed:false,result:JSON.parse(existing.result_json)};
    this.db.prepare('INSERT INTO idempotency_keys(key,operation,payload_hash,result_json,created_at) VALUES (?,?,?,?,?)').run(key,operation,payloadHash,'{}',now());
    return {claimed:true};
  }
  finishIdempotency(key, result) { if (key) this.db.prepare('UPDATE idempotency_keys SET result_json=? WHERE key=?').run(json(result),key); }
  createOpenAISession({decisionId,sessionId,agentName='ARKI Architect',status='created',metadata={}}, correlationId) {
    const t=now(); this.db.prepare('INSERT INTO openai_sessions(decision_id,session_id,agent_name,status,metadata_json,created_at,updated_at) VALUES (?,?,?,?,?,?,?)').run(decisionId,sessionId,agentName,status,json(metadata),t,t); const row=this.getOpenAISessionByDecision(decisionId); this.audit({correlationId,actorType:'orchestrator',actorSubject:'bridge',action:'openai.session.created',objectType:'openai_session',objectId:sessionId,decisionId,after:row}); return row;
  }
  getOpenAISessionByDecision(decisionId) { return this.db.prepare('SELECT * FROM openai_sessions WHERE decision_id=?').get(decisionId); }
  getOpenAISession(sessionId) { return this.db.prepare('SELECT * FROM openai_sessions WHERE session_id=?').get(sessionId); }
  updateOpenAISession(sessionId,status,metadata=null) { const row=this.getOpenAISession(sessionId); const merged=metadata?{...JSON.parse(row?.metadata_json||'{}'),...metadata}:null; this.db.prepare('UPDATE openai_sessions SET status=?,metadata_json=COALESCE(?,metadata_json),updated_at=? WHERE session_id=?').run(status,merged?safe(merged):null,now(),sessionId); return this.getOpenAISession(sessionId); }
  insertOpenAIEvent({eventType,externalEventId,sessionId,decisionId,payload}) {
    const payloadText=JSON.stringify(payload); const payloadSha=hash(payloadText); try { const r=this.db.prepare('INSERT INTO openai_events(source,event_type,external_event_id,session_id,decision_id,payload_json,payload_sha256,received_at,processing_status) VALUES (?,?,?,?,?,?,?,?,?)').run('openai',eventType,externalEventId,sessionId,decisionId,safe(payloadText),payloadSha,now(),'accepted'); return {duplicate:false,id:Number(r.lastInsertRowid)}; } catch(e) { if(String(e.message).includes('UNIQUE')) return {duplicate:true}; throw e; }
  }
  markOpenAIEventProcessed(id,status='processed') { this.db.prepare('UPDATE openai_events SET processed_at=?,processing_status=? WHERE id=?').run(now(),status,id); }
  addEvidence(evidence) { this.db.prepare('INSERT INTO evidence(evidence_id,evidence_type,source,producer,timestamp,artifact_hash,provenance,integrity_status,verification_status,decision_id,correlation_id,claim,metadata_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(evidence.evidence_id,evidence.evidence_type,evidence.source,evidence.producer,evidence.timestamp,evidence.artifact_hash,evidence.provenance,evidence.integrity_status,evidence.verification_status,evidence.decision_id,evidence.correlation_id,evidence.claim,json(evidence.metadata)); return this.db.prepare('SELECT * FROM evidence WHERE evidence_id=?').get(evidence.evidence_id); }
  listEvidence(decisionId) { return this.db.prepare('SELECT * FROM evidence WHERE decision_id=? ORDER BY timestamp,evidence_id').all(decisionId); }
  getEvidence(evidenceId) { return this.db.prepare('SELECT * FROM evidence WHERE evidence_id=?').get(evidenceId); }
  markEvidenceVerified(evidenceId,verifierId) { const row=this.getEvidence(evidenceId); if(!row) throw new Error('Evidence not found'); this.db.prepare("UPDATE evidence SET verification_status='INDEPENDENTLY_VERIFIED',metadata_json=? WHERE evidence_id=?").run(json({...JSON.parse(row.metadata_json||'{}'),verified_by:verifierId,verification_act:'bridge-registry'}),evidenceId); this.audit({correlationId:`verify-${evidenceId}`,actorType:'verifier',actorSubject:verifierId,action:'evidence.independently_verified',objectType:'evidence',objectId:evidenceId,decisionId:row.decision_id,metadata:{verification_act:'bridge-registry'}}); }
  claimDispatch(decisionId,intentHash,claimId=crypto.randomUUID()) { const t=now(); try { this.db.prepare('INSERT INTO dispatch_claims(decision_id,claim_id,status,intent_hash,created_at,updated_at) VALUES (?,?,?,?,?,?)').run(decisionId,claimId,'CLAIMED',intentHash,t,t); return {claimed:true,claimId}; } catch(e) { if(String(e.message).includes('UNIQUE')) return {claimed:false,existing:this.db.prepare('SELECT * FROM dispatch_claims WHERE decision_id=?').get(decisionId)}; throw e; } }
  finishDispatchClaim(decisionId,status,{taskId=null}={}) { this.db.prepare('UPDATE dispatch_claims SET status=?,task_id=?,updated_at=? WHERE decision_id=?').run(status,taskId,now(),decisionId); return this.db.prepare('SELECT * FROM dispatch_claims WHERE decision_id=?').get(decisionId); }
  getDispatchClaim(decisionId) { return this.db.prepare('SELECT * FROM dispatch_claims WHERE decision_id=?').get(decisionId); }
  claimReview({reviewId,decisionId,taskId,inputHash}) { const t=now(); try { this.db.prepare('INSERT INTO review_claims(review_id,decision_id,task_id,input_hash,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)').run(reviewId,decisionId,taskId,inputHash,'CLAIMED',t,t); return {claimed:true,reviewId}; } catch(e) { if(String(e.message).includes('UNIQUE')) { const existing=this.db.prepare('SELECT * FROM review_claims WHERE decision_id=? AND input_hash=?').get(decisionId,inputHash); if(['RECOVERY_REQUIRED','FAILED','UNKNOWN'].includes(existing?.status)){const changed=this.db.prepare("UPDATE review_claims SET status='CLAIMED',updated_at=? WHERE review_id=? AND status IN ('RECOVERY_REQUIRED','FAILED','UNKNOWN')").run(t,existing.review_id);if(Number(changed.changes)===1)return {claimed:true,reviewId:existing.review_id,recovered:true};const winner=this.db.prepare('SELECT * FROM review_claims WHERE decision_id=? AND input_hash=?').get(decisionId,inputHash);return {claimed:false,existing:winner};} return {claimed:false,existing}; } throw e; } }
  finishReviewClaim(reviewId,{status,outputHash=null,actionStatus=null}={}) { this.db.prepare('UPDATE review_claims SET status=?,output_hash=?,action_status=?,updated_at=? WHERE review_id=?').run(status,outputHash,actionStatus,now(),reviewId); return this.db.prepare('SELECT * FROM review_claims WHERE review_id=?').get(reviewId); }
  createExternalEffect(effect) { const t=now(); this.db.prepare('INSERT INTO external_effects(effect_id,decision_id,operation,idempotency_key,status,intent_hash,provider,provider_task_id,correlation_id,visibility,reconciliation_state,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(effect.effectId,effect.decisionId,effect.operation,effect.idempotencyKey??null,effect.status,effect.intentHash,effect.provider??null,effect.providerTaskId??null,effect.correlationId??null,effect.visibility??null,effect.reconciliationState??'PENDING',t,t); return this.getExternalEffectById(effect.effectId); }
  getExternalEffectById(id) { return this.db.prepare('SELECT * FROM external_effects WHERE effect_id=?').get(id); }
  getExternalEffect(decisionId,intentHash) { return this.db.prepare('SELECT * FROM external_effects WHERE decision_id=? AND intent_hash=?').get(decisionId,intentHash); }
  getExternalEffectByIdempotency(decisionId,key) { return key?this.db.prepare('SELECT * FROM external_effects WHERE decision_id=? AND idempotency_key=?').get(decisionId,key):null; }
  updateExternalEffect(id,patch) { const current=this.getExternalEffectById(id); if(!current)throw new Error('External effect not found'); this.db.prepare('UPDATE external_effects SET status=?,provider=?,provider_reference=?,provider_task_id=?,correlation_id=?,visibility=?,reconciliation_state=?,result_hash=?,updated_at=? WHERE effect_id=?').run(patch.status??current.status,patch.provider??current.provider,patch.providerReference??current.provider_reference,patch.providerTaskId??current.provider_task_id,patch.correlationId??current.correlation_id,patch.visibility??current.visibility,patch.reconciliationState??current.reconciliation_state,patch.resultHash??current.result_hash,now(),id); return this.getExternalEffectById(id); }
  getExternalEffectByProviderTaskId(decisionId,providerTaskId) { return this.db.prepare('SELECT * FROM external_effects WHERE decision_id=? AND provider=? AND provider_task_id=?').get(decisionId,'manus',providerTaskId); }
  getAudit(decisionId) { return this.db.prepare('SELECT * FROM audit_log WHERE decision_id=? ORDER BY id').all(decisionId); }
  counts() { return Object.fromEntries(['decisions','tasks','events','messages','transitions','escalations','audit_log','idempotency_keys','openai_sessions','openai_events','autonomy_controls','autonomy_counters','evidence','external_effects','dispatch_claims','review_claims'].map(t => [t, this.db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n])); }
}
