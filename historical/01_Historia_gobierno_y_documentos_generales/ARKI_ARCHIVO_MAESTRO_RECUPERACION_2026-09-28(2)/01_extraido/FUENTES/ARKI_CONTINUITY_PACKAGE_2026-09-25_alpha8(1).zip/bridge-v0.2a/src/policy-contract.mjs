import {PublicError} from './schemas.mjs';
export const POLICY_CATEGORIES=Object.freeze(['SCOPE','SECURITY','COST','CREDENTIAL','ARCHITECTURE','PROFESSIONAL','EXECUTION','EVIDENCE','NONE']);
export const OPENAI_CONTRACT_V1='OPENAI_ADAPTER_CONTRACT_V1';
export const OPENAI_CONTRACT_V2='OPENAI_ADAPTER_CONTRACT_V2_COMPAT';
export function validatePolicyFields(output,{contract=OPENAI_CONTRACT_V1}={}){if(typeof output?.reason!=='string')throw new PublicError('OPENAI_SCHEMA_INVALID','reason must be explanatory text',422); if(output.policy_category===undefined||output.policy_category===null)return {...output,policy_category:'NONE',contract}; if(!POLICY_CATEGORIES.includes(output.policy_category))throw new PublicError('POLICY_CATEGORY_INVALID','policy_category is not a valid enum',422); return {...output,contract};}
export function policyAction(output){return {classification:output.classification,policy_category:output.policy_category||'NONE',reason:output.reason};}
export function categoryToPolicy(category){return {SCOPE:'AMBIGUOUS_MATERIAL_SCOPE',SECURITY:'SECURITY_BOUNDARY',CREDENTIAL:'CREDENTIAL_REQUIRED',COST:'COST_OR_RESOURCE_DECISION',ARCHITECTURE:'ARCHITECTURAL_FORK',PROFESSIONAL:'PROFESSIONAL_VALIDATION_REQUIRED',EXECUTION:null,EVIDENCE:null,NONE:null}[category||'NONE']??null;}
