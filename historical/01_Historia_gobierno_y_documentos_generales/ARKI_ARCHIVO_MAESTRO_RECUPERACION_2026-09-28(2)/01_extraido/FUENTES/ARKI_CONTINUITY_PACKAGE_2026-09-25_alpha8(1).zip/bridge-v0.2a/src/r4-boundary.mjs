import {PublicError} from './schemas.mjs';

export const R4_RESULT='ARKI_BRIDGE_R4_EXECUTION_OK';
export const R4_ORDER='EXECUTE_R4_SYNTHETIC';

export function assertR4CreateOptions(options={}){
  if(options.share_visibility!=='private') throw new PublicError('R4_SECURITY_BOUNDARY','R4 requires private Manus visibility',409);
  for(const key of ['connectors','files','enable_skills','force_skills']) if(!Array.isArray(options[key]??[])) throw new PublicError('R4_SCHEMA_INVALID',`${key} must be an array`,422);
  if((options.connectors??[]).length||(options.files??[]).length) throw new PublicError('R4_EXTERNAL_SCOPE','R4 synthetic task cannot use connectors or files',409);
}

export function r4PromptBoundary(){return `Do not use connectors, files, browser tools, external services or external actions. Do not request confirmation or permission. Do not wait for input; complete this task and stop after the exact response. Return exactly: ${R4_RESULT}`;}

export function classifyR4Observation(detail={},messages=[]){
  const providerText=messages.map(m=>[m?.assistant_message?.content,m?.error_message?.content,m?.status_update?.brief,m?.status_update?.description,m?.status_update?.status_detail?.waiting_description].filter(Boolean).join(' ')).join(' ');
  const exactResult=providerText.includes(R4_RESULT);
  const waitingStatus=detail?.task?.status==='waiting'||detail?.task?.status==='input_required'||detail?.task?.status==='confirmation_required';
  const waiting=(!exactResult&&waitingStatus)||/confirmation|permission|connector authorization|external action|publication/i.test(providerText);
  const externalAction=/browser|connector|file upload|tool call|navigation|publication/i.test(providerText);
  return {waiting_action_observed:waiting,external_action_observed:externalAction,skills_observed:'UNKNOWN',result:(waiting||externalAction)?'HALT':'ALLOW'};
}
