import {ManusAdapter} from './manus.mjs';
import {providerMode,requireRealProvider} from './provider-config.mjs';

export class ManusRealAdapter extends ManusAdapter {
  constructor({apiKey=null,mode=providerMode(),...options}={}){super({apiKey,mode,...options});this.mode=mode;}
  assertEnabled(){return requireRealProvider('Manus',{mode:this.mode,apiKey:this.apiKey});}
  async request(...args){this.assertEnabled();return super.request(...args);}
}
