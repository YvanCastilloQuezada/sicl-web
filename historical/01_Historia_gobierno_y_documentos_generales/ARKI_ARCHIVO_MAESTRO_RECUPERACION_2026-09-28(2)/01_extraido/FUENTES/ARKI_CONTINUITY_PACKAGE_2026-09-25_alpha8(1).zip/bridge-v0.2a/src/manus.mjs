import {PublicError} from './schemas.mjs';
import {assertR3CreateOptions,assertR3FollowUp,classifyR3Observation} from './r3-boundary.mjs';
const BASE='https://api.manus.ai/v2';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const safeProviderMessage=value=>{const text=String(value??'');return /bearer\s|api[_-]?key|authorization|token|secret|password|cookie|sk-[a-z0-9]/i.test(text)?'REDACTED':text.length<=200?text:'REDACTED';};
const attachProviderDiagnostics=(error,{status,data}={})=>{error.http_status=status??null;error.provider_error_code=data?.error?.code??null;error.provider_request_id=data?.request_id??null;error.provider_error_message=safeProviderMessage(data?.error?.message);return error;};
export class ManusAdapter {
  constructor({apiKey=null, base=BASE, fetchImpl=fetch, timeoutMs=5000, maxRetries=2}={}) { this.apiKey=apiKey; this.base=base; this.fetch=fetchImpl; this.timeoutMs=timeoutMs; this.maxRetries=maxRetries; }
  async request(path,{method='GET',body,query,retryNotFound=false}={}) {
    if (!this.apiKey) throw new PublicError('MANUS_NOT_CONFIGURED','Manus API key is not configured',503);
    const url=new URL(this.base+path); if(query) for(const [k,v] of Object.entries(query)) if(v!==undefined&&v!==null) url.searchParams.set(k,String(v));
    let retryCount=0;
    for(let attempt=0;;attempt++) {
      const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),this.timeoutMs);
      try {
        const res=await this.fetch(url,{method,signal:controller.signal,headers:{'x-manus-api-key':this.apiKey,...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
        const data=await res.json().catch(()=>({}));
        if(res.ok && data.ok!==false) return {...data,retry_count:retryCount};
        if(retryNotFound && res.status===404 && attempt<1){ await sleep(1000); continue; }
        const retryable=res.status===429 || res.status>=500;
        if(retryable && attempt<this.maxRetries){ retryCount++; await sleep(25*2**attempt); continue; }
        throw attachProviderDiagnostics(new PublicError(retryable?'MANUS_TRANSIENT_ERROR':'MANUS_API_ERROR',`Manus API request failed (${res.status})`,retryable?503:502,retryable),{status:res.status,data});
      } catch(e) {
        if(e instanceof PublicError && !e.retryable) throw e;
        if(attempt<this.maxRetries){ retryCount++; await sleep(25*2**attempt); continue; }
        e.retry_count=retryCount;
        const unavailable=attachProviderDiagnostics(new PublicError('MANUS_TIMEOUT_OR_NETWORK','Manus API unavailable',504,true),{status:e.http_status,data:{request_id:e.provider_request_id,error:{code:e.provider_error_code,message:e.provider_error_message}}}); unavailable.retry_count=retryCount; throw unavailable;
      } finally { clearTimeout(timer); }
    }
  }
  async createTask(content, options={}) {
    if(options.r3) assertR3CreateOptions(options);
    const shareVisibility=options.share_visibility??'private';
    if(shareVisibility!=='private') throw new PublicError('MANUS_SECURITY_BOUNDARY','Only private Manus tasks are allowed by the Bridge adapter',409);
    const capabilities=['connectors','enable_skills','force_skills'];
    for(const key of capabilities) if(!Array.isArray(options[key]??[])) throw new PublicError('MANUS_SCHEMA_INVALID',`${key} must be an array`,422);
    const message={content,connectors:options.connectors??[],enable_skills:options.enable_skills??[],force_skills:options.force_skills??[]};
    const body={message,share_visibility:'private'};
    if(options.project_id) body.project_id=options.project_id;
    const result=await this.request('/task.create',{method:'POST',body});
    if(result.share_visibility!=='private'||Object.prototype.hasOwnProperty.call(result,'share_url')) throw new PublicError('MANUS_SECURITY_BOUNDARY','Manus task visibility response was not private',409);
    return result;
  }
  sendMessage(task_id,content,options={}) { if(options.r3) assertR3FollowUp('task.sendMessage'); return this.request('/task.sendMessage',{method:'POST',body:{task_id,message:{content}}}); }
  detail(task_id) { return this.request('/task.detail',{query:{task_id},retryNotFound:true}); }
  listMessages(task_id,{limit=50,cursor,order='desc'}={}) { return this.request('/task.listMessages',{query:{task_id,limit,cursor,order}}); }
  createWebhook(url) { return this.request('/webhook.create',{method:'POST',body:{url}}); }
  webhookPublicKey() { return this.request('/webhook.publicKey'); }
}
