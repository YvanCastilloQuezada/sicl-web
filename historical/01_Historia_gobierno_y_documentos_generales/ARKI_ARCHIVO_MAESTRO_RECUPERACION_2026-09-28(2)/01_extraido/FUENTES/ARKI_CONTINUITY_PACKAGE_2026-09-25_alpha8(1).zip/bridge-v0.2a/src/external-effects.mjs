import crypto from 'node:crypto';
import {PublicError} from './schemas.mjs';
import {canonicalHash} from './autonomy-control.mjs';
export const EFFECT_STATUS=Object.freeze({INTENT_PERSISTED:'INTENT_PERSISTED',IN_FLIGHT:'IN_FLIGHT',SUCCEEDED:'SUCCEEDED',FAILED:'FAILED',EXTERNAL_EFFECT_UNKNOWN:'EXTERNAL_EFFECT_UNKNOWN',RECONCILIATION_REQUIRED:'RECONCILIATION_REQUIRED'});
export class ExternalEffectCoordinator {
  constructor({store,control}={}){this.store=store;this.control=control;}
  begin({decisionId,operation,payload,idempotencyKey=null}){const check=this.control?.before(decisionId,'external_call',{action:{operation,payload}}); if(check&&check.result!=='ALLOW')return check; const intentHash=canonicalHash({operation,payload}); const existing=this.store.getExternalEffect(decisionId,intentHash); if(existing)return existing; const keyed=this.store.getExternalEffectByIdempotency(decisionId,idempotencyKey); if(keyed&&keyed.intent_hash!==intentHash)throw new PublicError('IDEMPOTENCY_CONFLICT','Idempotency key reused with different external intent',409); const effect=this.store.createExternalEffect({effectId:crypto.randomUUID(),decisionId,operation,idempotencyKey,intentHash,status:EFFECT_STATUS.INTENT_PERSISTED}); return effect;}
  markInFlight(effectId){return this.store.updateExternalEffect(effectId,{status:EFFECT_STATUS.IN_FLIGHT});}
  recordProviderIdentity(effectId,{provider='manus',providerTaskId,correlationId=null,visibility='private'}={}){if(!providerTaskId)throw new PublicError('PROVIDER_ID_MISSING','Provider task ID is required before reconciliation',502);return this.store.updateExternalEffect(effectId,{provider,providerTaskId,providerReference:providerTaskId,correlationId,visibility,reconciliationState:'IDENTITY_PERSISTED'});}
  markSuccess(effectId,providerReference,result){return this.store.updateExternalEffect(effectId,{status:EFFECT_STATUS.SUCCEEDED,providerTaskId:providerReference,providerReference,resultHash:canonicalHash(result),reconciliationState:'RECONCILIATION_READY'});}
  markFailure(effectId,error){return this.store.updateExternalEffect(effectId,{status:EFFECT_STATUS.FAILED,resultHash:canonicalHash({error:String(error)})});}
  markUnknown(effectId,reason){return this.store.updateExternalEffect(effectId,{status:EFFECT_STATUS.EXTERNAL_EFFECT_UNKNOWN,resultHash:canonicalHash({reason})});}
  assertRedispatchSafe(effect){if(!effect)return; if([EFFECT_STATUS.IN_FLIGHT,EFFECT_STATUS.EXTERNAL_EFFECT_UNKNOWN,EFFECT_STATUS.RECONCILIATION_REQUIRED].includes(effect.status))throw new PublicError('EXTERNAL_EFFECT_UNKNOWN','External effect must be reconciled before redispatch',409);}
}
