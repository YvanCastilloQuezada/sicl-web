# ARKI Agent Bridge v0.2C.2 — Gate 2 Closeout Report

**Orden:** `AB-V02C2-GATE2-CLOSEOUT-001`  
**Baseline:** v0.2C.1 / `0.2.0-alpha.4`  
**Versión resultante:** `0.2.0-alpha.5`  
**Resultado del Gate 2:** cierre de los required fixes deterministas.  
**Estado de ejecución:** Mock E2E, OpenAI real, Manus real, credenciales, deployment y webhook público no ejecutados.

## Conclusión

Los gaps parciales F-03, F-06 y F-07, junto con RT-G2-NEW-01 a RT-G2-NEW-05, fueron corregidos dentro de la arquitectura existente. La regresión conserva los **55 tests previos** y añade **13 tests Gate 2**. El resultado final es **68 tests, 68 PASS, 0 FAIL, 0 skipped**.

La evidencia de runtime es exclusivamente local y fake. Por esa razón, este reporte no utiliza `E2E_VERIFIED` y no afirma exactly-once, attestation real de Manus ni verdad criptográfica del proveedor.

## Test accounting

| Grupo | Tests | Pass | Fail | Skipped |
|---|---:|---:|---:|---:|
| Baseline v0.2C.1 | 55 | 55 | 0 | 0 |
| Nuevos Gate 2 | 13 | 13 | 0 | 0 |
| Total | 68 | 68 | 0 | 0 |

Comandos ejecutados:

```bash
npm test
node --check src/*.mjs tests/*.mjs
```

## Findings closeout

### F-03 / RT-G2-NEW-02 — IN_FLIGHT recovery

**ROOT CAUSE.** Un proceso podía terminar después de `INTENT_PERSISTED → IN_FLIGHT`, dejando el efecto durable en `IN_FLIGHT` sin una decisión segura después del reinicio.

**CODE PATH.** `BridgeStore` ejecuta `recoverAfterRestart()` después de migrations. La función convierte `external_effects.status = IN_FLIGHT` a `EXTERNAL_EFFECT_UNKNOWN`. `ExternalEffectCoordinator.assertRedispatchSafe()` bloquea `IN_FLIGHT`, `EXTERNAL_EFFECT_UNKNOWN` y `RECONCILIATION_REQUIRED`.

**FIX.** El recovery es fail-closed. No asume `SUCCEEDED`, `FAILED` ni exactly-once. Los dispatch claims `CLAIMED` pasan a `RECONCILIATION_REQUIRED` y los review claims `CLAIMED` pasan a `RECOVERY_REQUIRED`.

**DIRECT TEST.** `RT-G2-NEW-02 restart converts IN_FLIGHT to UNKNOWN and blocks redispatch`.

**COMPOSITION TEST.** `F-03 local persistence failure after provider success becomes UNKNOWN and blocks blind redispatch` cubre también el caso de éxito remoto con persistencia local fallida.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** para recovery local y bloqueo de redispatch.

**RESIDUAL RISK.** Determinar si el proveedor aceptó o no el efecto requiere reconciliación específica del proveedor. No se declara exactly-once.

### F-06 — Retries reales

**ROOT CAUSE.** `max_retries` existía como contador, pero no estaba alimentado por repeticiones reales del request de Manus.

**CODE PATH.** `ManusAdapter.request()` incrementa `retryCount` solo cuando repite el mismo request por respuesta retryable o error de red. `consumeRetryCount()` entrega ese número una sola vez. `Orchestrator.recordManusOutcome()` registra cada retry, alimenta `retries` y llama a `LoopGovernor.observe()` con la acción y resultado reales.

**FIX.** Se separan `external_call`, `retry`, `failure`, `cycle`, `progress` y `correction`. Un éxito después de retry limpia `consecutive_failures`; una falla real incrementa ese contador. El retry budget bloquea operaciones posteriores cuando se alcanza el límite.

**DIRECT TESTS.** `F-06 real ManusAdapter retries are counted separately from external calls`, `F-06 dispatch integrates retry count, failure reset and restart preservation`.

**COMPOSITION TESTS.** `F-06 retry budget blocks a later external operation after real retry consumption`, `F-06 repeated failed dispatch feeds consecutive_failures and effective HALT`, y los tests existentes de repeated action/stagnant result.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** para retries fake locales y contadores persistidos.

**RESIDUAL RISK.** Los límites y backoff de producción todavía requieren validación operativa con el proveedor real. No se ejecutó Manus real.

### F-07 — Eliminación de autoverificación nominal

**ROOT CAUSE.** El contrato de evidencia rechazaba algunos productores, pero permitía que el estado `INDEPENDENTLY_VERIFIED` llegara como metadata de entrada si el formato era válido.

**CODE PATH.** `validateEvidence()` rechaza cualquier entrada que ya declare `INDEPENDENTLY_VERIFIED`. `VerifierRegistry.verify()` es el único camino implementado que llama a `store.markEvidenceVerified()`.

**FIX.** `producer`, `verification_status` y metadata no conceden autoridad. La transición solo ocurre mediante identidad registrada en `VerifierRegistry` y acto estructural del Bridge.

**DIRECT TEST.** `F-07 producer cannot fabricate INDEPENDENTLY_VERIFIED without registry act`.

**COMPOSITION TEST.** `F-07 producer cannot self-assign verification; Bridge registry performs act` comprueba evidencia persistida, rechazo del producer y verificación posterior mediante registry autorizado.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** para la autoridad estructural local.

**RESIDUAL RISK.** El registry actual es una autoridad local del Bridge. No es attestation criptográfica de Manus, PKI ni prueba de verdad externa.

### RT-G2-NEW-01 — Call count separado de usage

**ROOT CAUSE.** La respuesta de provider podía pasar por `incrementAutonomyCounter(..., 'external_call', usage)`, sumando usage y llamada con una responsabilidad ambigua.

**CODE PATH.** `BudgetEnforcer.accountExternalCall()` incrementa únicamente `external_calls`. `BudgetEnforcer.accumulateUsage()` incrementa únicamente `usage_json`. `reviewWithArchitect()` cuenta `createSession` y `review` una vez cada uno y acumula tokens/cost sin una tercera llamada.

**DIRECT TESTS.** `RT-G2-NEW-01 new session counts create plus review, usage adds zero calls` y `RT-G2-NEW-01 existing session counts one review plus independent usage`.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** para ambos caminos de sesión.

**RESIDUAL RISK.** La semántica de usage depende del esquema que entregue el provider real. No se inventan precios.

### RT-G2-NEW-03 — Review claim recovery

**ROOT CAUSE.** Una excepción después de crear `review_claim` podía dejarlo en `CLAIMED`, y la restricción unique impedía recuperar el input.

**CODE PATH.** `reviewWithArchitect()` cierra claims en `BLOCKED`, `FAILED` o `CONSUMED`, incluso si falla el procesamiento del output o `applyArchitectOutput()`. `BridgeStore.recoverAfterRestart()` convierte claims activos a `RECOVERY_REQUIRED`; `claimReview()` puede reabrirlos de forma explícita.

**DIRECT TEST.** `RT-G2-NEW-03 review claim exception is closed and recoverable after restart` cubre exception durante apply y retry.

**COMPOSITION TEST.** `RT-G2-NEW-03 claimed review is recovered after actual store restart` comprueba `CLAIMED → RECOVERY_REQUIRED → CLAIMED` en una base reabierta.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** para los estados de recovery locales.

**RESIDUAL RISK.** Un resultado OpenAI desconocido no se convierte automáticamente en éxito; requiere nueva revisión o reconciliación.

### RT-G2-NEW-04 — Budget kind de transiciones internas

**ROOT CAUSE.** La evaluación de control interno usaba por defecto el budget de `external_call`.

**CODE PATH.** `autonomyEnvelope()` usa `budgetKind = control` por defecto. `LoopGovernor` evalúa el límite de `external_calls` solo para `kind = external_call`. Los coordinadores externos pasan explícitamente `external_call` o `correction`.

**DIRECT TEST.** `RT-G2-NEW-04 internal transition is governable without consuming external-call budget`.

**COMPOSITION TEST.** El mismo test demuestra que la transición interna permanece gobernable mientras una nueva llamada externa es bloqueada en el límite.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED**.

**RESIDUAL RISK.** Kill, revocation, security, evidence y loop controls siguen precediendo al resultado; no se verificaron con provider real.

### RT-G2-NEW-05 — Revocación por decisión frente a kill global

**ROOT CAUSE.** `revokeDecision()` llamaba un método que podía escribir el archivo out-of-band, mezclando estado de D1 con el kill global.

**CODE PATH.** `revokeDecision()` usa `KillSwitch.setDecision()` y solo afecta la fila de esa decisión. `KillSwitch.setGlobal()` es el camino explícito para el archivo OOB. `KillSwitch.state()` conserva precedencia global cuando el archivo existe.

**DIRECT TEST.** `RT-G2-NEW-05 revocation is per decision while global OOB kill applies to all`.

**COMPOSITION TEST.** D1 revocada produce HALT, D2 permanece ALLOW; después del global OOB HARD HALT ambas producen HALT.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** en dos decisiones locales.

**RESIDUAL RISK.** La operación global requiere una ruta de kill configurada. No se desplegó un operador externo.

### Revocation mid-fetch

**ROOT CAUSE.** El riesgo era aplicar el resultado Manus después de que una decisión fuera revocada durante un `await`.

**CODE PATH.** `reconcile()` consulta nuevamente `isRevoked()` después de completar la obtención de detalle y mensajes, antes de evidence, LoopGovernor y cualquier transición.

**DIRECT TEST / COMPOSITION TEST.** `RT-G2-NEW-05 revocation during detail await prevents late transition` revoca durante el await y confirma que no se produce transición; el dato tardío solo queda representado por el retorno/auditoría permitido.

**RESULT.** **CODE_EVIDENCE + RUNTIME_EVIDENCE + IMPLEMENTED + VERIFIED** para el escenario mid-fetch fake.

**RESIDUAL RISK.** No se ejecutó una condición de carrera multiproceso ni cancelación remota de Manus.

## No-touch and security gate

Se preservaron estas restricciones:

- ARKI modifications: **0**.
- Real OpenAI calls: **0**.
- Real Manus calls: **0**.
- Real credentials: **0**.
- Production deploy: **0**.
- Public webhook: **0**.
- Mock E2E durante esta orden: **0**.
- Real E2E: **0**.
- Manus attestation inventado: **0**.
- PKI ficticia: **0**.

## Readiness

| Gate | Result | Meaning |
|---|---|---|
| READY FOR CHATGPT VERIFICATION | YES | Source, tests, report, bundle y hashes quedan disponibles. |
| READY FOR TARGETED RED TEAM CONFIRMATION | YES | F-03, F-06, F-07 y RT-G2-NEW-01…05 tienen pruebas directas y compositivas. |
| READY FOR MOCK E2E | YES | Declaración técnica de implementación; no es autorización para ejecutarlo. |
| READY FOR REAL CREDENTIALS | NO | Credenciales y conexiones reales siguen fuera de esta orden. |
| READY FOR REAL E2E | NO | Manus/OpenAI reales, deployment y webhook público no se ejecutaron. |

## Files changed

- `src/autonomy-control.mjs`
- `src/evidence.mjs`
- `src/external-effects.mjs`
- `src/loop-budget.mjs`
- `src/manus.mjs`
- `src/orchestrator.mjs`
- `src/store.mjs`
- `tests/gate2-closeout.test.mjs`
- `package.json`
- `README.md`
- `V02C2_GATE2_CLOSEOUT_REPORT.md`
- `ARKI_AGENT_BRIDGE_v0.2C2_DEEPSEEK_AUDIT_BUNDLE.md`

No migration file was required: the existing schema already represented the needed recovery states as durable status values.

## References

No external sources were used. The claims above are supported by the source and tests included in the attached bundle.
