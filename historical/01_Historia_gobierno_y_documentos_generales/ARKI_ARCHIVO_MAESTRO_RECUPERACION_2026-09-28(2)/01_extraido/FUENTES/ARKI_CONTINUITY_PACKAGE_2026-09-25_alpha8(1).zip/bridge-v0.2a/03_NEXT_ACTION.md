# Next Action

```text
NEXT_AUTHORIZED_ACTION=ARKI_DEEP_CAPABILITY_RADIOGRAPHY
BLOCKER=NONE
```

The Bridge closeout is complete. The next action is not to modify the Bridge. It is to audit ARKI itself using the priority in `ROADMAP/ARKI_NEXT_ROADMAP.md`.

The ARKI radiography must compare documentation, code, runtime, tests, knowledge, optimization, BIM semantics, and output representation. It must classify every claim by evidence level before implementation is proposed. It must preserve the rule that the Bridge remains external and decoupled.

A new agent must obtain or inspect the official ARKI repository before making product claims. The Bridge package is not a source-of-truth copy of ARKI.

## References

[1]: ROADMAP/ARKI_NEXT_ROADMAP.md "ARKI roadmap"
[2]: GOVERNANCE/CAPABILITY_LEDGER.md "Capability ledger"
