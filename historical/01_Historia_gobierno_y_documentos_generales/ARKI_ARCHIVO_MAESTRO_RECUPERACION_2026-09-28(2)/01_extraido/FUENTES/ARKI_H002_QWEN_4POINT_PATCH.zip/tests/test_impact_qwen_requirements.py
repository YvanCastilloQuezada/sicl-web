from dataclasses import fields
import pytest

from sicl.derivation import (
    DerivationLedger, DerivationRecord, TypedRelation, VersionedRef,
    DerivationValidationError,
)
from sicl.impact import ImpactAnalyzer, ImpactChange, ImpactReport
from sicl.domain import Event


class MemoryStore:
    def __init__(self):
        self.items = []

    def add_event(self, event):
        self.items.append(event)
        return event

    def events(self, project_id=None):
        return [
            x for x in self.items
            if project_id is None or x.project_id == project_id
        ]


def ref(t, i, v, h=None):
    return VersionedRef(t, i, v, h)


def rec(i, out, inputs):
    return DerivationRecord(
        i, out, tuple(inputs), "m", "1",
        tuple(TypedRelation(out, x, "COMPUTED_FROM", "COMPUTATIONAL") for x in inputs),
    )


def one_hop(input_ref):
    store = MemoryStore()
    ledger = DerivationLedger(store)
    area = ref("Area", "A1", 1)
    ledger.record("P", rec("D-A", area, [input_ref]))
    return store, ledger, area


def test_impact_change_contract_has_before_after_and_allowed_change_kind():
    before = ref("Geometry", "G1", 1)
    after = ref("Geometry", "G1", 2)
    change = ImpactChange(before, after, "VERSION_UPGRADED")
    assert change.before == before
    assert change.after == after
    assert change.to_dict()["changeKind"] == "VERSION_UPGRADED"
    assert {"before", "after", "change_kind"} <= {f.name for f in fields(ImpactChange)}
    with pytest.raises(DerivationValidationError):
        ImpactChange(before, after, "NOT_A_CHANGE_KIND")


def test_analyze_change_traverses_before_and_records_change_kind():
    before = ref("Geometry", "G1", 1)
    after = ref("Geometry", "G1", 2)
    store, ledger, area = one_hop(before)
    count_before = len(store.items)

    report = ImpactAnalyzer(ledger).analyze_change(
        "P", ImpactChange(before, after, "VERSION_UPGRADED")
    )

    assert report.changed_ref == before
    assert [x.ref for x in report.impacted] == [area]
    assert report.change_kind == "VERSION_UPGRADED"
    assert report.to_dict()["changeKind"] == "VERSION_UPGRADED"
    assert len(store.items) == count_before


def test_impact_report_always_exposes_graph_coverage_warning():
    changed = ref("Geometry", "G1", 1)
    report = ImpactReport(changed_ref=changed, impacted=())
    assert report.coverageWarning == "GRAPH_MAY_BE_INCOMPLETE"
    assert report.to_dict()["coverageWarning"] == "GRAPH_MAY_BE_INCOMPLETE"


@pytest.mark.parametrize(
    ("before", "after", "expected"),
    [
        (
            ref("Geometry", "G1", 1, "a" * 64),
            ref("Geometry", "G1", 1),
            "IDENTITY_UNCERTAIN",
        ),
        (
            ref("Geometry", "G1", 1),
            ref("Geometry", "G1", 1),
            "IDENTITY_UNVERIFIABLE",
        ),
    ],
)
def test_analyze_change_propagates_h001_identity_uncertainty(before, after, expected):
    store, ledger, area = one_hop(before)
    report = ImpactAnalyzer(ledger).analyze_change(
        "P", ImpactChange(before, after, "CONTENT_CHANGED")
    )
    impacted = next(x for x in report.impacted if x.ref == area)
    assert impacted.identity_status == expected
    assert impacted.to_dict()["identityStatus"] == expected
