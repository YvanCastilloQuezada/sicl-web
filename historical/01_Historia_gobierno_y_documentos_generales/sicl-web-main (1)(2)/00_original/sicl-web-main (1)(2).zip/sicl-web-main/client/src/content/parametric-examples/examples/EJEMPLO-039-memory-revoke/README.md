# Ejemplo 039 · /MEMORY REVOKE

**Comando:** `/MEMORY REVOKE MEM-001`

**Modo:** EXPLORE

Creates a repeatable command-shaped example for learning and traceability.

Este archivo es un ejemplo repetible y trazable; no afirma ejecución contra un Core remoto, Dynamo/Revit, Rhino/Grasshopper ni autoridad humana.
