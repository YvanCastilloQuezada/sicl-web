# ARKI-SOLVER-MAP-001 — Optimization Engine Study

This family study is preserved in the source report `SOLVER_MAP_RESEARCH/optimization-risk.md`. It records candidate tools, licenses, APIs/CLI, headless operation, determinism, testability, validation references, limitations and professional boundaries.

**Status:** research-only; no installation or execution. **Aurora:** not used. **Access date:** 2026-09-24.

See the cited official URLs and unknown register in the source report. Recommendations are candidate selections, not authorization.
