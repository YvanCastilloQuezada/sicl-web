# C30 Foundation

Avatar ARKI is bound to existing WAVE 1 foundations: W1:identity, W1:epistemic, W9:human-authority. This artifact does not claim implementation.