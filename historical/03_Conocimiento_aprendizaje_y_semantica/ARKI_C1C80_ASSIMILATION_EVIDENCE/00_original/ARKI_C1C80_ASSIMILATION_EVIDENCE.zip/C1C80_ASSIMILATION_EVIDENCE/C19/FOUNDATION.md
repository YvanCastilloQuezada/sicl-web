# C19 Foundation

EnergyPlus is bound to existing WAVE 1 foundations: W1:units, W1:evidence, W3:solver-interface. This artifact does not claim implementation.