# ARKI Agent Bridge v0.1 (private/internal)

Temporary, detachable bridge for sending governed ARKI work orders to Manus API v2. It does **not** modify ARKI and contains no credentials.

## Security
- Never commit `MANUS_API_KEY`.
- Manus API keys provide broad account access; keep the key only in an environment variable/secrets manager.
- Webhook signature verification is supported when `MANUS_WEBHOOK_PUBLIC_KEY_PEM` is configured.
- No deploy/publish endpoint is exposed by this bridge.

## Start
1. Copy `.env.example` values into your local secret environment (do not paste the key into source code).
2. `MANUS_API_KEY=... node src/server.mjs`
3. `GET http://localhost:8787/health`

## Send governed task
POST `/manus/tasks` with JSON fields:
`decision_id, project, context, why, objective, execution, preserve, do_not_touch, acceptance, validation`.

## Follow up / inspect
- POST `/manus/tasks/:task_id/messages` body `{ "content": "..." }`
- GET `/manus/tasks/:task_id`

## Webhook
POST `/webhooks/manus`. For real Manus delivery this endpoint must be public HTTPS and registered with Manus. Configure the Manus public key for RSA-SHA256 verification.

## Important v0.1 boundary
This bridge automates **ChatGPT-authored order → Manus task → result retrieval/webhook reception**. It does not make this specific ChatGPT conversation wake up from an external webhook. Fully unattended ChatGPT↔Manus cycles require a persistent orchestrator/agent runtime on the ChatGPT/OpenAI side. That is phase v0.2, not silently claimed here.
