export function buildOrder(o) {
  const req = ['decision_id','project','context','why','objective','execution','acceptance'];
  for (const k of req) if (!o[k]) throw new Error(`Missing ${k}`);
  return `ARKI INTERNAL BRIDGE\nDECISION_ID: ${o.decision_id}\nPROJECT: ${o.project}\n\nCONTEXT\n${o.context}\n\nWHY\n${o.why}\n\nOBJECTIVE\n${o.objective}\n\nEXECUTION\n${o.execution}\n\nPRESERVE\n${o.preserve || 'Only what is outside the authorized scope.'}\n\nDO NOT TOUCH\n${o.do_not_touch || 'No scope expansion.'}\n\nACCEPTANCE CRITERIA\n${o.acceptance}\n\nVALIDATION\n${o.validation || 'Return concrete evidence, tests and blockers.'}\n\nDECISION LOCK\nExecute within this scope without reconfirming the same owner decision. Stop only for a materially new destructive, security, data, architectural, or out-of-scope decision.\n\nREPORT\nReturn: STATUS, ROOT_CAUSE/RESULT, FILES_CHANGED, TESTS, EVIDENCE, BLOCKERS, HUMAN_DECISION_REQUIRED.`;
}
