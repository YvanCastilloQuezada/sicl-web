import http from 'node:http';
import {ManusClient} from './manus.mjs';
import {buildOrder} from './protocol.mjs';
import {verifyManusWebhook} from './webhook-security.mjs';

const port = Number(process.env.BRIDGE_PORT || 8787);
const json = (res, code, data) => { res.writeHead(code, {'content-type':'application/json'}); res.end(JSON.stringify(data,null,2)); };
const read = req => new Promise((resolve,reject)=>{let b=[];req.on('data',c=>b.push(c));req.on('end',()=>resolve(Buffer.concat(b)));req.on('error',reject)});

http.createServer(async (req,res)=>{
  try {
    if (req.method==='GET' && req.url==='/health') return json(res,200,{ok:true,bridge:'ARKI Agent Bridge',version:'0.1.0'});
    if (req.method==='POST' && req.url==='/manus/tasks') {
      const body=JSON.parse((await read(req)).toString('utf8'));
      const client=new ManusClient();
      return json(res,200,await client.createTask(buildOrder(body), body));
    }
    if (req.method==='POST' && req.url?.startsWith('/manus/tasks/') && req.url.endsWith('/messages')) {
      const taskId=req.url.split('/')[3]; const body=JSON.parse((await read(req)).toString('utf8'));
      return json(res,200,await new ManusClient().sendMessage(taskId, body.content));
    }
    if (req.method==='GET' && req.url?.startsWith('/manus/tasks/')) {
      const taskId=req.url.split('/')[3]; const c=new ManusClient();
      return json(res,200,{detail:await c.detail(taskId),messages:await c.listMessages(taskId)});
    }
    if (req.method==='POST' && req.url==='/webhooks/manus') {
      const raw=await read(req); const publicKey=process.env.MANUS_WEBHOOK_PUBLIC_KEY_PEM;
      if (publicKey) {
        const external=process.env.MANUS_WEBHOOK_PUBLIC_URL || `http://${req.headers.host}${req.url}`;
        const ok=verifyManusWebhook({rawBody:raw,url:external,timestamp:req.headers['x-webhook-timestamp'],signature:req.headers['x-webhook-signature'],publicKeyPem:publicKey});
        if (!ok) return json(res,401,{ok:false,error:'invalid webhook signature'});
      }
      const event=JSON.parse(raw.toString('utf8'));
      // v0.1 deliberately records/returns the event; autonomous ChatGPT continuation requires a persistent orchestrator integration.
      return json(res,200,{ok:true,received:event.event_type,task_id:event?.task_detail?.task_id,stop_reason:event?.task_detail?.stop_reason});
    }
    json(res,404,{ok:false,error:'not found'});
  } catch(e) { json(res,500,{ok:false,error:e.message}); }
}).listen(port,()=>console.log(`ARKI Agent Bridge v0.1 listening on ${port}`));
