const BASE = 'https://api.manus.ai/v2';

export class ManusClient {
  constructor(apiKey = process.env.MANUS_API_KEY) {
    if (!apiKey) throw new Error('MANUS_API_KEY is required');
    this.apiKey = apiKey;
  }
  async request(path, {method='GET', body, query}={}) {
    const url = new URL(BASE + path);
    if (query) for (const [k,v] of Object.entries(query)) if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
    const res = await fetch(url, {
      method,
      headers: {'x-manus-api-key': this.apiKey, ...(body ? {'content-type':'application/json'} : {})},
      body: body ? JSON.stringify(body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw new Error(`Manus API ${res.status}: ${data?.error?.message || JSON.stringify(data)}`);
    return data;
  }
  createTask(content, options={}) {
    const message = {content};
    if (options.connectors) message.connectors = options.connectors;
    if (options.enable_skills) message.enable_skills = options.enable_skills;
    if (options.force_skills) message.force_skills = options.force_skills;
    const body = {message};
    if (options.project_id) body.project_id = options.project_id;
    return this.request('/task.create', {method:'POST', body});
  }
  sendMessage(task_id, content) { return this.request('/task.sendMessage', {method:'POST', body:{task_id, message:{content}}}); }
  listMessages(task_id, limit=50) { return this.request('/task.listMessages', {query:{task_id, limit}}); }
  detail(task_id) { return this.request('/task.detail', {query:{task_id}}); }
  createWebhook(url) { return this.request('/webhook.create', {method:'POST', body:{url}}); }
  webhookPublicKey() { return this.request('/webhook.publicKey'); }
}
