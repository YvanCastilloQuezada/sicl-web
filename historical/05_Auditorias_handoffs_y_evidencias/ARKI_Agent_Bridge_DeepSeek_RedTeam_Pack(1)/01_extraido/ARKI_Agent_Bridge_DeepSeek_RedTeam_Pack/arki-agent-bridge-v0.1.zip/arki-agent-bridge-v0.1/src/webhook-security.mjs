import crypto from 'node:crypto';
export function verifyManusWebhook({rawBody, url, timestamp, signature, publicKeyPem, now=Date.now()}) {
  if (!timestamp || !signature || !publicKeyPem) return false;
  const ts = Number(timestamp);
  if (!Number.isFinite(ts) || Math.abs(Math.floor(now/1000)-ts) > 300) return false;
  const hash = crypto.createHash('sha256').update(rawBody).digest('hex');
  const signed = `${timestamp}.${url}.${hash}`;
  return crypto.verify('RSA-SHA256', Buffer.from(signed), publicKeyPem, Buffer.from(signature, 'base64'));
}
