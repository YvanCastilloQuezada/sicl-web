import test from 'node:test'; import assert from 'node:assert/strict'; import {buildOrder} from '../src/protocol.mjs';
test('buildOrder includes decision lock and why',()=>{const s=buildOrder({decision_id:'D1',project:'ARKI',context:'c',why:'w',objective:'o',execution:'e',acceptance:'a'});assert.match(s,/DECISION LOCK/);assert.match(s,/WHY\nw/);});
