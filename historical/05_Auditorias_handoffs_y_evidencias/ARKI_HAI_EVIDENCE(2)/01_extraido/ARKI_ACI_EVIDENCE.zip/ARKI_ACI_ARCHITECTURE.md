# ARKI Architectural Competition Intelligence — ACI-001

**Maximum status:** FOUNDATION IMPLEMENTED / PILOT SCOPE / PENDING INDEPENDENT VERIFICATION

ACI is a governed capability inside ONE ARKI and the existing LKS. It studies documented competition alternatives, winners and non-winners as comparative design evidence. It does not create a second knowledge database, autonomous web crawler or architectural authority.

The computable foundation provides CompetitionRecord, CompetitionProposalRecord, JuryEvaluationRecord, ArchitecturalObservation, DesignStrategyCandidate, CompetitionComparison and BuiltOutcomeDelta. LKS remains the owner of evidence, provenance, epistemic state, promotion and temporal history.

Core boundaries: winner is not truth; jury decision is contextual; precedent is not template; observation is not canonical knowledge; and competition result cannot self-certify ARKI competence.
