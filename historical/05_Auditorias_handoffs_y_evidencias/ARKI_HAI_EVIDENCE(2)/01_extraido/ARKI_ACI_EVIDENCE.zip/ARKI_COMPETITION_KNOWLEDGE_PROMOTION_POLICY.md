# ARKI Competition Knowledge Promotion Policy v1.0

A corpus item is not a verified architectural principle. Promotion follows project → observation → pattern candidate → cross-project evidence → Curator → knowledge candidate. A single winner, publication or jury outcome cannot self-promote.

The policy preserves provenance, epistemic state, rights and unknowns. Promotion to canonical LKS knowledge remains governed by existing LKS and Human Authority rules.
