# ARKI ACI Pilot Plan v1.0

Wave 1 selects 3–5 competitions with strong official documentation, multiple proposals, available brief, jury evidence and high architectural relevance. Selection should vary period or type where possible.

Later waves expand historical range, typology, geography and long-tail/non-winners. Each wave remains selective, rights-aware and traceable. Corpus quality, comparability, provenance and analytical usefulness take precedence over image count or project count.

The pilot validates the data model and evidence firewall before any expansion. No mass ingestion is authorized.
