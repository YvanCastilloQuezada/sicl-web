# ARKI ACI Test Matrix v1.0

| ID | Scenario | Required result |
|---|---|---|
| ACI-01 | Winner with poor documentation | No over-inference |
| ACI-02 | Non-winner with valuable strategy | Preserve candidate |
| ACI-03 | Same strategy in winner and loser | No automatic causality |
| ACI-04 | Explicit jury reason | Attribution preserved |
| ACI-05 | ARKI interpretation | INFERRED |
| ACI-06 | Historical project | Context preserved |
| ACI-07 | Current reassessment | Separate from original jury judgment |
| ACI-08 | Missing author | UNKNOWN |
| ACI-09 | Missing plan | No fabricated geometry |
| ACI-10 | Reconstruction | Assumptions preserved |
| ACI-11 | Held-out contradiction | Correction and evidence retained |
| ACI-12 | Winning unbuilt project | Winning ≠ buildability |
| ACI-13 | Built delta | Changes preserved |
| ACI-14 | Copyrighted board | Rights preserved |
| ACI-15 | Official vs secondary conflict | Official precedence through Curator |
| ACI-16 | Geographic bias | Not labelled global |
| ACI-17 | Style similarity | No copying instruction |
| ACI-18 | Corpus observation | Cannot become canonical directly |
| ACI-19 | Competition result | Cannot self-certify ARKI |
| ACI-20 | Participation | Human Authority preserved |

The executable foundation test covers records, author uncertainty, rights gate, epistemic observation, comparison, no-style-copy, no-self-certification, no-canonical shortcut, bounded ingestion and scheduler boundary.
