# ARKI Competition Rights and Access Policy v1.0

Each item is classified as PUBLIC_METADATA, PUBLICLY_VIEWABLE, DOWNLOADABLE, LICENSED, OPEN_LICENSE, RESTRICTED, COPYRIGHTED or UNKNOWN_RIGHTS.

Visibility on the Internet does not imply permission to download, redistribute, transform or use boards/models for training. Unknown or restricted rights block ingestion of the protected artifact and preserve only permitted metadata or references. Selective ingestion requires provenance, access status, storage decision and Curator review.

This policy does not authorize mass downloading or rights circumvention.
