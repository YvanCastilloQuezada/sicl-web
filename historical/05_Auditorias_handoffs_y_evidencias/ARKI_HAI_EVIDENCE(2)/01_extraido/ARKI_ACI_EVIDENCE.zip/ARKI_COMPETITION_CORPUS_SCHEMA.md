# ARKI Competition Corpus Schema v1.0

The foundation defines structured records for CompetitionRecord, CompetitionProposalRecord, JuryEvaluationRecord, ArchitecturalObservation, DesignStrategyCandidate, CompetitionComparison and BuiltOutcomeDelta.

Records preserve competition identity, brief, program, constraints, eligibility, jury evidence, proposal result, source files, rights, provenance, epistemic status, unknowns and built/unbuilt status. Missing authors remain explicitly unknown; missing drawings never become fabricated geometry.

The corpus is specialized storage for comparative design evidence, not a second general knowledge truth.
