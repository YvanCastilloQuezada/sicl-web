# ARKI Comparative Design Framework v1.0

For proposals responding to a comparable brief, ACI records common responses, divergent responses, rare strategies, recurring problems, recurring failures, alternative partis, circulation models, urban strategies, structural hypotheses and environmental strategies.

Winner, runner-up, mention, finalist and non-winner remain explicit result states. Comparison asks what is common, what differs, which reasons were attributed by the jury, which strong strategies were not rewarded and which differences remain unexplained.

Correlation is not causality. A design strategy becomes a candidate for transfer only after cross-project evidence and Curator review.
