# ARKI Semantic Reconstruction Protocol v1.0

Pipeline: documentation → spaces → relationships → circulation → massing → topology → structural hypothesis → environmental hypothesis → semantic model.

Reconstruction preserves source evidence, assumptions, inferred elements, unknowns and confidence dimensions. `SEE ≠ UNDERSTAND ≠ RECONSTRUCT ≠ ORIGINAL MODEL`; reconstruction is never asserted as fact. Held-out documentation may test a reconstruction when legal and technically possible.
