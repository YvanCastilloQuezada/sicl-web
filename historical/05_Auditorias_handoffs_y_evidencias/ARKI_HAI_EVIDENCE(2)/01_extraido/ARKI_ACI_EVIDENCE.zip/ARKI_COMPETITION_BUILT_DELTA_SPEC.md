# ARKI Competition Built Outcome Delta v1.0

Where evidence exists, ACI compares competition proposal with design development, engineering, procurement, construction and operation. It records preserved, modified, removed and added ideas, systems, structural, program, cost, regulatory, material, environmental and operational changes.

A delta without documented cause remains unknown. Winning does not imply buildability, and a built result does not prove the competition proposal was technically complete.
