# ARKI 50-Year Architectural Timeline Specification v1.0

The initial research horizon is approximately 1975 to the present, while exceptional earlier competitions may be preserved. Period views cover the 1970s, 1980s, 1990s, 2000s, 2010s and 2020s when evidence permits.

The timeline observes changes in urban relationship, monumentality, public realm, program, typology, landscape, environmental response, sustainability, reuse, participation, mobility, materiality, representation, computation, resilience, circularity, inclusion and narrative.

Contemporary-to-project evaluation and current reassessment remain separate.
