# ARKI Jury Intelligence Specification v1.0

JuryEvaluationRecord preserves composition, professional background, criteria, explicit comments, strengths, weaknesses, reasons for selection and reasons for rejection when documented.

Jury reasoning is contextual evidence from a particular time, brief, rules and cultural setting. Missing reasoning is UNKNOWN. A jury decision is never promoted to universal architectural truth or professional completeness.
