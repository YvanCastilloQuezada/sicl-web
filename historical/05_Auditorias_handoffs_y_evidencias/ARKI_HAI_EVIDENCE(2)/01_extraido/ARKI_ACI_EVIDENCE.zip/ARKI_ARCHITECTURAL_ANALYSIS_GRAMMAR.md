# ARKI Architectural Analysis Grammar v1.0

The extensible grammar covers parti, concept, site and urban strategy, landscape, program, zoning, access, circulation, spatial sequence, public/private, solid/void, massing, topology, structural logic, envelope, light, materiality, climate response, human scale, public realm, flexibility, adaptability, constructability, economy, sustainability, resilience, representation and narrative.

Each observation preserves documented, observed, inferred, hypothesized and unknown status. The grammar describes analysis; it does not claim structural calculation, professional certification or original-model recovery.
