# ARKI Competition Participation Specification v1.0

Future participation flow: eligibility → brief → context → requirements → ARKI design process → alternatives → evaluation → Human Decision → submission.

This addendum does not implement autonomous participation or submission. Human architect remains entrant, author and professionally responsible party. Before participation, AI permission, disclosure, authorship, intellectual property, anonymity, deliverables and disqualification rules must be checked for the specific competition.
