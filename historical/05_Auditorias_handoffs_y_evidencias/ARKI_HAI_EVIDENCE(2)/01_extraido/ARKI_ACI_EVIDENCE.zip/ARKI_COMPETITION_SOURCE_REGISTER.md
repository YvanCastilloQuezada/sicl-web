# ARKI Competition Source Register v1.0

Initial source families are candidates only: competition organizers, official archives, UIA/UNESCO where applicable, official jury reports, official publications, architect/team sources, institutional archives, professional bodies, universities and secondary publications.

Every source must pass LKS source registration, rights/access review and Curator review before selective ingestion. Social media and unknown sources have lower evidentiary priority and cannot override official jury evidence without documented curation.

No claim of global or exhaustive coverage is made.
